"""finalize.py — 方案冻结后的交付流水线（一次跑完：合并 → 传播 → 官方复核 → 图表/报告 → 打包）。

阶段：
  L1  合并问题一增量跑批（litA / mgA / tworst / …）进 out/final
  L2  合并问题三/问题二增量（runC / runB）进 out/final3 / out/finalB
  L3  把问题一的最终方案传播到问题三/问题二（sceneBC 复用+官方精评），再取最优合并
  L4  官方复核（verify_mp 直接用未打补丁的官方评估器；B/三 由 mkcsv 汇总同一官方数值）
  L5  附表、图表、单文件报告
  L6  打包 deliverable/ 与 deliverable.zip

用法：
    python finalize.py --workers 8 --a-deltas out/litA out/mgA
    python finalize.py --stage L1 L2            # 只跑指定阶段
    python finalize.py --skip-verify            # 跳过 L4 的 A 场景全量官方复核
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable
LOGS = os.path.join(HERE, 'out')


def run(tag, args, cwd=HERE):
    log = os.path.join(LOGS, 'fin_%s.log' % tag)
    print('[%s] %s' % (tag, ' '.join(args)), flush=True)
    t0 = time.time()
    with open(log, 'w', encoding='utf-8') as f:
        p = subprocess.run([PY, '-u'] + args, cwd=cwd, stdout=f,
                           stderr=subprocess.STDOUT)
    ok = p.returncode == 0
    print('[%s] %s  (%.0fs)  log=%s' % (tag, 'OK' if ok else
                                        'FAIL rc=%d' % p.returncode,
                                        time.time() - t0, log), flush=True)
    return ok


def tail(tag, n=40):
    p = os.path.join(LOGS, 'fin_%s.log' % tag)
    if not os.path.exists(p):
        return
    lines = open(p, encoding='utf-8', errors='replace').read().splitlines()
    for L in lines[-n:]:
        print('   |', L[:180])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--stage', nargs='+',
                    default=['L1', 'L2', 'L3', 'L4', 'L5', 'L6'])
    ap.add_argument('--workers', type=int, default=8)
    ap.add_argument('--a-deltas', nargs='*',
                    default=['out/litA', 'out/mgA', 'out/tworst'])
    ap.add_argument('--b-deltas', nargs='*', default=['out/runB'])
    ap.add_argument('--c-deltas', nargs='*', default=['out/runC'])
    ap.add_argument('--verify-workers', type=int, default=0,
                    help='0 表示用 --workers')
    ap.add_argument('--skip-verify', action='store_true')
    ap.add_argument('--skip-prop', action='store_true',
                    help='跳过 L3（把问题一方案传播到问题二/三）')
    args = ap.parse_args()
    W = args.workers
    VW = args.verify_workers or W

    def has(t):
        return t in args.stage

    if has('L1'):
        dels = [d for d in args.a_deltas if os.path.isdir(os.path.join(HERE, d))]
        if dels:
            run('L1_mergeA', ['mergeA.py', '--final', 'out/final',
                              '--deltas'] + dels)
            tail('L1_mergeA', 20)

    if has('L2'):
        for scene, base, dels in (('3', 'out/final3', args.c_deltas),
                                  ('B', 'out/finalB', args.b_deltas)):
            ds = [d for d in dels if os.path.isdir(os.path.join(HERE, d))]
            if not ds:
                continue
            tag = 'L2_merge%s' % scene
            run(tag, ['mergeBC.py', '--base', base, '--deltas'] + ds +
                ['--scene', scene])
            tail(tag, 12)

    if has('L3') and not args.skip_prop:
        for scene, out, base in (('B', 'out/finalB2', 'out/finalB'),
                                 ('3', 'out/final32', 'out/final3')):
            tag = 'L3_scene%s' % scene
            run(tag, ['sceneBC.py', '--scene', scene, '--src', 'out/final/plans',
                      '--t1', 'out/final/results_problem1.csv',
                      '--out', out, '--workers', str(W)])
            tail(tag, 8)
            tag2 = 'L3_merge%s' % scene
            run(tag2, ['mergeBC.py', '--base', base, '--deltas', out,
                       '--scene', scene])
            tail(tag2, 8)

    if has('L4'):
        if not args.skip_verify:
            for scene, plans, out in (
                    ('A', 'out/final/plans', 'out/final/verified_A.csv'),
                    ('B', 'out/finalB', 'out/final/verified_B.csv'),
                    ('3', 'out/final3', 'out/final/verified_3.csv')):
                tag = 'L4_ver%s' % scene
                run(tag, ['verify_mp.py', '--plans', plans, '--scene', scene,
                          '--out', out, '--workers', str(VW)])
                tail(tag, 12)
        else:
            run('L4_mkcsvB', ['mkcsv.py', '--summary',
                              'out/finalB/summary_all.csv', '--scene', 'B',
                              '--out', 'out/final/verified_B.csv'])
            tail('L4_mkcsvB', 8)
            run('L4_mkcsv3', ['mkcsv.py', '--summary',
                              'out/final3/summary_all.csv', '--scene', '3',
                              '--out', 'out/final/verified_3.csv'])
            tail('L4_mkcsv3', 8)

    if has('L5'):
        run('L5_appendix', ['appendix.py', '--dir', 'out/final'])
        tail('L5_appendix', 8)
        run('L5_paper', ['gen_paper.py', '--dir', 'out/final',
                         '--out', 'out/final/paper.html'])
        tail('L5_paper', 8)

    if has('L6'):
        run('L6_package', ['package_all.py'])
        tail('L6_package', 30)

    print('finalize done.')


if __name__ == '__main__':
    main()
