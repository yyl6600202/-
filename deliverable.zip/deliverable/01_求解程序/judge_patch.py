"""judge_patch.py — 判定 5 例不一致的责任方。

对同一份方案分别用
  (a) 未打补丁的官方评估器（work/code/*.py，原样 import）
  (b) 内存补丁加速版 fl
评估，并与第三方汇总表里的历史 makespan 比对。
"""
from __future__ import annotations

import csv
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.join(HERE, 'code')
sys.path.insert(0, CODE)
sys.path.insert(0, HERE)

import fl  # noqa: E402

PKG = r'C:\Users\xjw\Desktop\A题_交接包_5核优化\题目与附件\通用神经网络处理器下的多核调度问题  附件\day5_results'
PLANS = os.path.join(PKG, 'problem1_5core_plans')
SUMMARY = os.path.join(PKG, 'problem1_5core_optimized_summary.csv')


def main():
    cases = sys.argv[1:] or ['case_002', 'case_062', 'case_063', 'case_082', 'case_085']
    ref = {}
    with open(SUMMARY, encoding='utf-8-sig', newline='') as f:
        for row in csv.DictReader(f):
            ref[row['case']] = row

    import importlib
    p1o = importlib.import_module('multicore_cut_evaluate_problem_1')
    cfg = fl.config()
    for stem in cases:
        f = stem + '.json'
        plan = json.load(open(os.path.join(PLANS, f), encoding='utf-8'))
        g = json.load(open(os.path.join(PLANS, f), encoding='utf-8')) if False else None
        with open(os.path.join(fl.DATA if hasattr(fl, 'DATA') else os.path.join(HERE, 'data'), f),
                  encoding='utf-8') as fh:
            g = json.load(fh)
        # (a) 未打补丁
        ra = p1o.evaluate_scene_a(
            g, plan, bandwidth=cfg['bandwidth'], capacity=cfg['capacity'],
            cross_core_wait=cfg['cross_core_wait'],
            same_core_wait=cfg['same_core_wait'])
        # (b) 补丁版
        rb = fl.load_fast()['p1'].evaluate_scene_a(
            g, plan, bandwidth=cfg['bandwidth'], capacity=cfg['capacity'],
            cross_core_wait=cfg['cross_core_wait'],
            same_core_wait=cfg['same_core_wait'])
        want = ref.get(stem, {}).get('problem1_makespan')
        print('%-10s UNPATCHED=%-12d PATCHED=%-12d CSV=%-12s  unp==csv:%s  patch==csv:%s'
              % (stem, ra['makespan'], rb['makespan'], want,
                 str(ra['makespan']) == str(want), str(rb['makespan']) == str(want)))
        print('           unp_added=%d patch_added=%d  unp_spill=%d patch_spill=%d'
              % (ra['data_movement_bytes']['added_copy_bytes'],
                 rb['data_movement_bytes']['added_copy_bytes'],
                 ra['data_movement_bytes'].get('spill_added_copy_bytes', -1),
                 rb['data_movement_bytes'].get('spill_added_copy_bytes', -1)))


if __name__ == '__main__':
    main()
