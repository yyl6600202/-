"""px.py — 场景 A 的快速估价代理（不调用官方评估器）。

对应参考模型式(2)/(3)：
    M_hat = max_k L_k + (D0 + ΔD)/B + W
其中 L_k 取该核 M/V 两条流水线的较大者；ΔD 为切分新增的 DDR 搬运量；
W 为 Task 图上按"同核 100 / 跨核 1000"权重的最长路。

实现为一个"Task 级事件模拟"：每个 Task 的耗时用其内部下界估计
    cost = max(M_load, V_load, copy_in/B, copy_out/B)
再按核串行 + 依赖等待传播。
"""
from __future__ import annotations
from collections import defaultdict


def layer_from(V, ocore):
    lv = {}
    for o in V.topo:
        ps = V.preds[o]
        if not ps:
            lv[o] = 0
        else:
            c = ocore[o]
            lv[o] = max(lv[p] + (1 if ocore[p] != c else 0) for p in ps)
    return lv


def tasks_of(V, ocore):
    lv = layer_from(V, ocore)
    task_of = {}
    tasks = defaultdict(list)
    for o in V.ops:
        key = (ocore[o], lv[o])
        task_of[o] = key
        tasks[key].append(o)
    return task_of, tasks


def proxy(V, ocore, k, B=60.0, cross_wait=1000, same_wait=100):
    task_of, tasks = tasks_of(V, ocore)
    # 每个 Task 的负载与边界搬运
    m_load = defaultdict(int)
    v_load = defaultdict(int)
    inb = defaultdict(float)
    outb = defaultdict(float)
    preds_t = defaultdict(set)
    for o in V.ops:
        t = task_of[o]
        if V.pipe[o] == 'PIPE_M':
            m_load[t] += V.cyc[o]
        else:
            v_load[t] += V.cyc[o]
    for o in V.ops:
        t = task_of[o]
        for s in V.succs[o]:
            ts = task_of[s]
            if ts != t:
                preds_t[ts].add(t)
                b = V.esz.get((o, s), 0.0)
                outb[t] += b
                inb[ts] += b
    cost = {}
    total_copy = 0.0
    for t in tasks:
        ci = inb[t] / B
        co = outb[t] / B
        total_copy += inb[t] + outb[t]
        cost[t] = max(m_load[t], v_load[t], ci, co)
    # Task 级事件模拟（按层递增处理，保证同核顺序正确）
    order = sorted(tasks.keys(), key=lambda t: (t[1], t[0]))
    end = {}
    core_last = {}
    for t in order:
        c = t[0]
        rel = 0
        prev = core_last.get(c)
        if prev is not None:
            rel = end[prev] + same_wait
        for p in preds_t[t]:
            r = end[p] + (cross_wait if p[0] != c else same_wait)
            if r > rel:
                rel = r
        end[t] = rel + cost[t]
        core_last[c] = t
    mk = max(end.values()) if end else 0
    ddr_floor = total_copy / B
    return max(mk, ddr_floor)
