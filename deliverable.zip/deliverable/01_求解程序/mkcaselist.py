"""mkcaselist.py — 从 gap5b.txt（k=5 的 ms/LB 排名）里抽出前 N 个用例，写成 case-file。"""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
O = os.path.join(HERE, 'out')
N = int(sys.argv[1]) if len(sys.argv) > 1 else 35
out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(O, 'weak35.txt')
cs = []
for ln in open(os.path.join(O, 'gap5b.txt'), encoding='utf-8', errors='replace'):
    ln = ln.strip()
    if ln.startswith('case_') and '.json' in ln:
        cs.append(ln.split()[0])
cs = cs[:N]
with open(out, 'w', encoding='utf-8') as f:
    f.write('\n'.join(cs) + '\n')
print('n=%d -> %s' % (len(cs), out))
print(' '.join(cs))
