"""figs2.py — 文献风格配图（对照 HEFT / 硬件感知图划分论文的图表组织方式）。

产出（out/figs2/*.png）：
  L1 dag_cores      加权 DAG 片段 + 按核着色（对照 p4 图 1/图 3 的"分区结果"示意）
  L2 gantt          k=5 时逐核执行时间线（甘特图，含共享 DDR 池）
  L3 methods        方法对照分组柱状图：HEFT / RR / LVL-LPT / 本文（对照 p2 图 3–7）
  L4 sorted_cdf     逐用例加速比排序条形 + 累积分布（对照 p2 的"频率/质量"图）
  L5 case_scatter   用例规模（算子数/边数）vs 加速比散点 + 核负载均衡度
  L6 partition      分区过程四联图：k=1→2→3→5 的逐核负载堆叠（对照 p4 图 3(a)–(d)）

用法：python figs2.py [--out out/figs2] [--case case_002.json] [--k 5]
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from collections import defaultdict

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib import font_manager  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fev  # noqa: E402

KS = [2, 3, 4, 5]
CORE_COLORS = ['#c0392b', '#2980b9', '#27ae60', '#8e44ad', '#e67e22',
               '#16a085', '#7f8c8d', '#2c3e50']


def setup_font():
    have = {f.name for f in font_manager.fontManager.ttflist}
    for name in ('Microsoft YaHei', 'SimHei', 'Noto Sans CJK SC',
                 'Source Han Sans SC', 'DejaVu Sans'):
        if name in have:
            plt.rcParams['font.sans-serif'] = [name, 'DejaVu Sans']
            break
    plt.rcParams['axes.unicode_minus'] = False


def load_csv(p):
    if not os.path.exists(p):
        return {}
    d = {}
    for r in csv.DictReader(open(p, encoding='utf-8-sig')):
        try:
            d[(r['case'], int(r['k']))] = r
        except (KeyError, ValueError):
            continue
    return d


def load_csv3(p):
    """基线表专用：同一 (用例, 核数) 下有三种方法，必须再把 method 放进键里，
    否则后写的行会覆盖前面的行（曾导致 LVL-LPT/HEFT 两条柱状图全为 0）。"""
    d = {}
    if not os.path.exists(p):
        return d
    for r in csv.DictReader(open(p, encoding='utf-8-sig')):
        try:
            d[(r['case'], int(r['k']), r['method'])] = r
        except (KeyError, ValueError):
            continue
    return d


def save(fig, outdir, name):
    p = os.path.join(outdir, name + '.png')
    fig.savefig(p, dpi=170, bbox_inches='tight')
    plt.close(fig)
    print('  ->', p, '%.0f KB' % (os.path.getsize(p) / 1024))


# --------------------------------------------------------------- L1 DAG 着色
def fig_dag(case, plan_path, outdir, max_ops=34):
    g = fev.graph(case)
    plan = json.load(open(plan_path, encoding='utf-8'))
    n2s = plan['node_to_subgraph']
    sched = plan['core_schedules']
    sg_core = {}
    for c, sgs in enumerate(sched):
        for sg in sgs:
            sg_core[sg] = c
    ops = {o['id']: o for o in g['ops']}
    succ = defaultdict(list)
    pred = defaultdict(list)
    for e in g['edges']:
        s, t = e['source'], e['target']
        if s in ops and t in ops:
            succ[s].append(t)
            pred[t].append(s)
    # 只画前 max_ops 个"拓扑靠前且同属一个连通块"的普通算子
    indeg = {i: len(pred[i]) for i in ops}
    q = [i for i in ops if indeg[i] == 0]
    order = []
    while q:
        u = q.pop()
        order.append(u)
        for v in succ[u]:
            indeg[v] -= 1
            if indeg[v] == 0:
                q.append(v)
    pick = [o for o in order if ops[o]['op'] not in ('COPY_IN', 'COPY_OUT')]
    pick = pick[:max_ops]
    pset = set(pick)
    lvl = {}
    for o in pick:
        lvl[o] = 0
    for o in order:
        if o not in pset:
            continue
        lvl[o] = max([lvl[p] + 1 for p in pred[o] if p in pset] or [0])
    col = defaultdict(list)
    for o in pick:
        col[lvl[o]].append(o)
    pos = {}
    for L, items in col.items():
        for j, o in enumerate(sorted(items, key=lambda z: -ops[z].get('cycles', 0))):
            pos[o] = (L, -(j - (len(items) - 1) / 2.0))
    fig, ax = plt.subplots(figsize=(11, 5.6))
    for o in pick:
        for s in succ[o]:
            if s in pset:
                ax.annotate('', xy=pos[s], xytext=pos[o],
                            arrowprops=dict(arrowstyle='-|>', color='#95a5a6',
                                            lw=1.0, shrinkA=9, shrinkB=9))
    for o in pick:
        c = sg_core.get(n2s.get(str(o)), 0)
        op = ops[o]['op']
        cy = ops[o].get('cycles', 0)
        ax.scatter(*pos[o], s=520, color=CORE_COLORS[c % len(CORE_COLORS)],
                   edgecolors='white', linewidths=1.4, zorder=3)
        ax.text(pos[o][0], pos[o][1], '%s\n%d' % (op[:4], cy), ha='center',
                va='center', fontsize=5.4, color='white', zorder=4)
    hs = [plt.Line2D([], [], marker='o', ls='', color=CORE_COLORS[c],
                     ms=9, label='核 %d' % c) for c in range(len(sched))]
    ax.legend(handles=hs, loc='upper left', fontsize=10, framealpha=0.9)
    ax.set_title('%s 的最优切图（k=%d）：按 (核, 层) 二维放置后的算子归属\n'
                 '节点颜色=核，节点内为 <算子类型, 周期数>；箭头为数据依赖'
                 % (case, len(sched)), fontsize=11)
    ax.set_xlabel('依赖层（拓扑序深度）')
    ax.axis('off')
    save(fig, outdir, 'L1_dag_cores')


# --------------------------------------------------------------- L2 甘特图
def fig_gantt(case, plan_path, outdir, topn=90):
    g = fev.graph(case)
    plan = json.load(open(plan_path, encoding='utf-8'))
    P = fev._modules()  # noqa: SLF001
    cfg = fev.config()
    r = P['p2'].evaluate_scene_b(
        g, plan, bandwidth=cfg['bandwidth'], capacity=dict(cfg['capacity']),
        cross_core_copy_delay=P['cross_core_copy_delay'])
    tls = r['per_core_timeline']
    fig, ax = plt.subplots(figsize=(11, 4.6))
    K = len(tls)
    for ci, tl in enumerate(tls):
        evs = sorted(tl['ops'], key=lambda e: e['start'])
        if len(evs) > topn:
            step = max(1, len(evs) // topn)
            evs = evs[::step]
        y = K - 1 - ci
        for e in evs:
            isc = e['op'] in ('COPY_IN', 'COPY_OUT')
            ax.barh(y, max(1, e['end'] - e['start']), left=e['start'], height=0.62,
                    color=('#e67e22' if isc else CORE_COLORS[ci % len(CORE_COLORS)]),
                    edgecolor='none', alpha=0.95 if not isc else 0.85)
        ax.barh(y, tl['tasks'][0]['end'], left=0, height=0.10, color='#3498db',
                alpha=0.25)
    ax.set_yticks(range(K))
    ax.set_yticklabels(['核 %d' % (K - 1 - i) for i in range(K)])
    ax.set_xlabel('周期 (cycle)')
    ax.set_title('%s 的 k=%d 执行时间线（橘色=跨核搬运 COPY，其余=计算；'
                 'makespan=%d）' % (case, K, r['makespan']), fontsize=11)
    ax.grid(axis='x', alpha=0.25)
    ax.set_xlim(0, r['makespan'] * 1.02)
    save(fig, outdir, 'L2_gantt')


# --------------------------------------------------------------- L3 方法对照
def fig_methods(base, ours, outdir):
    if not base:
        print('  (跳过 L3：缺少 baselines.csv)')
        return
    methods = ['RR', 'LVL-LPT', 'HEFT', '本文（(核,层) 单调着色 + 搜索）']
    # 公平对照：本文只统计**与基线完全相同的那批用例**（基线是抽样跑的）
    bcases = {c for (c, _k, _m) in base}
    ours_by = {k: [] for k in KS}
    for (c, k), r in ours.items():
        if k in KS and c in bcases:
            ours_by[k].append(float(r['speedup']))
    data = {}
    for m in methods[:3]:
        data[m] = {k: [] for k in KS}
        for (c, k, mm), r in base.items():
            if mm == m and k in KS:
                data[m][k].append(float(r['speedup']))
    data[methods[3]] = ours_by
    for m in methods:
        print('   %-28s' % m, ' '.join(
            'k%d=%.4f' % (k, sum(data[m][k]) / len(data[m][k]))
            if data[m].get(k) else 'k%d=--' % k for k in KS))
    fig, ax = plt.subplots(figsize=(9.0, 4.6))
    n = len(KS)
    w = 0.2
    for i, m in enumerate(methods):
        xs, ys = [], []
        for j, k in enumerate(KS):
            v = data[m].get(k) or []
            xs.append(j + (i - 1.5) * w)
            ys.append(sum(v) / len(v) if v else 0)
        bars = ax.bar(xs, ys, w, label=m, color=CORE_COLORS[i % len(CORE_COLORS)],
                      alpha=0.92, edgecolor='white')
        for b, y in zip(bars, ys):
            ax.text(b.get_x() + b.get_width() / 2, y + 0.05, '%.2f' % y,
                    ha='center', fontsize=7.2)
    ax.axhline(4.0, ls='--', color='#7f8c8d', lw=1.2)
    ax.text(0.02, 4.06, '4.0 参考线', fontsize=8, color='#7f8c8d')
    ax.set_xticks(range(n))
    ax.set_xticklabels(['%d 核' % k for k in KS])
    ax.set_ylabel('平均加速比（逐用例比值后算术平均）')
    ax.set_title('与文献基线的对照（同一官方评测口径、同 %d 例抽样）' % len(bcases),
                 fontsize=11)
    ax.grid(axis='y', alpha=0.3)
    ax.legend(fontsize=8.4, loc='upper left')
    save(fig, outdir, 'L3_methods')


# ----------------------------------------------------- L4 排序条形 + 累积分布
def fig_sorted_cdf(B, C, outdir, k=5):
    vb = sorted((float(r['speedup']) for (c, kk), r in B.items() if kk == k))
    vc = sorted((float(r['speedup']) for (c, kk), r in C.items() if kk == k))
    if not vb:
        print('  (跳过 L4)')
        return
    fig, axes = plt.subplots(1, 2, figsize=(12.2, 4.4))
    ax = axes[0]
    ax.bar(range(len(vb)), vc, color='#16a085', alpha=0.75, width=1.0,
           label='问题三（只读 L2）')
    ax.bar(range(len(vb)), vb, color='#2980b9', alpha=0.55, width=1.0,
           label='问题二（无 L2）')
    ax.axhline(4.0, ls='--', color='#c0392b', lw=1.2)
    ax.axhline(sum(vb) / len(vb), ls=':', color='#2980b9', lw=1.2,
               label='问题二均值 %.3f' % (sum(vb) / len(vb)))
    ax.axhline(sum(vc) / len(vc), ls=':', color='#16a085', lw=1.2,
               label='问题三均值 %.3f' % (sum(vc) / len(vc)))
    ax.set_xlabel('用例（按加速比升序）')
    ax.set_ylabel('%d 核加速比' % k)
    ax.set_title('逐用例加速比排序（k=%d）' % k)
    ax.legend(fontsize=8)
    ax.grid(axis='y', alpha=0.3)

    ax = axes[1]
    for v, col, nm in ((vb, '#2980b9', '问题二'), (vc, '#16a085', '问题三')):
        xs = [x / len(v) for x in range(1, len(v) + 1)]
        ax.step(v, xs, where='post', color=col, lw=2.0, label=nm)
    ax.axvline(4.0, ls='--', color='#c0392b', lw=1.2)
    ax.text(4.05, 0.05, '4.0', fontsize=8, color='#c0392b')
    ax.set_xlabel('%d 核加速比' % k)
    ax.set_ylabel('累积比例')
    ax.set_title('加速比累积分布（k=%d）' % k)
    ax.grid(alpha=0.3)
    ax.legend(fontsize=8.4)
    save(fig, outdir, 'L4_sorted_cdf')


# ------------------------------------------- L5 规模散点 + 核负载均衡度
def fig_scatter(B, outdir, k=5):
    # 用例规模从 capcheck.csv 读取（避免逐图解析上百个 JSON）
    stat = {}
    cp = os.path.join(HERE, 'out', 'capcheck.csv')
    if os.path.exists(cp):
        for r in csv.DictReader(open(cp, encoding='utf-8-sig')):
            if int(r['k']) == k:
                stat[r['case']] = (int(r['nops']), int(r['sum_pipe']))
    pts = []
    for (c, kk), r in B.items():
        if kk != k:
            continue
        n, cyc = stat.get(c, (0, 0))
        pts.append((n, cyc, float(r['speedup']), int(r['T1'])))
    if not pts:
        print('  (跳过 L5)')
        return
    fig, axes = plt.subplots(1, 2, figsize=(12.2, 4.4))
    ax = axes[0]
    ax.scatter([p[1] for p in pts], [p[2] for p in pts], s=[max(8, min(120, p[0] / 60))
               for p in pts], c='#8e44ad', alpha=0.65, edgecolors='white')
    ax.axhline(4.0, ls='--', color='#c0392b', lw=1.2)
    ax.set_xscale('log')
    ax.set_xlabel('单核 M/V 周期总量 Σcyc（对数轴）')
    ax.set_ylabel('%d 核加速比' % k)
    ax.set_title('用例规模 vs 加速比（点面积∝算子数）')
    ax.grid(alpha=0.3)
    ax = axes[1]
    ax.hist([p[2] for p in pts], bins=16, color='#e67e22', alpha=0.85,
            edgecolor='white')
    ax.axvline(4.0, ls='--', color='#c0392b', lw=1.2)
    ax.axvline(sum(p[2] for p in pts) / len(pts), ls='-', color='#2c3e50', lw=1.4)
    ax.set_xlabel('%d 核加速比' % k)
    ax.set_ylabel('用例数')
    ax.set_title('加速比分布（k=%d，实线=均值 %.3f）'
                 % (k, sum(p[2] for p in pts) / len(pts)))
    ax.grid(axis='y', alpha=0.3)
    save(fig, outdir, 'L5_case_scatter')


# ------------------------------------------------------------- L6 分区过程
def fig_partition(case, plans_dir, outdir, kk=5):
    fig, axes = plt.subplots(1, 4, figsize=(13.2, 3.5))
    for ax, k in zip(axes, [1, 2, 3, kk]):
        if k == 1:
            g = fev.graph(case)
            cyc = defaultdict(float)
            for o in g['ops']:
                if o.get('op') in ('COPY_IN', 'COPY_OUT'):
                    continue
                cyc['0'] += o.get('cycles', 0)
            loads = {0: cyc['0']}
        else:
            p = os.path.join(plans_dir, '%s_k%d.json' % (case[:-5], k))
            if not os.path.exists(p):
                ax.axis('off')
                continue
            plan = json.load(open(p, encoding='utf-8'))
            loads = {i: 0.0 for i in range(k)}
            g = fev.graph(case)
            ocy = {o['id']: max(1, o.get('cycles', 1)) for o in g['ops']}
            for oid, sg in plan['node_to_subgraph'].items():
                c = None
                for ci, sgs in enumerate(plan['core_schedules']):
                    if sg in sgs:
                        c = ci
                        break
                if c is not None:
                    loads[c] += ocy.get(int(oid), int(oid) if False else 0)
        ks = sorted(loads)
        vals = [loads[c] for c in ks]
        tot = sum(vals) or 1
        ax.bar(range(len(ks)), vals,
               color=[CORE_COLORS[c % len(CORE_COLORS)] for c in ks],
               edgecolor='white')
        ax.axhline(tot / len(ks), ls='--', color='#2c3e50', lw=1.1)
        imb = (max(vals) - min(vals)) / (tot / len(ks))
        ax.set_title('k=%d\n最大偏差 %.1f%%' % (len(ks), 100 * imb), fontsize=10)
        ax.set_xticks(range(len(ks)))
        ax.set_xticklabels(['核%d' % c for c in ks], fontsize=8)
        ax.grid(axis='y', alpha=0.3)
        if k == 1:
            ax.set_ylabel('该核的算子周期总量')
    fig.suptitle('%s：随核数增加的分区与负载均衡过程（虚线=各核平均负载）'
                 % case, fontsize=11)
    save(fig, outdir, 'L6_partition')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default='out/figs2')
    ap.add_argument('--case', default=None, help='示意用用例（默认自动挑中等规模）')
    ap.add_argument('--k', type=int, default=5)
    args = ap.parse_args()
    setup_font()
    outdir = os.path.join(HERE, args.out)
    os.makedirs(outdir, exist_ok=True)

    B = load_csv(os.path.join(HERE, 'out', 'finalB', 'summary_all.csv'))
    C = load_csv(os.path.join(HERE, 'out', 'final3', 'summary_all.csv'))
    ours = load_csv(os.path.join(HERE, 'out', 'final', 'results_problem1.csv'))
    base = load_csv3(os.path.join(HERE, 'out', 'baselines', 'baselines.csv'))

    case = args.case
    if not case:
        cand = []
        for f in os.listdir(os.path.join(HERE, 'data')):
            if f.startswith('case_') and f.endswith('.json') and f[5:-5].isdigit():
                sz = os.path.getsize(os.path.join(HERE, 'data', f))
                if 1.0e6 < sz < 3.0e6:
                    cand.append((sz, f))
        cand.sort()
        case = cand[len(cand) // 2][1] if cand else 'case_002.json'
    print('示意用例:', case)

    pl5 = os.path.join(HERE, 'out', 'final', 'plans',
                       '%s_k%d.json' % (case[:-5], args.k))
    if os.path.exists(pl5):
        fig_dag(case, pl5, outdir)
    else:
        print('  (跳过 L1：缺 %s)' % pl5)
    pb5 = os.path.join(HERE, 'out', 'finalB', '%s_k%d.json' % (case[:-5], args.k))
    if os.path.exists(pb5):
        fig_gantt(case, pb5, outdir)
    else:
        print('  (跳过 L2：缺 %s)' % pb5)
    fig_methods(base, ours, outdir)
    fig_sorted_cdf(B, C, outdir, k=args.k)
    fig_scatter(B, outdir, k=args.k)
    fig_partition(case, os.path.join(HERE, 'out', 'final', 'plans'), outdir,
                  kk=args.k)
    print('完成 ->', outdir)


if __name__ == '__main__':
    main()
