"""mkcsv.py — 把 sceneBC.py 的汇总表转成与 verify_mp.py 同格式的发布级复核表。

说明：`sceneBC.py` 内部直接调用**未经补丁**的官方评估器
`multicore_cut_evaluate_problem_2/3.py`（只读 L2 配置取自 data/config.txt），
因此其输出本身就是官方数值；本脚本只是统一列名与排序，便于 `gen_paper.py`
与 `appendix.py` 直接消费，避免对同一批方案重复跑一遍昂贵的官方评测。

用法：
    python mkcsv.py --summary out/finalB/summary_all.csv --scene B --out out/final/verified_B.csv
    python mkcsv.py --summary out/final3/summary_all.csv --scene 3 --out out/final/verified_3.csv
"""
from __future__ import annotations

import argparse
import csv
import os

FIELDS = ['scene', 'case', 'k', 'T1', 'ms', 'speedup', 'added_copy_bytes',
          'cache_hit_rate']


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--summary', required=True)
    ap.add_argument('--scene', required=True)
    ap.add_argument('--out', required=True)
    args = ap.parse_args()

    best = {}
    for r in csv.DictReader(open(args.summary, encoding='utf-8-sig')):
        if int(r['T1']) <= 0 or int(r['ms']) <= 0:
            continue                      # 跳过 T1 缺失的无效记录（曾把加速比算成 0）
        key = (r['case'], int(r['k']))
        ms = int(r['ms'])
        if key not in best or ms < int(best[key]['ms']):
            best[key] = r
    rows = []
    for (case, k), r in sorted(best.items(),
                               key=lambda kv: (int(kv[0][0][5:-5]), kv[0][1])):
        t1, ms = int(r['T1']), int(r['ms'])
        rows.append(dict(scene=args.scene, case=case, k=k, T1=t1, ms=ms,
                         speedup=round(t1 / ms, 6),
                         added_copy_bytes=int(r['added_copy_bytes']),
                         cache_hit_rate=(r.get('cache_hit_rate') or '')))
    with open(args.out, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)
    from collections import defaultdict
    byk = defaultdict(list)
    for r in rows:
        byk[r['k']].append(r['speedup'])
    print('-> %s  (%d 条)' % (args.out, len(rows)))
    for k in sorted(byk):
        v = byk[k]
        print('  scene %s k=%d n=%d mean=%.4f min=%.4f max=%.4f'
              % (args.scene, k, len(v), sum(v) / len(v), min(v), max(v)))


if __name__ == '__main__':
    main()
