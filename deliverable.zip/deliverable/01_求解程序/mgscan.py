"""mgscan.py — 扫描 out/final/plans 全部方案，输出每个 (case,k) 的任务数/可合并切点数，
并与 T1、当前 ms 合并成一张表，用于圈定"合并算子可能有效"的目标集。"""
from __future__ import annotations
import csv, json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
PLANS = os.path.join(HERE, 'out', 'final', 'plans')
RES = os.path.join(HERE, 'out', 'final', 'results_problem1.csv')
OUT = os.path.join(HERE, 'out', 'mgscan.csv')

T1, MS = {}, {}
for r in csv.DictReader(open(RES, encoding='utf-8-sig')):
    T1[r['case']] = int(r['T1'])
    for k in (2, 3, 4, 5):
        v = r.get('T%d' % k)
        if v:
            MS[(r['case'], k)] = int(float(v))

rows = []
for f in sorted(os.listdir(PLANS)):
    if not f.endswith('.json'):
        continue
    stem, ks = f[:-5].rsplit('_k', 1)
    k = int(ks)
    plan = json.load(open(os.path.join(PLANS, f), encoding='utf-8'))
    sgs = set(int(v) for v in plan['node_to_subgraph'].values())
    ncore_used = sum(1 for s in plan['core_schedules'] if s)
    ntask = len(sgs)
    rows.append(dict(case=stem + '.json', k=k, ntask=ntask,
                     ncand=ntask - ncore_used, T1=T1.get(stem + '.json', 0),
                     ms=MS.get((stem + '.json', k), 0)))

rows.sort(key=lambda r: (r['k'], -r['ntask']))
with open(OUT, 'w', encoding='utf-8-sig', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=['case', 'k', 'ntask', 'ncand', 'T1', 'ms'])
    w.writeheader()
    w.writerows(rows)

for k in (2, 3, 4, 5):
    g = [r for r in rows if r['k'] == k]
    for th in (1, 3, 5, 8, 12, 20, 40):
        n = sum(1 for r in g if r['ncand'] >= th)
        print('k=%d  ncand>=%-3d : %d 个 (case,k)' % (k, th, n))
print()
print('全部 (case,k) 数:', len(rows))
print('ncand>=5 的清单（前 60）:')
for r in rows:
    if r['ncand'] >= 5:
        print('  %-16s k=%d ntask=%-4d ncand=%-4d ms=%d' % (
            r['case'], r['k'], r['ntask'], r['ncand'], r['ms']))
print('-> ', OUT)
