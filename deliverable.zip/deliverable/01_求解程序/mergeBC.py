"""mergeBC.py — 场景 B / 场景三：把增量跑批并按 makespan 取最优合并进基准目录。

与 mergeA.py 同理，但源数据是各目录的 summary_all.csv（append 模式，需按
"最后一次出现"去重，因为磁盘上的方案文件对应最后一次写入）。

用法：
    python mergeBC.py --base out/finalB --deltas out/runB --scene B
    python mergeBC.py --base out/final3 --deltas out/runC --scene 3
"""
from __future__ import annotations
import argparse, csv, os, shutil, sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
FL = ['case', 'k', 'T1', 'ms', 'speedup', 'added_copy_bytes', 'cache_hit_rate',
      'tag']


def read_last(d):
    """返回 {(case,k): row}，同一键取最后一行（对应磁盘上的方案）。"""
    p = os.path.join(d, 'summary_all.csv')
    out = {}
    if not os.path.exists(p):
        return out
    for r in csv.DictReader(open(p, encoding='utf-8-sig')):
        try:
            k = int(r['k'])
            ms = int(r['ms'])
        except (KeyError, ValueError):
            continue
        if ms <= 0 or not r.get('case'):
            continue
        out[(r['case'], k)] = dict(r, k=k, ms=ms)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--base', required=True)
    ap.add_argument('--deltas', nargs='+', required=True)
    ap.add_argument('--scene', default='B')
    args = ap.parse_args()

    best = read_last(args.base)
    print('基准 %-16s %4d 条' % (args.base, len(best)))
    for d in args.deltas:
        got = read_last(d)
        n = 0
        for key, r in got.items():
            if key not in best or r['ms'] < best[key]['ms']:
                best[key] = r
                r['_src'] = d
                n += 1
        print('增量 %-16s %4d 条，胜出 %d' % (d, len(got), n))

    ncopy = 0
    for key, r in best.items():
        src = r.get('_src')
        if not src:
            continue
        a = os.path.join(src, '%s_k%d.json' % (key[0][:-5], key[1]))
        b = os.path.join(args.base, '%s_k%d.json' % (key[0][:-5], key[1]))
        if not os.path.exists(a):
            print('  !! 缺方案', a)
            continue
        shutil.copyfile(a, b)
        ncopy += 1
    print('覆盖方案 %d 个' % ncopy)

    out = os.path.join(args.base, 'summary_all.csv')
    with open(out, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=FL)
        w.writeheader()
        for key in sorted(best, key=lambda z: (int(z[0][5:-5]), z[1])):
            r = best[key]
            w.writerow({x: r.get(x, '') for x in FL})
    byk = defaultdict(list)
    for key, r in best.items():
        byk[key[1]].append(float(r['speedup']) if r.get('speedup')
                           else float(r['T1']) / r['ms'])
    for k in sorted(byk):
        v = byk[k]
        print('scene %s k=%d n=%d mean=%.4f min=%.4f max=%.4f'
              % (args.scene, k, len(v), sum(v) / len(v), min(v), max(v)))
    print('-> ', out)


if __name__ == '__main__':
    main()
