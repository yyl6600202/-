"""status.py — 汇总当前各来源的平均加速比，确认交付口径。"""
import csv
import os
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
O = os.path.join(HERE, 'out')


def load(p, spcol='speedup', kcol='k'):
    if not os.path.exists(p):
        return None
    rows = list(csv.DictReader(open(p, encoding='utf-8-sig')))
    byk = defaultdict(list)
    for r in rows:
        try:
            s = float(r[spcol])
        except Exception:
            continue
        if s <= 0:
            continue
        byk[int(r[kcol])].append(s)
    return {k: (len(v), sum(v) / len(v)) for k, v in sorted(byk.items())}


def show(name, p):
    d = load(p)
    if d is None:
        print('%-34s MISSING' % name)
        return
    print('%-34s ' % name + '  '.join(
        'k%d n=%d %.4f' % (k, n, m) for k, (n, m) in d.items()))


F = os.path.join(O, 'final')
show('final/results_problem1.csv', os.path.join(F, 'results_problem1.csv'))
show('final/verified_A_test.csv', os.path.join(F, 'verified_A_test.csv'))
show('final/verified_B.csv', os.path.join(F, 'verified_B.csv'))
show('final/verified_3.csv', os.path.join(F, 'verified_3.csv'))
show('finalB/summary_all.csv', os.path.join(O, 'finalB', 'summary_all.csv'))
show('final3/summary_all.csv', os.path.join(O, 'final3', 'summary_all.csv'))
show('runC/summary_all.csv', os.path.join(O, 'runC', 'summary_all.csv'))
show('runB/summary_all.csv', os.path.join(O, 'runB', 'summary_all.csv'))
print()
for p in ['verA_rest.log']:
    q = os.path.join(O, p)
    if os.path.exists(q):
        ls = [x for x in open(q, encoding='utf-8', errors='replace').read().split('\n') if x.strip()]
        print(p, 'lines', len(ls), '| last:', ls[-1][:100])
import csv as _c
p = os.path.join(F, 'verified_A_rest.csv')
print('verified_A_rest.csv exists:', os.path.exists(p),
      len(open(p, encoding='utf-8-sig').read().split('\n')) - 1 if os.path.exists(p) else 0)
