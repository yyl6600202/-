"""verify_patch.py — 用加速版复算前期 100 个 5 核最优方案，与官方记录逐一比对。

这同时完成两件事：
  1) 验证内存补丁与官方评估器逐位一致（makespan 必须完全相同）；
  2) 给出加速后的实测耗时，用于后续搜索预算建模。
"""
import csv
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fl  # noqa: E402

PKG = r'C:\Users\xjw\Desktop\A题_交接包_5核优化\题目与附件\通用神经网络处理器下的多核调度问题  附件\day5_results'
PLANS = os.path.join(PKG, 'problem1_5core_plans')
SUMMARY = os.path.join(PKG, 'problem1_5core_optimized_summary.csv')


def main():
    ref = {}
    with open(SUMMARY, encoding='utf-8-sig', newline='') as f:
        for row in csv.DictReader(f):
            ref[row['case']] = row
    files = sorted(f for f in os.listdir(PLANS) if f.startswith('case_') and f.endswith('.json'))
    rows = []
    bad = 0
    t_all = time.time()
    for f in files:
        case = f
        stem = f[:-5]
        if stem not in ref:
            continue
        with open(os.path.join(PLANS, f), encoding='utf-8') as fh:
            plan = json.load(fh)
        g = fl.graph(case)
        t0 = time.time()
        try:
            r = fl.load_fast()['p1'].evaluate_scene_a(
                g, plan,
                bandwidth=fl.config()['bandwidth'], capacity=fl.config()['capacity'],
                cross_core_wait=fl.config()['cross_core_wait'],
                same_core_wait=fl.config()['same_core_wait'])
            ms = r['makespan']
            added = r['data_movement_bytes']['added_copy_bytes']
            err = ''
        except Exception as exc:  # noqa: BLE001
            ms, added, err = None, None, type(exc).__name__ + ':' + str(exc)[:80]
        dt = time.time() - t0
        want = int(ref[stem]['problem1_makespan'])
        ok = (ms == want)
        if not ok:
            bad += 1
        rows.append((stem, ms, want, ok, int(ref[stem]['n_ops'] if 'n_ops' in ref[stem] else 0), dt, err))
        print('%-10s our=%-12s official=%-12s %-4s %.2fs %s' % (
            stem, ms, want, 'OK' if ok else 'MISMATCH', dt, err), flush=True)
    total = time.time() - t_all
    print()
    print('cases=%d  mismatches=%d  total=%.1fs  mean=%.2fs' % (len(rows), bad, total, total / max(1, len(rows))))
    with open(os.path.join(HERE, 'out', 'verify_patch.json'), 'w', encoding='utf-8') as fh:
        json.dump({'mismatches': bad, 'rows': [
            {'case': a, 'ours': b, 'official': c, 'ok': d, 'ops': e, 'secs': round(g, 3), 'err': h}
            for a, b, c, d, e, g, h in rows]}, fh, indent=1)


if __name__ == '__main__':
    main()
