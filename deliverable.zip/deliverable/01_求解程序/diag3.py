"""diag3.py — 用官方（内存补丁版，逐位一致）评测器做**分解诊断**。

输出：makespan 的构成 —— 每核 Task 数、Σ local_makespan、同核/跨核等待、
边界搬运 / spill 搬运，以及理论下界。用来判断"下一步该优化什么"。
"""
from __future__ import annotations

import json
import os
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import fl  # noqa: E402

DATA = os.path.join(HERE, 'data')
PLANS = os.path.join(HERE, 'out', 'final', 'plans')


def diag(case, k):
    c = fl.load_fast()
    cfg = fl.config()
    g = fl.graph(case)
    pp = os.path.join(PLANS, '%s_k%d.json' % (case[:-5], k))
    plan = json.load(open(pp, encoding='utf-8'))
    r = c['p1'].evaluate_scene_a(
        g, plan, bandwidth=cfg['bandwidth'], capacity=cfg['capacity'],
        cross_core_wait=cfg['cross_core_wait'],
        same_core_wait=cfg['same_core_wait'])
    dm = r['data_movement_bytes']
    # 每核统计
    ntask = defaultdict(int)
    sum_local = defaultdict(int)
    max_local = defaultdict(int)
    for tid, d in r['step3_by_task'].items():
        pass
    # core_of task：从 core_orders 推
    core_of_task = {}
    sched = plan.get('core_schedules', [])
    for ci, sgs in enumerate(sched):
        for sg in sgs:
            core_of_task[sg] = ci
    for tid, d in r['step3_by_task'].items():
        ci = core_of_task.get(tid, 0)
        ntask[ci] += 1
        sum_local[ci] += d['local_makespan']
        max_local[ci] = max(max_local[ci], d['local_makespan'])
    # 每核原始算力负载
    n2s = plan['node_to_subgraph']
    pipeload = defaultdict(lambda: defaultdict(float))
    for op in g['ops']:
        if op.get('op') in ('COPY_IN', 'COPY_OUT'):
            continue
        sg = n2s.get(str(op['id']))
        if sg is None:
            continue
        pipeload[core_of_task.get(sg, 0)][op['pipe']] += op['cycles']
    tm = sum(v for pl in pipeload.values() for p, v in pl.items() if p == 'PIPE_M')
    tv = sum(v for pl in pipeload.values() for p, v in pl.items() if p == 'PIPE_V')
    t2 = sum(v for pl in pipeload.values() for p, v in pl.items() if p == 'PIPE_MTE2')
    t3 = sum(v for pl in pipeload.values() for p, v in pl.items() if p == 'PIPE_MTE3')
    print('==== %s k=%d' % (case, k))
    print('  makespan=%d  T1?  tasks=%d  cores_used=%d' % (
        r['makespan'], len(r['step3_by_task']),
        len({ci for ci in core_of_task.values()})))
    print('  traffic: partition_added=%d spill=%d added=%d orig=%d' % (
        dm.get('partition_added_copy_bytes', 0), dm.get('spill_added_copy_bytes', 0),
        dm.get('added_copy_bytes', 0), dm.get('original_graph_copy_bytes', 0)))
    print('  cross_task_traffic=%d  (=%d cyc at B=60)' % (
        r.get('cross_task_traffic', 0), r.get('cross_task_traffic', 0) // 60))
    print('  pipe totals: M=%d V=%d MTE2=%d MTE3=%d  -> per-core floor M/k=%.0f V/k=%.0f' % (
        tm, tv, t2, t3, tm / k, tv / k))
    lbw = max(tm, tv) / k
    print('  LB(work)=%.0f  ms/LB=%.3f' % (lbw, r['makespan'] / max(lbw, 1)))
    print('  %-4s %-7s %-14s %-14s %-10s %-10s' % (
        'core', 'ntask', 'sum_local(cyc)', 'rawM+rawV', 'peakL1', 'peakUB'))
    for ci in range(k):
        raw = sum(pipeload[ci].values())
        pk = r['memory_peak_by_core'].get(ci, {})
        print('  %-4d %-7d %-14d %-14.0f %-10d %-10d' % (
            ci, ntask[ci], sum_local[ci], raw,
            pk.get('L1', 0), pk.get('UB', 0)))
    # 每次同核切换 ~100 周期，跨核边 ~1000
    waits_same = sum(100 * max(0, ntask[ci] - 1) for ci in range(k))
    print('  same-core switch overhead total = %d cyc (Σ100·(n_t-1))' % waits_same)
    print()


if __name__ == '__main__':
    args = sys.argv[1:]
    ks = [5]
    cases = []
    for a in args:
        if a.startswith('k='):
            ks = [int(x) for x in a[2:].split(',')]
        else:
            cases.append(a if a.endswith('.json') else a + '.json')
    for case in cases:
        for k in ks:
            try:
                diag(case, k)
            except Exception as e:  # noqa: BLE001
                print('ERR', case, k, e)
