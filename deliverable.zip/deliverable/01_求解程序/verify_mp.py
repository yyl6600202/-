"""verify_mp.py — verify_final.py 的多进程版：用**未经补丁**的官方评估器并行复核。

与 verify_final.py 完全相同的评测口径（直接 import 官方
`multicore_cut_evaluate_problem_{1,2,3}`、`read_evaluation_config`、
`validate_multicore_plan`，不经过 fl.py 的加速补丁），只是把"逐用例"改成进程池，
以便在有限机时内完成 100 用例 × 4 核数 × 3 场景的发布级复核。

健壮性（重要）
--------------
结果**边跑边追加**写入 `--out`，并在正常结束时按 (用例号, k) 重排一次。
因此长跑过程被杀只损失未完成的用例，不会像早期版本那样"跑完才写盘、
中途被终止就整批丢失"（曾真实发生过：88/100 的一轮复核只留下日志）。
`--resume` 会读回已有 `--out`，跳过其中已出现的用例，实现断点续跑。

大图（JSON > 4 MB）内存占用高，建议单独一批、并发 2；中小图并发 4。

用法：
    python verify_mp.py --plans out/final/plans --scene A --out out/final/verified_A.csv \
                        --workers 4
    python verify_mp.py --plans out/final/plans --scene A --out out/final/verified_A.csv \
                        --workers 4 --resume        # 断点续跑
    python verify_mp.py --plans out/final/plans --scene A --out out/final/verified_A_big.csv \
                        --case-file out/wave_big.txt --workers 2
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.join(HERE, 'code')
DATA = os.path.join(HERE, 'data')
sys.path.insert(0, CODE)
sys.path.insert(0, HERE)

FIELDS = ['scene', 'case', 'k', 'T1', 'ms', 'speedup', 'added_copy_bytes',
          'cache_hit_rate']


def worker(job):
    case, ks, plans_dir, scene = job
    import multicore_cut_evaluate_problem_1 as P1
    import multicore_cut_evaluate_problem_2 as P2
    import multicore_cut_evaluate_problem_3 as P3
    from evaluation_validation import (read_evaluation_config,
                                       read_required_settings)
    from stub_multicore_cut_and_schedule import validate_multicore_plan

    cfgp = os.path.join(DATA, 'config.txt')
    s = read_evaluation_config(cfgp)
    wa = read_required_settings(
        cfgp, 'multicore_scene_a',
        ('task_cross_core_wait_cycles', 'task_same_core_wait_cycles'))
    wb = P2.read_scene_b_config(cfgp)
    cc = P3.read_cache_config(cfgp)

    t0 = time.time()
    try:
        g = json.load(open(os.path.join(DATA, case), encoding='utf-8'))
        t1 = P1.evaluate_scene_a(
            g, {'node_to_subgraph': {str(o['id']): 0 for o in g['ops']
                                     if o.get('op') not in ('COPY_IN', 'COPY_OUT')},
                'core_schedules': [[0]]},
            bandwidth=s['bandwidth'], capacity=s['capacity'],
            cross_core_wait=wa['task_cross_core_wait_cycles'],
            same_core_wait=wa['task_same_core_wait_cycles'])['makespan']
        rows, bad = [], []
        for k in ks:
            p = os.path.join(plans_dir, '%s_k%d.json' % (case[:-5], k))
            if not os.path.exists(p):
                continue
            plan = json.load(open(p, encoding='utf-8'))
            try:
                validate_multicore_plan(g, plan)
            except Exception as exc:  # noqa: BLE001
                bad.append((case, k, 'ILLEGAL', repr(exc)[:160]))
                continue
            try:
                if scene == 'A':
                    r = P1.evaluate_scene_a(
                        g, plan, bandwidth=s['bandwidth'],
                        capacity=s['capacity'],
                        cross_core_wait=wa['task_cross_core_wait_cycles'],
                        same_core_wait=wa['task_same_core_wait_cycles'])
                    hit = ''
                elif scene == 'B':
                    r = P2.evaluate_scene_b(
                        g, plan, bandwidth=s['bandwidth'],
                        capacity=s['capacity'],
                        cross_core_copy_delay=wb['cross_core_copy_delay_cycles'])
                    hit = ''
                else:
                    r = P3.evaluate_problem_3(
                        g, plan, bandwidth=s['bandwidth'],
                        capacity=s['capacity'],
                        cross_core_copy_delay=wb['cross_core_copy_delay_cycles'],
                        cache_capacity_bytes=cc['cache_capacity_bytes'],
                        cache_bandwidth_bytes_per_cycle=(
                            cc['cache_bandwidth_bytes_per_cycle']))
                    hit = '%.6f' % r['cache_stats'].get('hit_rate', 0.0)
            except Exception as exc:  # noqa: BLE001
                bad.append((case, k, 'EVAL_FAIL', repr(exc)[:160]))
                continue
            ms = r['makespan']
            rows.append(dict(scene=scene, case=case, k=k, T1=t1, ms=ms,
                             speedup=round(t1 / ms, 6),
                             added_copy_bytes=r['data_movement_bytes'][
                                 'added_copy_bytes'],
                             cache_hit_rate=hit))
        return {'ok': True, 'case': case, 'rows': rows, 'bad': bad,
                'line': '%-16s %d 条 (%.0fs)' % (case, len(rows),
                                                 time.time() - t0)}
    except Exception:  # noqa: BLE001
        import traceback
        return {'ok': False, 'case': case, 'err': traceback.format_exc()[-800:]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--plans', required=True)
    ap.add_argument('--scene', default='A', choices=['A', 'B', '3'])
    ap.add_argument('--out', required=True)
    ap.add_argument('--cases', nargs='*')
    ap.add_argument('--case-file', default=None)
    ap.add_argument('--ks', nargs='+', type=int, default=[2, 3, 4, 5])
    ap.add_argument('--workers', type=int, default=4)
    ap.add_argument('--resume', action='store_true',
                    help='读回 --out 中已有用例并跳过（断点续跑）')
    args = ap.parse_args()

    cases = args.cases or []
    if args.case_file:
        cases = [ln.strip() for ln in open(args.case_file, encoding='utf-8')
                 if ln.strip()]
    if not cases:
        cases = sorted({f.split('_k')[0] + '.json' for f in os.listdir(args.plans)
                        if f.startswith('case_') and f.endswith('.json')},
                       key=lambda s: int(s[5:-5]))
    jobs = [(c, args.ks, args.plans, args.scene) for c in cases]

    done_cases = set()
    if args.resume and os.path.exists(args.out):
        for r in csv.DictReader(open(args.out, encoding='utf-8-sig')):
            if r.get('case'):
                done_cases.add(r['case'])
        jobs = [j for j in jobs if j[0] not in done_cases]
        print('resume: %d 待跑 / 已完成 %d 例' % (len(jobs), len(done_cases)),
              flush=True)

    import multiprocessing as mp
    ctx = mp.get_context('spawn')
    rows, bad, n_ok = [], [], 0
    t0 = time.time()
    # 边跑边追加，避免长跑被杀导致整批结果丢失
    fout = open(args.out, 'a', encoding='utf-8-sig', newline='')
    wout = csv.DictWriter(fout, fieldnames=FIELDS)
    if not done_cases:
        wout.writeheader()
    fout.flush()
    pool = ctx.Pool(args.workers)
    try:
        for res in pool.imap_unordered(worker, jobs, chunksize=1):
            if not res['ok']:
                print('FAIL %s\n%s' % (res['case'], res['err']), flush=True)
                continue
            n_ok += 1
            rows.extend(res['rows'])
            bad.extend(res['bad'])
            for row in res['rows']:
                wout.writerow(row)
            fout.flush()
            print('%s  [%d/%d]' % (res['line'], n_ok, len(jobs)), flush=True)
    finally:
        pool.terminate()
        pool.join()
        fout.close()

    # 正常走完：按 (用例号, k) 重排一次，得到稳定可读的发布表
    if n_ok:
        allrows = []
        for r in csv.DictReader(open(args.out, encoding='utf-8-sig')):
            try:
                r['k'] = int(r['k'])
            except (KeyError, ValueError):
                continue
            allrows.append(r)
        allrows.sort(key=lambda r: (int(r['case'][5:-5]), r['k']))
        with open(args.out, 'w', encoding='utf-8-sig', newline='') as f:
            w = csv.DictWriter(f, fieldnames=FIELDS)
            w.writeheader()
            w.writerows(allrows)
        rows = allrows
        print('（已按用例号重排 %d 行，覆盖 %d 例）'
              % (len(allrows), len({r['case'] for r in allrows})))

    print('\n不合法/失败 %d 份' % len(bad))
    for b in bad[:20]:
        print('  ', b)
    from collections import defaultdict
    byk = defaultdict(list)
    for r in rows:
        byk[r['k']].append(r['speedup'])
    for k in sorted(byk):
        v = byk[k]
        print('scene %s k=%d n=%d mean=%.4f min=%.4f max=%.4f'
              % (args.scene, k, len(v), sum(v) / len(v), min(v), max(v)))
    print('-> %s  (%.0fs)' % (args.out, time.time() - t0))


if __name__ == '__main__':
    main()
