"""solve_final.py — 场景 A 主求解器 v3（借鉴参考模型：聚簇 → 装箱 → 落成 → 实测择优）。

流水线
------
1. 聚簇(units)：链式 / 重边匹配多级(H EM) / 弱连通分量 —— 多种粒度各算一遍；
2. 装箱(seeds)：LPT(max|sum|m4)、局部性贪心(多种 λ)、轮转、随机扰动的 K−1 核嵌套种子；
3. 落成(plan)：给定 算子→核 映射，令
       layer(o) = max_{p∈pred(o)} ( layer(p) + [core(p)≠core(o)] )
   按 (核, 层) 打包成子图，同核按层升序执行 ⇒ 商图必无环、同核顺序不违反依赖（合法性自动成立）；
4. 择优：用 px.proxy 快速代理做大量候选筛选与爬山，再用官方评估器精评 top 候选；
5. 嵌套：k 核候选里始终放入 "k−1 核最优 + 空核"，保证 M_1 ≥ M_2 ≥ … 与 S_1 ≤ S_2 ≤ …。
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import random
import sys
import time
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
DATA = os.path.join(HERE, 'data')

import fl              # noqa: E402
import fev             # noqa: E402
import opt as optmod   # noqa: E402
import px              # noqa: E402
import testmerge as TM  # noqa: E402

SCENE = ['A']


# ------------------------------------------------------------------ 视图
def attach_esz(V):
    gv = V.gv
    ts, out_t, in_t = gv.tensor_size, gv.out_t, gv.in_t
    esz = {}
    for o in V.ops:
        ot = out_t.get(o, ())
        if not ot:
            continue
        for s in V.succs[o]:
            st = set(in_t.get(s, ()))
            b = 0
            for tid in ot:
                if tid in st:
                    b += ts.get(tid, 0)
            esz[(o, s)] = float(b)
    V.esz = esz
    return V


def load_case(case):
    g = json.load(open(os.path.join(DATA, case), encoding='utf-8'))
    fev.set_graph(case, g)         # 让评估器直接复用这份解析结果（避免双份占内存）
    V = attach_esz(optmod.View(g))
    return V, g


# ------------------------------------------------------------------ 聚簇
def units_hem(V, target, wadd=1.0):
    """重边匹配多级聚簇：反复把边权最大的未匹配对合并，直到簇数 <= target。"""
    members = {o: [o] for o in V.ops}
    cur = {o: o for o in V.ops}
    n = len(V.ops)
    if target >= n:
        return [members[o] for o in list(members)]
    guard = 0
    while n > target and guard < 100:
        guard += 1
        w = defaultdict(float)
        for o in V.ops:
            co = cur[o]
            for s in V.succs[o]:
                cs = cur[s]
                if co != cs:
                    key = (co, cs) if co < cs else (cs, co)
                    w[key] += V.esz.get((o, s), 0.0) + wadd
        if not w:
            break
        edges = sorted(w.items(), key=lambda kv: -kv[1])
        used = set()
        for (a, b), _ww in edges:
            if a in used or b in used:
                continue
            if a not in members or b not in members:
                continue
            used.add(a)
            used.add(b)
            if len(members[a]) < len(members[b]):
                a, b = b, a
            members[a].extend(members.pop(b))
            for o in members[a]:
                cur[o] = a
            n -= 1
            if n <= target:
                break
    return list(members.values())


def units_components(V, chunk=None):
    return optmod.groups_components(V, chunk)


def units_split_from(V, chains, cap):
    """把 `chains`（in-tree 列表）中过大的组按组内拓扑序切成 <= cap 个算子的片。"""
    gid = {}
    for gi, grp in enumerate(chains):
        for o in grp:
            gid[o] = gi
    buckets = [[] for _ in chains]
    for o in V.topo:
        buckets[gid[o]].append(o)
    out = []
    for gi, grp in enumerate(chains):
        if len(grp) <= cap:
            out.append(grp)
            continue
        order = buckets[gi]
        for i in range(0, len(order), cap):
            out.append(order[i:i + cap])
    return out


def units_split(V, cap):
    """把"单前驱"聚出的 in-tree 按组内拓扑序切成 <= cap 个算子的片。

    动机（关键）：`groups_chains` 会把"每个节点恰有一个前驱"的整棵子树合成一个单元，
    实测会在若干用例上生成 900+ 算子的巨型单元；LPT 装箱无法再切它，只能整块压在一个核上，
    直接把加速比钉死在 1.0x 附近。按拓扑序切片后单元可自由分配，负载才摊得平。
    组内拓扑序保证"片内算子的前驱只会落在更早的片"，因此跨片边一律向前，不破坏无环性。
    """
    return units_split_from(V, optmod.groups_chains(V), cap)


# ------------------------------------------------------------------ 计划
def ocore_of(units, gc):
    ocore = {}
    for gi, ops in enumerate(units):
        c = gc[gi]
        for o in ops:
            ocore[o] = c
    return ocore


def plan_of(V, ocore, k):
    return TM.group_by_core_layer(V, ocore, k)


def seed_from_ocore(units, prev_ocore, k):
    """把外来方案（上一核数最优 / 别的场景最优）按"多数票"投影到当前粒度上，
    作为当前 (核数, 场景) 的一个种子。只要把新增核留空，该种子就与外来方案一致。"""
    gc = []
    for ops in units:
        cnt = defaultdict(int)
        for o in ops:
            cnt[prev_ocore.get(o, 0)] += 1
        c = max(cnt.items(), key=lambda kv: (kv[1], -kv[0]))[0]
        gc.append(c if c < k else k - 1)
    return gc


def split_plan_ops(V, plan, max_ops):
    """把方案里每个超大 Task（子图）按**全局拓扑序**切成 <= max_ops 的连续片。

    动机：按 (核, 层) 打包时，一棵"全程同核"的大子树会整体落在同一层 ⇒ 成为一个
    巨型 Task；巨型 Task 的活跃张量集很大，核内调度第 2 步会大量换出/换入（spill），
    DDR 流量激增。切成小片后 spill 显著下降，代价是新增跨子图边界搬运。
    跨片边一律向前、同核顺序按原顺序拼接 ⇒ 方案恒合法。
    """
    n2s = plan['node_to_subgraph']
    sched = plan['core_schedules']
    sg_ops = defaultdict(list)
    for o in V.ops:
        sg = n2s.get(str(o))
        if sg is not None:
            sg_ops[sg].append(o)
    pos = getattr(V, '_pos', None)
    if pos is None:
        pos = {o: i for i, o in enumerate(V.topo)}
        V._pos = pos
    mapping, new_sched, nxt = {}, [], 0
    for sgs in sched:
        row = []
        for sg in sgs:
            ops = sg_ops.get(sg)
            if not ops:
                continue
            ops.sort(key=lambda o: pos[o])
            if len(ops) <= max_ops:
                pieces = [ops]
            else:
                cnt = (len(ops) + max_ops - 1) // max_ops
                size = (len(ops) + cnt - 1) // cnt
                pieces = [ops[i:i + size] for i in range(0, len(ops), size)]
            for pc in pieces:
                for o in pc:
                    mapping[str(o)] = nxt
                row.append(nxt)
                nxt += 1
        new_sched.append(row)
    return {'node_to_subgraph': mapping, 'core_schedules': new_sched}


def ocore_from_plan(V, plan):
    """从已保存的多核方案文件还原 算子→核 映射。"""
    n2s = plan.get('node_to_subgraph', {})
    s2c = {}
    for ci, sgs in enumerate(plan.get('core_schedules', [])):
        for sg in sgs:
            s2c[sg] = ci
    out = {}
    for o in V.ops:
        sg = n2s.get(str(o))
        if sg is None:
            continue
        out[o] = s2c.get(sg, 0)
    return out


# ------------------------------------------------------------------ 代理爬山
def proxy_descent(V, units, gc, k, budget_s, rng, max_sweeps=40, max_units=320):
    """代理爬山。单元数过多时只对"负载最大的前 max_units 个"做全核扫描，
    其余冻结——否则 n×k 次代理评估会把时间吃光（大图 n 可达上万）。"""
    t0 = time.time()
    n = len(units)
    cur = list(gc)
    cur_p = px.proxy(V, ocore_of(units, cur), k)
    best_p = cur_p
    best = list(cur)
    gl = [V.m_v(u) for u in units]
    pool = sorted(range(n), key=lambda i: -max(gl[i]))[:max_units]
    stalls = 0
    for _sweep in range(max_sweeps):
        if time.time() - t0 > budget_s:
            break
        improved = False
        order = list(pool)
        rng.shuffle(order)
        for i in order:
            if time.time() - t0 > budget_s:
                break
            base = cur[i]
            lb, lc = cur_p, base
            for c in range(k):
                if c == base:
                    continue
                cur[i] = c
                p = px.proxy(V, ocore_of(units, cur), k)
                if p < lb - 1e-9:
                    lb, lc = p, c
            cur[i] = lc
            if lb < cur_p - 1e-9:
                cur_p = lb
                improved = True
                if cur_p < best_p:
                    best_p, best = cur_p, list(cur)
        if not improved:
            stalls += 1
            if stalls >= 1:
                break
    return best, best_p


# ------------------------------------------------------------------ 精评爬山
def exact_descent(V, units, loads, gc, k, ev, budget_s, t0_case, max_sweeps=6):
    t0 = time.time()
    n = len(units)
    cur = list(gc)
    cur_ms = ev(plan_of(V, ocore_of(units, cur), k))
    best_ms, best = cur_ms, list(cur)
    stalls = 0
    for _sweep in range(max_sweeps):
        if time.time() - t0 > budget_s or time.time() - t0_case > 6 * budget_s:
            break
        improved = False
        # 只对负载最大的若干单元做全核扫描，控制评估次数
        order = sorted(range(n), key=lambda i: -max(loads[i]))
        order = order[:max(6, min(120, n // 3))]
        for i in order:
            if time.time() - t0 > budget_s or time.time() - t0_case > 6 * budget_s:
                break
            base = cur[i]
            lb, lc = cur_ms, base
            for c in range(k):
                if c == base:
                    continue
                cur[i] = c
                ms = ev(plan_of(V, ocore_of(units, cur), k))
                if ms < lb:
                    lb, lc = ms, c
            cur[i] = lc
            if lb < cur_ms:
                cur_ms = lb
                improved = True
                if cur_ms < best_ms:
                    best_ms, best = cur_ms, list(cur)
        if not improved:
            stalls += 1
            if stalls >= 1:
                break
    return best, best_ms


def lower_bound(V, k, B=60.0):
    """核负载下界（代理可用）：max(总 M/k, 总 V/k) + 原始 DDR 搬运/B。"""
    tm = tv = 0
    ddr = 0.0
    for o in V.ops:
        if V.pipe[o] == 'PIPE_M':
            tm += V.cyc[o]
        else:
            tv += V.cyc[o]
    # 原图 DDR 输入/输出：pos=='DDR' 的张量至少被搬一次
    ts = V.gv.tensor_size
    for t in V.g['tensors']:
        if t.get('pos') == 'DDR':
            ddr += ts.get(t['id'], 0)
    return max(tm / k, tv / k) + ddr / B


# ------------------------------------------------------------------ 单案例
def run_case(case, ks, budget_s, seed=12345, seed_dir=None, max_evals=64,
             split_caps=(0, 4000, 1500, 600, 250, 100, 40)):
    V, g = load_case(case)
    t1, _add, dt1 = fev.evaluate(case, fl.single_plan(g), scene=SCENE[0],
                                 timing=True)
    t1 = int(t1)

    def ev(plan):
        return fev.evaluate(case, plan, scene=SCENE[0])[0]

    # 单次精评实测成本 → 决定搜索策略（大图只能靠代理，精评次数必须少）
    per_eval = max(dt1, 0.05)
    heavy = per_eval > 1.2

    nops = len(V.ops)
    # 多粒度候选：由细到粗（细粒度是打破"巨型单元"瓶颈的关键）
    chains = optmod.groups_chains(V)
    variants = [('chain', chains)]
    for cap in (4, 8, 16, 32, 64, 128, 256):
        if cap < nops - 1:
            variants.append(('split%d' % cap, units_split_from(V, chains, cap)))
    for ch in (1, 2, 4, 8, 16, 32, 64):
        variants.append(('comp%d' % ch, optmod.groups_components(V, ch)))
    tgt1 = max(8, min(nops // 16, 260))
    tgt2 = max(6, min(nops // 48, 90))
    if nops <= 12000:
        if tgt1 < nops - 2:
            variants.append(('hem%d' % tgt1, units_hem(V, tgt1)))
        if tgt2 < nops - 2:
            variants.append(('hem%d' % tgt2, units_hem(V, tgt2)))
    variants.append(('compall', optmod.groups_components(V, None)))
    # 去重（不同 cap 可能给出相同划分）
    seen = set()
    uniq = []
    for name, units in variants:
        sig = tuple(sorted(len(u) for u in units))
        key = (len(units), sig)
        if key in seen:
            continue
        seen.add(key)
        uniq.append((name, units))
    variants = uniq

    rng = random.Random(seed)
    t0 = time.time()
    prev_ocore = None
    out = []
    for k in ks:
        if k == 1:
            out.append(dict(case=case, k=1, T1=t1, ms=t1, sp=1.0, tag='single',
                            evals=0, secs=0.0, plan=fl.single_plan(g)))
            continue
        best_ms = None
        best_gc = None
        best_units = None
        best_loads = None
        best_tag = ''
        best_plan = None
        nev = [0]
        lbk = lower_bound(V, k)

        def evc(plan):
            nev[0] += 1
            return ev(plan)

        def take(ms, plan, tag, units=None, gc=None, gl=None):
            nonlocal best_ms, best_plan, best_tag, best_units, best_gc, best_loads
            if best_ms is None or ms < best_ms:
                best_ms, best_plan, best_tag = ms, plan, tag
                best_units, best_gc, best_loads = units, gc, gl

        # 复用外部场景/前一轮已求得的方案（例如用问题一的解直接喂给问题二、三）
        seed_oc = None
        ext_plan = None
        if seed_dir:
            sp_ = os.path.join(seed_dir, '%s_k%d.json' % (case[:-5], k))
            if os.path.exists(sp_):
                try:
                    ext_plan = json.load(open(sp_, encoding='utf-8'))
                    seed_oc = ocore_from_plan(V, ext_plan)
                except Exception:  # noqa: BLE001
                    ext_plan, seed_oc = None, None
        if ext_plan is not None:
            try:
                take(evc(ext_plan), ext_plan, 'reuse/plan')
            except Exception:  # noqa: BLE001
                ext_plan = None

        # 第一阶段：把所有 (粒度 × 种子) 候选按代理排序，取前 N 个做真实精评。
        # 代理只估"算力 + 边界搬运"，估不准 spill / partition 的真实代价，
        # 因此必须给出足够多的真实精评名额，而不能只评每个粒度的一个种子。
        allc = []
        for name, units in variants:
            gl = [V.m_v(u) for u in units]
            seeds = [('lpt_max', optmod.lpt(gl, k, 'max')),
                     ('lpt_sum', optmod.lpt(gl, k, 'sum')),
                     ('lpt_m4', optmod.lpt(gl, k, 'm4'))]
            for lam in (2000, 10000, 50000, 200000):
                seeds.append(('loc%d' % lam,
                              optmod.seed_locality(V, units, gl, k, lam)))
            if seed_oc is not None:
                seeds.append(('reuse', seed_from_ocore(units, seed_oc, k)))
            if prev_ocore is not None:
                seeds.append(('nest', seed_from_ocore(units, prev_ocore, k)))
            for tag, gc in seeds:
                allc.append((px.proxy(V, ocore_of(units, gc), k),
                             name, units, gl, tag, gc))
        allc.sort(key=lambda z: z[0])
        # 自适应精评：用**时间预算**而不是预估次数，因为方案的真实评测成本随核内
        # spill 剧烈变化（单核评测耗时往往会低估坏方案的代价）。
        evaluated = []
        deadline = time.time() + budget_s * 0.55
        for p0, name, units, gl, tag0, gc0 in allc:
            if len(evaluated) >= max_evals:
                break
            if len(evaluated) >= 3 and time.time() > deadline:
                break
            plan = plan_of(V, ocore_of(units, gc0), k)
            ms = evc(plan)
            evaluated.append((ms, name, units, gl, tag0, gc0))
            take(ms, plan, tag0 + '/' + name, units, list(gc0), gl)

        # 第二阶段：对胜出的粒度做代理爬山 + 精评爬山
        win = min(evaluated, key=lambda x: x[0])
        _ms0, name, units, gl, tag0, gc0 = win
        gcp, _pp = proxy_descent(V, units, gc0, k, budget_s * 0.6, rng)
        plan = plan_of(V, ocore_of(units, gcp), k)
        take(evc(plan), plan, 'pdesc/' + name, units, list(gcp), gl)
        if best_ms > lbk * 1.02 and not heavy:
            gce, mse = exact_descent(V, units, gl, gcp, k, evc,
                                     max(6.0, budget_s), t0)
            if mse < best_ms:
                take(mse, plan_of(V, ocore_of(units, gce), k),
                     'xdesc/' + name, units, list(gce), gl)

        # 第三阶段：超大 Task 再切分（缓解核内换出/换入主导的用例）
        if best_plan is not None and split_caps:
            got = False
            for cap in split_caps:
                if cap <= 0:
                    continue
                if time.time() - t0 > 8 * budget_s:
                    break
                try:
                    plan2 = split_plan_ops(V, best_plan, cap)
                except Exception:  # noqa: BLE001
                    continue
                ms2 = evc(plan2)
                if ms2 < best_ms:
                    best_ms, best_plan = ms2, plan2
                    best_tag = best_tag + '|scap%d' % cap
                    got = True
            if got:
                best_units, best_gc = None, None
        prev_ocore = (ocore_of(best_units, best_gc) if best_units is not None
                      else (seed_oc or {}))
        out.append(dict(case=case, k=k, T1=t1, ms=best_ms, sp=t1 / best_ms,
                        tag=best_tag, evals=nev[0], secs=round(time.time() - t0, 1),
                        plan=best_plan))

    # 单调化：k 核必然可以"空置一核"来无损模拟 k−1 核方案，故 M_k ≤ M_{k−1} 必须成立。
    # 若搜索没找到更好的，就退回更少核的最优方案，并把 core_schedules 补齐到 k 项。
    _monotonize(out, k_target=max(ks))
    return out


def _monotonize(out, k_target):
    prev = None
    for r in out:
        if r['k'] == 1:
            prev = (r['ms'], r['plan'])
            continue
        if prev is not None and r['ms'] > prev[0]:
            plan = {'node_to_subgraph': dict(prev[1]['node_to_subgraph']),
                    'core_schedules': [list(x) for x in prev[1]['core_schedules']]}
            while len(plan['core_schedules']) < r['k']:
                plan['core_schedules'].append([])
            r['plan'] = plan
            r['ms'] = prev[0]
            r['sp'] = r['T1'] / r['ms']
            r['tag'] = r['tag'] + '|mono<-k'
        prev = (r['ms'], r['plan'])


def worker(job):
    """在子进程内直接落盘，只把极小的统计串回传 —— 避免大对象经 IPC 被父进程反序列化（曾致 OOM）。"""
    case, ks, budget_s, seed, outdir, scene, seed_dir, max_evals, split_caps = job
    SCENE[0] = scene
    t0 = time.time()
    try:
        rows = run_case(case, ks, budget_s, seed, seed_dir=seed_dir,
                        max_evals=max_evals, split_caps=split_caps)
        recs = []
        for r in rows:
            p = os.path.join(outdir, '%s_k%d.json' % (r['case'][:-5], r['k']))
            with open(p, 'w', encoding='utf-8') as f:
                json.dump(r['plan'], f)
            recs.append(dict(case=r['case'], k=r['k'], T1=r['T1'],
                             ms=r['ms'], speedup=round(r['sp'], 6),
                             tag=r['tag'], evals=r['evals'],
                             secs=round(time.time() - t0, 1)))
        return {'ok': True, 'case': case,
                'line': '%-16s %s (%.0fs)' % (
                    case, ' '.join('k%d=%.3f' % (r['k'], r['sp']) for r in rows),
                    time.time() - t0),
                'recs': recs}
    except Exception:  # noqa: BLE001
        import traceback
        return {'ok': False, 'case': case, 'err': traceback.format_exc()[-1500:]}


SUMMARY_FIELDS = ['case', 'k', 'T1', 'ms', 'speedup', 'tag', 'evals', 'secs']


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--cases', nargs='*')
    ap.add_argument('--case-file', default=None,
                    help='从文件读案例名（每行一个，避免命令行传参的 shell 依赖）')
    ap.add_argument('--ks', nargs='+', type=int, default=[2, 3, 4, 5])
    ap.add_argument('--out', required=True)
    ap.add_argument('--budget', type=float, default=12.0)
    ap.add_argument('--workers', type=int, default=5)
    ap.add_argument('--seed', type=int, default=12345)
    ap.add_argument('--scene', default='A', choices=['A', 'B', '3'],
                    help='A=问题一, B=问题二, 3=问题三（只读 L2 Cache）')
    ap.add_argument('--seed-dir', default=None,
                    help='复用该目录下已求得的 <case>_k<k>.json 方案作为候选种子')
    ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--max-evals', type=int, default=64,
                    help='每个 (用例, 核数) 允许的真实精评次数上限')
    ap.add_argument('--split-caps', nargs='+', type=int,
                    default=[0, 4000, 1500, 600, 250, 100, 40],
                    help='超大 Task 再切分的算子数阈值（0 表示不切分）')
    ap.add_argument('--resume', action='store_true',
                    help='跳过输出目录里已存在全部 k 的案例')
    args = ap.parse_args()
    SCENE[0] = args.scene

    cases = args.cases or []
    if args.case_file:
        cases = [ln.strip() for ln in open(args.case_file, encoding='utf-8')
                 if ln.strip()]
    if not cases:
        cases = sorted(
            (f for f in os.listdir(DATA)
             if f.startswith('case_') and f.endswith('.json')
             and f[5:-5].isdigit()), key=lambda s: int(s[5:-5]))
    if args.limit:
        cases = cases[:args.limit]
    os.makedirs(args.out, exist_ok=True)

    if args.resume:
        keep = []
        for c in cases:
            base = c[:-5]
            if all(os.path.exists(os.path.join(args.out, '%s_k%d.json' % (base, k)))
                   for k in args.ks):
                continue
            keep.append(c)
        print('resume: %d 待跑 / %d 总计' % (len(keep), len(cases)), flush=True)
        cases = keep

    jobs = [(c, args.ks, args.budget, args.seed, args.out, args.scene,
             args.seed_dir, args.max_evals, tuple(args.split_caps))
            for c in cases]

    # 汇总文件：增量追加，崩溃也不丢已完成部分
    sp = os.path.join(args.out, 'summary_all.csv')
    new_file = not os.path.exists(sp)
    fsum = open(sp, 'a', encoding='utf-8-sig', newline='')
    wsum = csv.DictWriter(fsum, fieldnames=SUMMARY_FIELDS)
    if new_file:
        wsum.writeheader()
        fsum.flush()

    import multiprocessing as mp
    ctx = mp.get_context('spawn')
    n_ok = 0
    t_start = time.time()
    pool = ctx.Pool(args.workers)
    try:
        for res in pool.imap_unordered(worker, jobs, chunksize=1):
            if not res['ok']:
                print('FAIL %s\n%s' % (res['case'], res['err']), flush=True)
                continue
            n_ok += 1
            for rec in res['recs']:
                wsum.writerow(rec)
            fsum.flush()
            print('%s  [%d/%d]' % (res['line'], n_ok, len(jobs)), flush=True)
    finally:
        pool.terminate()
        pool.join()
        fsum.close()

    # 汇总统计
    rows_all = list(csv.DictReader(open(sp, encoding='utf-8-sig')))
    byk = defaultdict(list)
    for r in rows_all:
        byk[int(r['k'])].append(float(r['speedup']))
    print('')
    for k in sorted(byk):
        v = byk[k]
        print('k=%d  n=%d  mean=%.4f  min=%.4f  max=%.4f' % (
            k, len(v), sum(v) / len(v), min(v), max(v)))
    print('summary -> %s ; 本轮 %.1fs' % (sp, time.time() - t_start))


if __name__ == '__main__':
    main()
