"""诊断：逐算例计算 5 核理论下界，与前期已达加速比对比，定位差距来源。

下界（对任意合法方案都成立）：
  LB_k = max( cpl_compute , W_M/k , W_V/k , DDR_min/bandwidth )
其中
  cpl_compute : 计算图（不含 COPY）按 cycles 加权的最长路径；任何方案都 >= 它
  W_M, W_V    : PIPE_M / PIPE_V 的总周期；单核内同 Pipe 串行，k 核各自一份 -> >= W/k
  DDR_min     : 原图 COPY_IN 输出 + COPY_OUT 输入 字节数；DDR 搬运只多不少 -> >= DDR_min
加速比上界 = T1 / LB_k
"""
import json, os, sys, math, statistics
from collections import defaultdict, Counter

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data')
BW = 60
K = 5

def load(p):
    with open(p, encoding='utf-8') as f:
        return json.load(f)

def features(g):
    ops = g['ops']; tensors = g['tensors']; edges = g['edges']
    op_ids = {o['id'] for o in ops}
    t_by_id = {t['id']: t for t in tensors}
    op_by_id = {o['id']: o for o in ops}
    in_t = defaultdict(list); out_t = defaultdict(list)
    for e in edges:
        s, d = e['source'], e['target']
        if s in op_ids and d not in op_ids: out_t[s].append(d)
        elif s not in op_ids and d in op_ids: in_t[d].append(s)
    producers = defaultdict(set)
    for oid, tids in out_t.items():
        for tid in tids: producers[tid].add(oid)
    preds = {o['id']: set() for o in ops}
    for oid, tids in in_t.items():
        for tid in tids:
            for p in producers.get(tid, ()):
                if p != oid: preds[oid].add(p)

    W = Counter()
    for o in ops: W[o['pipe']] += o.get('cycles', 0)
    # 原图 DDR 搬运字节
    ddr_bytes = 0
    for o in ops:
        if o['op'] == 'COPY_IN':
            ddr_bytes += sum(t_by_id[t]['size'] for t in out_t.get(o['id'], []))
        elif o['op'] == 'COPY_OUT':
            ddr_bytes += sum(t_by_id[t]['size'] for t in in_t.get(o['id'], []))

    # 最长路径（cycles 加权）；COPY cycles=0，但按 size/BW 计入搬运时间更真实
    order = topo(ops, preds)
    dist = {}
    for oid in order:
        base = 0.0
        o = op_by_id[oid]
        if o['op'] == 'COPY_IN':
            base = sum(t_by_id[t]['size'] for t in out_t.get(oid, [])) / BW
        elif o['op'] == 'COPY_OUT':
            base = sum(t_by_id[t]['size'] for t in in_t.get(oid, [])) / BW
        else:
            base = o.get('cycles', 0)
        best = 0.0
        for s in preds[oid]:
            best = max(best, dist[s])
        dist[oid] = best + base
    cpl = max(dist.values()) if dist else 0.0
    # 纯计算关键路径（不含搬运时间）
    distc = {}
    for oid in order:
        o = op_by_id[oid]
        base = 0 if o['op'] in ('COPY_IN', 'COPY_OUT') else o.get('cycles', 0)
        best = 0.0
        for s in preds[oid]:
            best = max(best, distc[s])
        distc[oid] = best + base
    cpl_c = max(distc.values()) if distc else 0.0

    total = sum(o.get('cycles', 0) for o in ops)
    return dict(n_ops=len(ops), total=total, WM=W['PIPE_M'], WV=W['PIPE_V'],
                ddr_bytes=ddr_bytes, cpl=cpl, cpl_c=cpl_c,
                ddr_cycles=ddr_bytes / BW)

def topo(ops, preds):
    succ = defaultdict(set)
    indeg = {o['id']: 0 for o in ops}
    for o in ops:
        for p in preds[o['id']]:
            succ[p].add(o['id']); indeg[o['id']] += 1
    ready = sorted([i for i, d in indeg.items() if d == 0])
    out = []
    while ready:
        u = ready.pop(0); out.append(u)
        for v in sorted(succ[u]):
            indeg[v] -= 1
            if indeg[v] == 0: ready.append(v)
    return out

if __name__ == '__main__':
    base = {}
    bp = os.path.join(HERE, 'out', 'baseline.json')
    if os.path.exists(bp):
        base = load(bp)
    prev = {}
    import csv
    prevcsv = r'C:\Users\xjw\Desktop\A题_交接包_5核优化\题目与附件\通用神经网络处理器下的多核调度问题  附件\day5_results\problem1_5core_optimized_summary.csv'
    if os.path.exists(prevcsv):
        with open(prevcsv, encoding='utf-8-sig', newline='') as f:
            for row in csv.DictReader(f):
                key = row['case']
                if not key.endswith('.json'):
                    key = key + '.json'
                prev[key] = row

    files = sorted(f for f in os.listdir(DATA) if f.startswith('case_') and f.endswith('.json'))
    rows = []
    for f in files:
        g = load(os.path.join(DATA, f))
        ft = features(g)
        T1 = None
        if f in base: T1 = base[f]['makespan']
        elif f in prev: T1 = int(prev[f]['baseline_makespan'])
        lb = max(ft['cpl'], ft['WM'] / K, ft['WV'] / K, ft['ddr_cycles'])
        spd_ub = (T1 / lb) if (T1 and lb > 0) else None
        ach = None
        if f in prev:
            try: ach = float(prev[f]['speedup'])
            except Exception: ach = None
        rows.append(dict(case=f, n_ops=ft['n_ops'], T1=T1,
                         WM=ft['WM'], WV=ft['WV'], ddr=ft['ddr_bytes'],
                         cpl=int(ft['cpl']), cpl_c=int(ft['cpl_c']),
                         ddr_cyc=int(ft['ddr_cycles']),
                         lb=int(lb), spd_ub=(round(spd_ub, 3) if spd_ub else None),
                         achieved=ach,
                         cls=(prev[f]['graph_class'] if f in prev else '')))

    # 输出
    lines = []
    hdr = '{:>10} {:>6} {:>10} {:>9} {:>9} {:>9} {:>9} {:>9} {:>9} {:>7} {:>7} {:>12}'.format(
        'case', 'ops', 'T1', 'WM/5', 'WV/5', 'ddr_cyc', 'cpl', 'LB', 'T1/LB', 'achie', 'gap', 'class')
    lines.append(hdr)
    for r in rows:
        lines.append('{:>10} {:>6} {:>10} {:>9} {:>9} {:>9} {:>9} {:>9} {:>9} {:>7} {:>7} {:>12}'.format(
            r['case'], r['n_ops'], r['T1'] if r['T1'] else '-',
            int(r['WM'] / K), int(r['WV'] / K), r['ddr_cyc'], r['cpl'], r['lb'],
            r['spd_ub'] if r['spd_ub'] else '-',
            r['achieved'] if r['achieved'] is not None else '-',
            (round(r['spd_ub'] - r['achieved'], 2) if (r['spd_ub'] and r['achieved']) else '-'),
            r['cls']))
    ubs = [r['spd_ub'] for r in rows if r['spd_ub']]
    achs = [r['achieved'] for r in rows if r['achieved'] is not None]
    lines.append('')
    lines.append('n=%d  mean UB=%.3f  mean achieved=%.3f  mean gap=%.3f' % (
        len(rows), statistics.mean(ubs), statistics.mean(achs),
        statistics.mean(ubs) - statistics.mean(achs)))
    # 下界主因统计
    cause = Counter()
    for r in rows:
        cands = {'cpl': r['cpl'], 'WM/5': r['WM']/K, 'WV/5': r['WV']/K, 'ddr': r['ddr_cyc']}
        cause[max(cands, key=cands.get)] += 1
    lines.append('LB 主因: ' + str(dict(cause)))
    open(os.path.join(HERE, 'out', 'bounds.txt'), 'w', encoding='utf-8').write('\n'.join(lines))
    print('\n'.join(lines[-6:]))
