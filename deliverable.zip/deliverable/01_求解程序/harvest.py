"""harvest.py — 收割"散落在各跑批目录里、只有方案文件没有汇总表"的更优方案。

起因：一次跑批在"方案已落盘、汇总表尚未写出"时中断，导致 out/mgA、out/mg_probe、
out/litplans 里存在未被合并的改进方案。本脚本对给定目录下的每个 <case>_k<K>.json
用等价加速版评估器现场复算 makespan，与 out/final/results_problem1.csv 逐条比对，
更优则覆盖方案并更新基表。

用法：
    python harvest.py --final out/final --dirs out/mgA out/mg_probe out/litplans out/tworst
"""
from __future__ import annotations
import argparse, csv, os, shutil, sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
DATA = os.path.join(HERE, 'data')
FIELDS = ['case', 'k', 'T1', 'ms', 'speedup', 'tag', 'src']


def _job(job):
    case, k, path = job
    import json
    import fl
    fl.load_fast()
    fl.config()
    g = json.load(open(os.path.join(DATA, case), encoding='utf-8'))
    fl.set_graph(case, g)
    try:
        ms, _add, _ = fl.eval_p1(case, json.load(open(path, encoding='utf-8')))
        return case, k, int(ms), path
    except Exception:  # noqa: BLE001
        return case, k, -1, path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--final', default='out/final')
    ap.add_argument('--dirs', nargs='+', required=True)
    ap.add_argument('--workers', type=int, default=4)
    args = ap.parse_args()

    F = os.path.join(HERE, args.final)
    base_csv = os.path.join(F, 'results_problem1.csv')
    rows = list(csv.DictReader(open(base_csv, encoding='utf-8-sig')))
    base = {(r['case'], int(r['k'])): r for r in rows}

    jobs = []
    for d in args.dirs:
        p = os.path.join(HERE, d)
        if not os.path.isdir(p):
            print('skip(缺失) %s' % d)
            continue
        n = 0
        for fn in sorted(os.listdir(p)):
            if not fn.endswith('.json') or '_k' not in fn:
                continue
            stem, ks = fn[:-5].rsplit('_k', 1)
            if not (stem.startswith('case_') and ks.isdigit()):
                continue
            case = stem + '.json'
            if (case, int(ks)) not in base:
                continue
            jobs.append((case, int(ks), os.path.join(p, fn)))
            n += 1
        print('候选 %-22s %4d 份方案' % (d, n))
    print('待复算 %d 份' % len(jobs))

    import multiprocessing as mp
    got = {}
    with mp.get_context('spawn').Pool(args.workers) as pool:
        for case, k, ms, path in pool.imap_unordered(_job, jobs, chunksize=1):
            if ms <= 0:
                print('  !! 复算失败', case, k, path)
                continue
            prev = got.get((case, k))
            if prev is None or ms < prev[0]:
                got[(case, k)] = (ms, path)

    pdir = os.path.join(F, 'plans')
    ncopy = saved = 0
    for (case, k), (ms, path) in sorted(got.items(),
                                        key=lambda kv: (int(kv[0][0][5:-5]), kv[0][1])):
        old = base[(case, k)]
        old_ms = int(old['ms'])
        if ms >= old_ms:
            continue
        shutil.copyfile(path, os.path.join(pdir, '%s_k%d.json' % (case[:-5], k)))
        t1 = int(old['T1'])
        old.update(ms=str(ms), speedup='%.6f' % (t1 / ms), tag='harvest',
                   src=os.path.relpath(os.path.dirname(path), HERE))
        ncopy += 1
        saved += old_ms - ms
        print('  %-16s k=%d  %d -> %d  (%+.2f%%)'
              % (case, k, old_ms, ms, (old_ms - ms) / old_ms * 100))
    print('覆盖 %d 条，makerspan 合计下降 %d' % (ncopy, saved))

    if ncopy:
        with open(base_csv, 'w', encoding='utf-8-sig', newline='') as f:
            w = csv.DictWriter(f, fieldnames=FIELDS)
            w.writeheader()
            w.writerows(rows)
    byk = defaultdict(list)
    for r in rows:
        byk[int(r['k'])].append(float(r['speedup']))
    for k in sorted(byk):
        v = byk[k]
        print('k=%d n=%d mean=%.4f min=%.4f max=%.4f'
              % (k, len(v), sum(v) / len(v), min(v), max(v)))
    print('-> ', base_csv)


if __name__ == '__main__':
    main()
