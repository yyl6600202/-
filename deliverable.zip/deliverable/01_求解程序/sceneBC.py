"""sceneBC.py — 场景 B（问题二）/ 场景 3（问题三）的"复用 + 官方精评"通道。

为什么可以复用问题一的方案
--------------------------
三个场景共用同一份方案文件结构（`node_to_subgraph` + `core_schedules`），
差别只在评测口径：
    · 问题一：每个子图是一个 Task；跨核前驱等 1000 cyc；跨子图数据经 DDR；
    · 问题二：每核的全部子图合并为一个 Task；跨核 COPY_OUT/COPY_IN + 500 cyc 同步；
    · 问题三：同问题二，另加只读 FIFO L2 Cache（1 MB @ 250 B/cyc）。
单核基准 T1 三场景完全相同（单核方案无任何跨核搬运）。
由于问题二的跨核代价（500 cyc）严格小于问题一（1000 cyc），同一份方案在场景 B 下
实测 makespan 通常优于场景 A —— 这是一个**合法且免费**的高质量基线：
只要再用官方评估器实测并按 M_k ≤ M_{k-1} 单调化，就能直接作为问题二/三的提交结果，
同时可作为后续真实搜索（solve_final.py --scene B --seed-dir ...）的种子。

用法：
    python sceneBC.py --scene B --src out/final/plans --t1 out/final/results_problem1.csv \
                      --out out/finalB --workers 4
    python sceneBC.py --scene 3 --src out/final/plans --t1 out/final/results_problem1.csv \
                      --out out/final3 --workers 4
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import fev  # noqa: E402

SUMMARY_FIELDS = ['case', 'k', 'T1', 'ms', 'speedup', 'added_copy_bytes',
                  'cache_hit_rate', 'tag']


def _eval_full(case, plan, scene):
    """一次评测拿到 (makespan, added_copy_bytes, cache_hit_rate)。"""
    if scene == 'B':
        ms, add, _ = fev.evaluate(case, plan, scene='B')
        return int(ms), int(add), ''
    cfg = fev.config()
    P = fev._modules()  # noqa: SLF001
    import multicore_cut_evaluate_problem_3 as P3
    r = P3.evaluate_problem_3(
        fev.graph(case), plan, bandwidth=cfg['bandwidth'], capacity=cfg['capacity'],
        cross_core_copy_delay=P['cross_core_copy_delay'],
        cache_capacity_bytes=P['cache_capacity_bytes'],
        cache_bandwidth_bytes_per_cycle=P['cache_bw'])
    return (int(r['makespan']), int(r['data_movement_bytes']['added_copy_bytes']),
            '%.6f' % r['cache_stats'].get('hit_rate', 0.0))


def worker(job):
    case, ks, src, outdir, scene, t1 = job
    t0 = time.time()
    try:
        plans, recs = {}, {}
        for k in ks:
            p = os.path.join(src, '%s_k%d.json' % (case[:-5], k))
            if not os.path.exists(p):
                continue
            plan = json.load(open(p, encoding='utf-8'))
            ms, add, hit = _eval_full(case, plan, scene)
            plans[k] = plan
            recs[k] = dict(case=case, k=k, T1=t1, ms=ms,
                           speedup=round(t1 / ms, 6), added_copy_bytes=add,
                           cache_hit_rate=hit, tag='reuse/A')
        # 单调化：M_k <= M_{k-1}。k 核可以空置一核无损模拟 k-1 核方案，
        # 一旦搜索/复用出现回落，就把 k-1 的方案补空核后落盘，保证提交数据自洽。
        prevk = None
        for k in sorted(recs):
            if prevk is not None and recs[k]['ms'] > recs[prevk]['ms']:
                plan = {'node_to_subgraph': dict(plans[prevk]['node_to_subgraph']),
                        'core_schedules': [list(x)
                                           for x in plans[prevk]['core_schedules']]}
                while len(plan['core_schedules']) < k:
                    plan['core_schedules'].append([])
                plans[k] = plan
                ms, add, hit = _eval_full(case, plan, scene)
                recs[k]['ms'] = ms
                recs[k]['speedup'] = round(t1 / ms, 6)
                recs[k]['added_copy_bytes'] = add
                recs[k]['cache_hit_rate'] = hit
                recs[k]['tag'] = 'mono<-k%d' % prevk
            prevk = k
        for k, plan in plans.items():
            with open(os.path.join(outdir, '%s_k%d.json' % (case[:-5], k)),
                      'w', encoding='utf-8') as f:
                json.dump(plan, f)
        rows = [recs[k] for k in sorted(recs)]
        return {'ok': True, 'case': case,
                'line': '%-16s %s (%.0fs)' % (
                    case, ' '.join('k%d=%.3f' % (r['k'], r['speedup'])
                                   for r in rows), time.time() - t0),
                'recs': rows}
    except Exception:  # noqa: BLE001
        import traceback
        return {'ok': False, 'case': case, 'err': traceback.format_exc()[-1200:]}


def load_t1(path):
    out = {}
    if path and os.path.exists(path):
        for r in csv.DictReader(open(path, encoding='utf-8-sig')):
            out[r['case']] = int(r['T1'])
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--scene', default='B', choices=['B', '3'])
    ap.add_argument('--src', required=True, help='问题一最终方案目录')
    ap.add_argument('--t1', default=None, help='含 T1 的 CSV（问题一结果表）')
    ap.add_argument('--out', required=True)
    ap.add_argument('--cases', nargs='*')
    ap.add_argument('--case-file', default=None)
    ap.add_argument('--ks', nargs='+', type=int, default=[2, 3, 4, 5])
    ap.add_argument('--workers', type=int, default=4)
    ap.add_argument('--resume', action='store_true')
    args = ap.parse_args()

    cases = args.cases or []
    if args.case_file:
        cases = [ln.strip() for ln in open(args.case_file, encoding='utf-8')
                 if ln.strip()]
    if not cases:
        cases = sorted({f.split('_k')[0] + '.json' for f in os.listdir(args.src)
                        if f.startswith('case_') and f.endswith('.json')},
                       key=lambda s: int(s[5:-5]))
    t1map = load_t1(args.t1)
    os.makedirs(args.out, exist_ok=True)

    if args.resume:
        keep = [c for c in cases
                if not all(os.path.exists(os.path.join(
                    args.out, '%s_k%d.json' % (c[:-5], k))) for k in args.ks)]
        print('resume: %d 待跑 / %d 总计' % (len(keep), len(cases)), flush=True)
        cases = keep

    miss = [c for c in cases if not t1map.get(c)]
    if miss:
        # T1 缺失就现场用官方场景 A 评估器算一遍（防止因结果表尚未合并而把加速比算成 0）
        import fl
        print('T1 缺失 %d 例，现场计算' % len(miss), flush=True)
        for c in miss:
            g = fev.graph(c)
            fev.set_graph(c, g)
            t1map[c] = int(fev.evaluate(c, fl.single_plan(g), scene='A')[0])
            print('  T1 %-16s = %d' % (c, t1map[c]), flush=True)

    jobs = [(c, args.ks, args.src, args.out, args.scene, t1map.get(c, 0))
            for c in cases]

    sp = os.path.join(args.out, 'summary_all.csv')
    new = not os.path.exists(sp)
    fsum = open(sp, 'a', encoding='utf-8-sig', newline='')
    wsum = csv.DictWriter(fsum, fieldnames=SUMMARY_FIELDS)
    if new:
        wsum.writeheader()
        fsum.flush()

    import multiprocessing as mp
    ctx = mp.get_context('spawn')
    n_ok = 0
    t0 = time.time()
    pool = ctx.Pool(args.workers)
    try:
        for res in pool.imap_unordered(worker, jobs, chunksize=1):
            if not res['ok']:
                print('FAIL %s\n%s' % (res['case'], res['err']), flush=True)
                continue
            n_ok += 1
            for rec in res['recs']:
                wsum.writerow(rec)
            fsum.flush()
            print('%s  [%d/%d]' % (res['line'], n_ok, len(jobs)), flush=True)
    finally:
        pool.terminate()
        pool.join()
        fsum.close()

    rows = list(csv.DictReader(open(sp, encoding='utf-8-sig')))
    byk = defaultdict(list)
    for r in rows:
        byk[int(r['k'])].append(float(r['speedup']))
    print('')
    for k in sorted(byk):
        v = byk[k]
        print('scene %s k=%d n=%d mean=%.4f min=%.4f max=%.4f'
              % (args.scene, k, len(v), sum(v) / len(v), min(v), max(v)))
    print('summary -> %s ; 本轮 %.1fs' % (sp, time.time() - t0))


if __name__ == '__main__':
    main()
