"""mergeA.py — 把若干"增量跑批"目录的最优方案合并进 out/final（不覆盖未涉及的条目）。

与 merge.py 的区别：以 out/final/results_problem1.csv（完整 400 条）为**基表**，
只对增量目录里 makespan 更小的 (case,k) 覆盖方案与数值，缺 T1 的沿用基表。
因此不会像 merge.py 那样"只保留增量目录里的条目"。

用法：
    python mergeA.py --final out/final --deltas out/mgA out/mgL
"""
from __future__ import annotations
import argparse, csv, os, shutil, sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))


def read_deltas(dirs):
    best = {}
    for d in dirs:
        p = os.path.join(d, 'summary_all.csv')
        if not os.path.exists(p):
            print('skip(无 summary_all.csv) %s' % d)
            continue
        n = 0
        for r in csv.DictReader(open(p, encoding='utf-8-sig')):
            try:
                ms = int(r['ms'])
            except (KeyError, ValueError):
                continue
            if ms <= 0:
                continue
            key = (r['case'], int(r['k']))
            if key not in best or ms < best[key][1]:
                best[key] = (d, ms, r.get('T1', ''), r.get('tag', 'delta'))
            n += 1
        print('读入 %-20s %4d 条' % (d, n))
    return best


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--final', default=os.path.join(HERE, 'out', 'final'))
    ap.add_argument('--deltas', nargs='+', required=True)
    args = ap.parse_args()

    F = args.final
    base_csv = os.path.join(F, 'results_problem1.csv')
    rows = list(csv.DictReader(open(base_csv, encoding='utf-8-sig')))
    base = {(r['case'], int(r['k'])): r for r in rows}
    print('基表 %d 条' % len(rows))

    delta = read_deltas(args.deltas)
    pdir = os.path.join(F, 'plans')
    ncopy = nbetter = 0
    for (case, k), (d, ms, _t1, tag) in sorted(delta.items()):
        old = base.get((case, k))
        if old is None:
            continue
        old_ms = int(old['ms'])
        if ms >= old_ms:
            continue
        src = os.path.join(d, '%s_k%d.json' % (case[:-5], k))
        if not os.path.exists(src):
            print('  !! 方案缺失 %s' % src)
            continue
        shutil.copyfile(src, os.path.join(pdir, '%s_k%d.json' % (case[:-5], k)))
        t1 = int(old['T1'])
        old.update(ms=str(ms), speedup='%.6f' % (t1 / ms), tag=tag)
        ncopy += 1
        nbetter += (old_ms - ms)
    print('覆盖方案 %d 条；总 makespan 下降 %d' % (ncopy, nbetter))

    with open(base_csv, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['case', 'k', 'T1', 'ms', 'speedup',
                                          'tag', 'src'])
        w.writeheader()
        w.writerows(rows)

    byk = defaultdict(list)
    for r in rows:
        byk[int(r['k'])].append(float(r['speedup']))
    for k in sorted(byk):
        v = byk[k]
        print('k=%d n=%d mean=%.4f min=%.4f max=%.4f'
              % (k, len(v), sum(v) / len(v), min(v), max(v)))
    print('-> ', base_csv)


if __name__ == '__main__':
    main()
