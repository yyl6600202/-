"""mkA.py — 汇总问题一（场景 A）的发布级结果表 verified_A.csv（并行版）。

数据来源优先级：
  1) verify_mp.py 产出的官方（未打补丁）复核表 verified_A_rest/big/small2.csv
  2) 兜底：等价加速版 fl（已证明与官方逐位一致，见 judge_patch.py 与报告 §4.7）
     —— 现场复算 makespan 与 added_copy_bytes，并与 results_problem1.csv 的 ms 交叉校验

输出：
  <final>/verified_A.csv       发布级结果表
  <final>/verified_A_src.csv   逐条标注来源，便于审计

用法：python mkA.py [--workers 3] [--only-missing]
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

F = os.path.join(HERE, 'out', 'final')
DATA = os.path.join(HERE, 'data')
PLANS = os.path.join(F, 'plans')
FIELDS = ['scene', 'case', 'k', 'T1', 'ms', 'speedup', 'added_copy_bytes',
          'cache_hit_rate']
OFFICIAL = ['verified_A_rest.csv', 'verified_A_big.csv', 'verified_A_small2.csv']
KS = [2, 3, 4, 5]


def _job(job):
    case, ks, plans, t1, ms_expect = job
    import fl
    fl.load_fast()
    fl.config()
    g = json.load(open(os.path.join(DATA, case), encoding='utf-8'))
    fl.set_graph(case, g)
    rows = []
    for k in ks:
        p = os.path.join(plans, '%s_k%d.json' % (case[:-5], k))
        if not os.path.exists(p):
            continue
        ms, add, _ = fl.eval_p1(case, json.load(open(p, encoding='utf-8')))
        rows.append(dict(scene='A', case=case, k=k, T1=t1, ms=int(ms),
                         speedup=round(t1 / ms, 6), added_copy_bytes=int(add),
                         cache_hit_rate='',
                         _src='fl(等价加速版)',
                         _ms_expect=ms_expect.get(k, '')))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--workers', type=int, default=3)
    args = ap.parse_args()

    best, src = {}, {}
    for nm in OFFICIAL:
        p = os.path.join(F, nm)
        if not os.path.exists(p):
            print('skip (缺失) %s' % nm)
            continue
        n = 0
        for r in csv.DictReader(open(p, encoding='utf-8-sig')):
            key = (r['case'], int(r['k']))
            if int(r['ms']) <= 0:
                continue
            best[key] = {f: r.get(f, '') for f in FIELDS}
            src[key] = nm
            n += 1
        print('读入 %-24s %4d 条' % (nm, n))

    # 现有 ms/T1（用于兜底，避免重复计算 T1）
    rp = os.path.join(F, 'results_problem1.csv')
    exp = {}
    if os.path.exists(rp):
        for r in csv.DictReader(open(rp, encoding='utf-8-sig')):
            exp.setdefault(r['case'], {})[int(r['k'])] = (int(r['T1']), int(r['ms']))

    cases = sorted({f.split('_k')[0] + '.json' for f in os.listdir(PLANS)
                    if f.startswith('case_') and f.endswith('.json')},
                   key=lambda s: int(s[5:-5]))
    todo = []
    for case in cases:
        e = exp.get(case, {})
        ks = [k for k in KS
              if (case, k) not in best and e.get(k)
              and os.path.exists(os.path.join(PLANS, '%s_k%d.json' % (case[:-5], k)))]
        if ks:
            todo.append((case, ks, PLANS, e[ks[0]][0], {k: e[k][1] for k in ks}))
    print('待补算 %d 个用例' % len(todo))

    filled = 0
    mism = []
    if todo:
        import multiprocessing as mp
        with mp.get_context('spawn').Pool(args.workers) as pool:
            for rows in pool.imap_unordered(_job, todo):
                for r in rows:
                    t1 = r['T1']
                    if r['_ms_expect'] not in ('', None) and int(r['_ms_expect']) != r['ms']:
                        mism.append((r['case'], r['k'], r['ms'], r['_ms_expect']))
                    key = (r['case'], r['k'])
                    best[key] = {f: r[f] for f in FIELDS}
                    src[key] = r['_src']
                    filled += 1
                print('  补算 %-14s %d 条' % (rows[0]['case'], len(rows)), flush=True)

    out = os.path.join(F, 'verified_A.csv')
    with open(out, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        for (case, k), r in sorted(best.items(),
                                   key=lambda kv: (int(kv[0][0][5:-5]), kv[0][1])):
            w.writerow({x: r.get(x, '') for x in FIELDS})
    with open(os.path.join(F, 'verified_A_src.csv'), 'w', encoding='utf-8-sig',
              newline='') as f:
        w = csv.writer(f)
        w.writerow(['case', 'k', 'source'])
        for (case, k), s in sorted(src.items(),
                                   key=lambda kv: (int(kv[0][0][5:-5]), kv[0][1])):
            w.writerow([case, k, s])

    from collections import Counter, defaultdict
    byk = defaultdict(list)
    for (_c, k), r in best.items():
        byk[k].append(float(r['speedup']))
    print('-> %s  (%d 条；官方 %d 条，补算 %d 条)'
          % (out, len(best), len(best) - filled, filled))
    for k in sorted(byk):
        v = byk[k]
        print('  scene A k=%d n=%d mean=%.4f min=%.4f max=%.4f'
              % (k, len(v), sum(v) / len(v), min(v), max(v)))
    if mism:
        print('!! ms 与 results_problem1.csv 不一致 %d 条: %s' % (len(mism), mism[:6]))
    else:
        print('ms 与 results_problem1.csv 完全一致（0 冲突）')
    print('来源分布:', dict(Counter(src.values())))


if __name__ == '__main__':
    main()
