"""cdiag2.py — 定位 B / 场景三时间线的"最早分歧点"及其邻域。"""
from __future__ import annotations
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fev  # noqa: E402


def ev(case, k, d):
    plan = json.load(open(os.path.join(HERE, d, '%s_k%d.json' % (case[:-5], k)),
                          encoding='utf-8'))
    P = fev._modules()  # noqa: SLF001
    cfg = fev.config()
    import multicore_cut_evaluate_problem_3 as P3
    g = fev.graph(case)
    rb = P['p2'].evaluate_scene_b(
        g, plan, bandwidth=cfg['bandwidth'], capacity=dict(cfg['capacity']),
        cross_core_copy_delay=P['cross_core_copy_delay'])
    rc = P3.evaluate_problem_3(
        g, plan, bandwidth=cfg['bandwidth'], capacity=dict(cfg['capacity']),
        cross_core_copy_delay=P['cross_core_copy_delay'],
        cache_capacity_bytes=P['cache_capacity_bytes'],
        cache_bandwidth_bytes_per_cycle=P['cache_bw'])
    return rb, rc


def main():
    case = sys.argv[1] if len(sys.argv) > 1 else 'case_067.json'
    k = int(sys.argv[2]) if len(sys.argv) > 2 else 2
    d = sys.argv[3] if len(sys.argv) > 3 else 'out/finalB'
    rb, rc = ev(case, k, d)

    def idx(res):
        out = {}
        for tl in res['per_core_timeline']:
            for e in tl['ops']:
                out[(e['task_id'], e['op_id'])] = e
        return out

    A, B = idx(rb), idx(rc)
    keys = sorted(A, key=lambda z: (A[z]['end'], A[z]['start']))
    first = None
    for kk in keys:
        if A[kk]['end'] != B[kk]['end']:
            first = kk
            break
    print('最早分歧算子:', first)
    if first is None:
        print('  无分歧（两场景逐算子一致）')
        return
    core = first[0]
    seqA = sorted([kk for kk in A if kk[0] == core],
                  key=lambda z: A[z]['start'])
    pos = seqA.index(first)
    print('\n同核 (core %d) 分歧点前后算子（按 B 的 start 排序）:' % core)
    print('  %-22s %-10s %-11s %-11s %-11s %-11s %-11s'
          % ('(core,op)', 'op', 'startB', 'endB', 'startC', 'endC', 'durB/durC'))
    for j in range(max(0, pos - 6), min(len(seqA), pos + 6)):
        kk = seqA[j]
        ea, eb = A[kk], B[kk]
        print('  %-22s %-10s %-11d %-11d %-11d %-11d %d/%d%s'
              % (str(kk), ea['op'], ea['start'], ea['end'], eb['start'],
                 eb['end'], ea['end'] - ea['start'], eb['end'] - eb['start'],
                 '   <== 分歧' if kk == first else ''))

    # 该核在分歧时刻附近的跨核搬运
    print('\n该核附近的跨核搬运（copy_out_end 落在分歧前后 ±1e6）:')
    t = A[first]['start']
    for it in rb['transfer_timeline']:
        if abs(it['copy_out_end'] - t) < 1e6:
            print('   %s' % {kk2: it[kk2] for kk2 in
                             ('source_core', 'target_core', 'copy_out_end',
                              'copy_in_release', 'copy_in_start', 'copy_in_end')})


if __name__ == '__main__':
    main()
