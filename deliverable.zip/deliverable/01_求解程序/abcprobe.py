"""abcprobe.py — 同一方案在 A / B / C 三个场景下的官方读数对照。

回答一个决定性的建模问题：只读 L2 缓存的 makespan 是否恒 ≤ 无缓存（场景 B）？
若存在 Ms_C(p) > Ms_B(p)，说明缓存带宽/未命中通路本身有开销，则
"用 B 的最优方案直接当 C 的答案"就不是免费的，必须以实测为准。
"""
from __future__ import annotations
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fev  # noqa: E402


def main():
    cases = sys.argv[1:] or ['case_067.json', 'case_048.json', 'case_075.json',
                             'case_061.json', 'case_002.json']
    k = 2
    P = fev._modules()  # noqa: SLF001
    cfg = fev.config()
    import multicore_cut_evaluate_problem_3 as P3

    for case in cases:
        for d in ('out/finalB', 'out/final3', 'out/final/plans'):
            p = os.path.join(HERE, d, '%s_k%d.json' % (case[:-5], k))
            if not os.path.exists(p):
                continue
            plan = json.load(open(p, encoding='utf-8'))
            g = fev.graph(case)
            rb = P['p2'].evaluate_scene_b(
                g, plan, bandwidth=cfg['bandwidth'],
                capacity=dict(cfg['capacity']),
                cross_core_copy_delay=P['cross_core_copy_delay'])
            rc = P3.evaluate_problem_3(
                g, plan, bandwidth=cfg['bandwidth'],
                capacity=dict(cfg['capacity']),
                cross_core_copy_delay=P['cross_core_copy_delay'],
                cache_capacity_bytes=P['cache_capacity_bytes'],
                cache_bandwidth_bytes_per_cycle=P['cache_bw'])
            mb, mc = int(rb['makespan']), int(rc['makespan'])
            cs = rc['cache_stats']
            print('%-16s k=%d %-18s B=%-10d C=%-10d delta=%-7d hit=%.4f '
                  'bytes=%d/%d'
                  % (case, k, os.path.basename(d), mb, mc, mc - mb,
                     cs.get('hit_rate', 0.0),
                     int(rb['data_movement_bytes']['added_copy_bytes']),
                     int(rc['data_movement_bytes']['added_copy_bytes'])),
                  flush=True)
            print('      cache_stats keys:', sorted(cs.keys()))


if __name__ == '__main__':
    main()
