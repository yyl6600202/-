"""xreuse.py — 跨场景复用扫描（目标场景吃下所有上游更优方案的官方实测值）。

原理（可证）
------------
三个场景共用同一份方案文件结构，差别只在评测口径：
    · 场景 A：每子图一个 Task；跨核前驱 +1000 cyc；跨子图数据走 DDR；
    · 场景 B：每核合并为一个 Task；跨核 COPY_OUT/COPY_IN + 500 cyc；
    · 场景 C：同 B，另加只读 FIFO L2 Cache（1MB @250B/cyc）。
因此
    (1) 方案可行域：Feas_C ⊇ Feas_B ⊇ Feas_A（结构相同，C 只多一个"缓存可能命中"的加速项）；
    (2) 同一方案在同一场景下 makespan 是确定量，故对任意 plan p 有
        Ms_C(p) ≤ Ms_B(p)（缓存只减少数据传输时间，不会增加）。
于是把"上游场景的最优方案"拿到目标场景下**再实测一次**，取 min，是严格合法且免费的改进；
且顺带给出目标场景的完整 cache 统计（命中率）。

用法
----
    python xreuse.py --scene 3 --cands out/final/plans out/finalB out/final3 \
                     --t1 out/final/results_problem1.csv --out out/xru3 --workers 8
    python xreuse.py --scene B --cands out/final/plans out/finalB \
                     --t1 out/final/results_problem1.csv --out out/xruB --workers 8
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import sys
import time
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import fev  # noqa: E402  三场景统一评测入口（含场景 A 的 fl 加速通道）

SUMMARY_FIELDS = ['case', 'k', 'T1', 'ms', 'speedup', 'added_copy_bytes',
                  'cache_hit_rate', 'tag']


def _eval_target(case, plan, scene, P3, cfg, P):
    """官方评估器：返回 (ms, added_copy_bytes, hit_rate_str)。"""
    if scene == 'A':
        # 场景 A 走 fl.eval_p1（与官方 evaluate_scene_a 逐位一致，已独立审计）
        ms, add, _ = fev.fl.eval_p1(case, plan)
        return int(ms), int(add), ''
    if scene == 'B':
        r = P['p2'].evaluate_scene_b(
            _graph(case), plan, bandwidth=cfg['bandwidth'],
            capacity=dict(cfg['capacity']),
            cross_core_copy_delay=P['cross_core_copy_delay'])
        return (int(r['makespan']),
                int(r['data_movement_bytes']['added_copy_bytes']), '')
    r = P3.evaluate_problem_3(
        _graph(case), plan, bandwidth=cfg['bandwidth'],
        capacity=dict(cfg['capacity']),
        cross_core_copy_delay=P['cross_core_copy_delay'],
        cache_capacity_bytes=P['cache_capacity_bytes'],
        cache_bandwidth_bytes_per_cycle=P['cache_bw'])
    return (int(r['makespan']),
            int(r['data_movement_bytes']['added_copy_bytes']),
            '%.6f' % r['cache_stats'].get('hit_rate', 0.0))


_G = {}


def _graph(case):
    g = _G.get(case)
    if g is None:
        with open(os.path.join(HERE, 'data', case), encoding='utf-8') as f:
            g = json.load(f)
        _G.clear()
        _G[case] = g
    return g


def worker(job):
    case, ks, cands, outdir, scene, t1 = job
    t0 = time.time()
    try:
        import fev
        P = fev._modules()  # noqa: SLF001
        cfg = fev.config()
        import multicore_cut_evaluate_problem_3 as P3

        best_plans, recs = {}, {}
        prev_ms, prev_plan = None, None
        for k in ks:
            seen = {}
            for d in cands:
                p = os.path.join(HERE, d, '%s_k%d.json' % (case[:-5], k))
                if not os.path.exists(p):
                    continue
                raw = open(p, 'rb').read()
                h = len(raw) if len(raw) < 64 else hashlib.sha1(raw).hexdigest()
                if h in seen:
                    continue
                seen[h] = (d, p, raw)
            if not seen:
                continue
            cand, errs = [], []
            for d, p, raw in seen.values():
                try:
                    plan = json.loads(raw.decode('utf-8'))
                    ms, add, hit = _eval_target(case, plan, scene, P3, cfg, P)
                except Exception as exc:  # noqa: BLE001 单个候选异常不影响整例
                    errs.append('%s:%s' % (os.path.basename(d), repr(exc)[:90]))
                    continue
                cand.append((ms, d, plan, add, hit))
            if not cand:
                raise RuntimeError('全部候选评测失败 %s: %s'
                                   % (k, '; '.join(errs)))
            if errs:
                print('WARN %s k=%d 跳过 %d 个候选: %s'
                      % (case, k, len(errs), '; '.join(errs)), flush=True)
            cand.sort(key=lambda z: z[0])
            ms, d, plan, add, hit = cand[0]
            tag = 'xru:%s' % d
            # 单调化：M_k <= M_{k-1}
            if prev_ms is not None and ms > prev_ms:
                plan = {'node_to_subgraph': dict(prev_plan['node_to_subgraph']),
                        'core_schedules': [list(x)
                                           for x in prev_plan['core_schedules']]}
                while len(plan['core_schedules']) < k:
                    plan['core_schedules'].append([])
                ms, add, hit = _eval_target(case, plan, scene, P3, cfg, P)
                tag = 'xru:mono<-k%d' % (k - 1)
            best_plans[k] = plan
            recs[k] = dict(case=case, k=k, T1=t1, ms=ms,
                           speedup=round(t1 / ms, 6), added_copy_bytes=add,
                           cache_hit_rate=hit, tag=tag)
            prev_ms, prev_plan = ms, plan

        for k, plan in best_plans.items():
            with open(os.path.join(outdir, '%s_k%d.json' % (case[:-5], k)),
                      'w', encoding='utf-8') as f:
                json.dump(plan, f)
        rows = [recs[k] for k in sorted(recs)]
        return {'ok': True, 'case': case,
                'line': '%-16s %s (%.0fs)' % (
                    case, ' '.join('k%d=%d' % (r['k'], r['ms']) for r in rows),
                    time.time() - t0),
                'recs': rows}
    except Exception:  # noqa: BLE001
        import traceback
        return {'ok': False, 'case': case, 'err': traceback.format_exc()[-1500:]}


def load_t1(path):
    out = {}
    if path and os.path.exists(path):
        for r in csv.DictReader(open(path, encoding='utf-8-sig')):
            out[r['case']] = int(r['T1'])
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--scene', default='3', choices=['A', 'B', '3'])
    ap.add_argument('--cands', nargs='+', required=True)
    ap.add_argument('--t1', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--cases', nargs='*')
    ap.add_argument('--case-file', default=None)
    ap.add_argument('--ks', nargs='+', type=int, default=[2, 3, 4, 5])
    ap.add_argument('--workers', type=int, default=8)
    ap.add_argument('--resume', action='store_true',
                    help='跳过 out/summary_all.csv 里已完成的用例')
    args = ap.parse_args()

    cases = args.cases or []
    if args.case_file:
        cases = [ln.strip() for ln in open(args.case_file, encoding='utf-8')
                 if ln.strip()]
    if not cases:
        names = set()
        for d in args.cands:
            for f in os.listdir(os.path.join(HERE, d)):
                if f.startswith('case_') and '_k' in f and f.endswith('.json'):
                    names.add(f.split('_k')[0] + '.json')
        cases = sorted(names, key=lambda s: int(s[5:-5]))

    t1map = load_t1(os.path.join(HERE, args.t1))
    os.makedirs(os.path.join(HERE, args.out), exist_ok=True)

    sp = os.path.join(HERE, args.out, 'summary_all.csv')
    done = set()
    if args.resume and os.path.exists(sp):
        for r in csv.DictReader(open(sp, encoding='utf-8-sig')):
            if r.get('case'):
                done.add(r['case'])
        cases = [c for c in cases if c not in done]
        print('resume: %d 待跑 / 已完成 %d' % (len(cases), len(done)),
              flush=True)

    print('场景 %s：%d 例，候选 %s' % (args.scene, len(cases), args.cands),
          flush=True)
    if not cases:
        print('无需处理。')
        return
    jobs = [(c, args.ks, args.cands, os.path.join(HERE, args.out), args.scene,
             t1map.get(c, 0)) for c in cases]

    new = not (args.resume and done)
    fsum = open(sp, 'a' if args.resume else 'w', encoding='utf-8-sig',
                newline='')
    wsum = csv.DictWriter(fsum, fieldnames=SUMMARY_FIELDS)
    if new:
        wsum.writeheader()
    fsum.flush()

    import multiprocessing as mp
    ctx = mp.get_context('spawn')
    n_ok = 0
    t0 = time.time()
    pool = ctx.Pool(args.workers)
    try:
        for res in pool.imap_unordered(worker, jobs, chunksize=1):
            if not res['ok']:
                print('FAIL %s\n%s' % (res['case'], res['err']), flush=True)
                continue
            n_ok += 1
            for rec in res['recs']:
                wsum.writerow(rec)
            fsum.flush()
            print('%s  [%d/%d]' % (res['line'], n_ok, len(jobs)), flush=True)
    finally:
        pool.terminate()
        pool.join()
        fsum.close()

    rows = list(csv.DictReader(open(sp, encoding='utf-8-sig')))
    byk = defaultdict(list)
    for r in rows:
        byk[int(r['k'])].append(float(r['speedup']))
    print('')
    for k in sorted(byk):
        v = byk[k]
        print('scene %s k=%d n=%d mean=%.4f min=%.4f max=%.4f'
              % (args.scene, k, len(v), sum(v) / len(v), min(v), max(v)))
    print('summary -> %s ; 本轮 %.1fs' % (sp, time.time() - t0))


if __name__ == '__main__':
    main()
