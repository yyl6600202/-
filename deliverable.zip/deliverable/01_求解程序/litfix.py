"""litfix.py — 把文献/参考实现启发的两个候选族并入候选池（官方评分裁决，保证不劣化）。

候选族（来自参考实现 solver2.py，见 exp_lit.py 的实测报告）：
  (1) intcut : 拓扑连续切段 + 张量级跨缝代价 DP（boundary_span_costs / gen_topo_cut_min）
  (2) ladder : 阶梯窗口（gen_ladder），核标号沿路径单调不减，层内仍可跨核并行

实测结论（out/exp_lit1.txt）：两者在多数用例上劣于本文的 (核, 层) 分组，
但在少数用例上更优（case_039 k=5：382,707 → 327,297，+14.5%）。
因此不做取舍，直接并入候选池：每个候选都用官方评估器实测，只保留更好的那个。

用法：
    python litfix.py --plans out/final/plans --out out/litA --t1 out/final/results_problem1.csv \
        --ks 4 5 --budget 180 --workers 3
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import exp_lit as EL  # noqa: E402  候选族生成器
import fl  # noqa: E402
import opt as optmod  # noqa: E402
import px  # noqa: E402
import testmerge as TM  # noqa: E402

DATA = os.path.join(HERE, 'data')
FIELDS = ['case', 'k', 'T1', 'ms', 'speedup', 'tag', 'evals', 'secs']


def candidates(V, k):
    out = []
    for wt in ('bytes', 'count'):
        for bal in (0.0, 0.5, 2.0, 8.0, 32.0, 128.0):
            try:
                out.append(('intcut_%s_b%g' % (wt, bal),
                            EL.intcut_ocore(V, k, balance=bal, weight=wt)))
            except Exception:  # noqa: BLE001
                pass
    for mode in ('work', 'uniform', 'two', 'head', 'tail'):
        try:
            out.append(('ladder_' + mode, EL.ladder_ocore(V, k, mode=mode)))
        except Exception:  # noqa: BLE001
            pass
    for mode in ('work', 'uniform', 'two'):
        try:
            out.append(('ladderB_' + mode, EL.ladder_ocore_bal(V, k, mode=mode)))
        except Exception:  # noqa: BLE001
            pass
    return out


def run_one(case, k, plans_dir, budget, outdir):
    g = json.load(open(os.path.join(DATA, case), encoding='utf-8'))
    fl.set_graph(case, g)
    V = optmod.View(g)
    pp = os.path.join(plans_dir, '%s_k%d.json' % (case[:-5], k))
    plan0 = json.load(open(pp, encoding='utf-8'))
    ms0 = fl.eval_p1(case, plan0)[0]
    best_ms, best_plan, best_tag = ms0, plan0, 'base'
    # 用代理预排序，把最有希望的放前面（预算不足时先评它们）
    ranked = []
    for name, ocore in candidates(V, k):
        oc = {o: (c if c < k else k - 1) for o, c in ocore.items()}
        try:
            p = px.proxy(V, oc, k)
        except Exception:  # noqa: BLE001
            p = 1e18
        ranked.append((p, name, plan0, oc))
    ranked.sort(key=lambda z: z[0])
    # 先把真实候选方案备好（代理排序前不做，避免大图上重复构造）
    t0, nev = time.time(), 0
    for p0, name, _pl, oc in ranked:
        if time.time() - t0 > budget:
            break
        try:
            plan = TM.group_by_core_layer(V, oc, k)
            ms = fl.eval_p1(case, plan)[0]
        except Exception:  # noqa: BLE001
            continue
        nev += 1
        if ms < best_ms:
            best_ms, best_plan, best_tag = ms, plan, name
    json.dump(best_plan, open(os.path.join(
        outdir, '%s_k%d.json' % (case[:-5], k)), 'w', encoding='utf-8'))
    return ms0, best_ms, best_tag, nev, round(time.time() - t0, 1)


def _w(job):
    case, k, plans, budget, out = job
    try:
        ms0, ms, tag, nev, secs = run_one(case, k, plans, budget, out)
        return dict(case=case, k=k, ms0=ms0, ms=ms, tag=tag, evals=nev, secs=secs)
    except Exception:  # noqa: BLE001
        import traceback
        print('FAIL %s k=%d %s' % (case, k, traceback.format_exc()[-300:]))
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--plans', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--ks', nargs='+', type=int, default=[2, 3, 4, 5])
    ap.add_argument('--cases', nargs='*', default=[])
    ap.add_argument('--case-file', default=None)
    ap.add_argument('--budget', type=float, default=180.0)
    ap.add_argument('--workers', type=int, default=3)
    ap.add_argument('--t1', default=None)
    args = ap.parse_args()

    fl.load_fast()
    fl.config()
    cases = args.cases
    if args.case_file:
        cases = [ln.strip() for ln in open(args.case_file, encoding='utf-8') if ln.strip()]
    if not cases:
        stems = sorted({f.split('_k')[0] for f in os.listdir(args.plans)
                        if f.startswith('case_') and f.endswith('.json')},
                       key=lambda s: int(s[5:]))
        cases = [s + '.json' for s in stems]
    T1 = {}
    if args.t1 and os.path.exists(args.t1):
        for r in csv.DictReader(open(args.t1, encoding='utf-8-sig')):
            T1[r['case']] = int(r['T1'])

    os.makedirs(args.out, exist_ok=True)
    jobs = [(c, k, args.plans, args.budget, args.out) for c in cases
            for k in args.ks
            if os.path.exists(os.path.join(args.plans, '%s_k%d.json' % (c[:-5], k)))]
    rows = []
    if args.workers > 1:
        import multiprocessing as mp
        with mp.get_context('spawn').Pool(args.workers) as pool:
            for r in pool.imap_unordered(_w, jobs):
                if r is None:
                    continue
                rows.append(r)
                print('%-16s k=%d  %d -> %d  %s (%d evals, %ss)'
                      % (r['case'], r['k'], r['ms0'], r['ms'], r['tag'],
                         r['evals'], r['secs']), flush=True)
    else:
        for j in jobs:
            r = _w(j)
            if r is None:
                continue
            rows.append(r)
            print('%-16s k=%d  %d -> %d  %s (%d evals, %ss)'
                  % (r['case'], r['k'], r['ms0'], r['ms'], r['tag'],
                     r['evals'], r['secs']), flush=True)

    if rows:
        with open(os.path.join(args.out, 'litfix_summary.csv'), 'w',
                  encoding='utf-8-sig', newline='') as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0]))
            w.writeheader()
            w.writerows(rows)
        with open(os.path.join(args.out, 'summary_all.csv'), 'w',
                  encoding='utf-8-sig', newline='') as f:
            w = csv.DictWriter(f, fieldnames=FIELDS)
            w.writeheader()
            for r in sorted(rows, key=lambda z: (int(z['case'][5:-5]), z['k'])):
                t1 = T1.get(r['case'], 0)
                w.writerow(dict(case=r['case'], k=r['k'], T1=t1, ms=r['ms'],
                                speedup=round(t1 / r['ms'], 6) if t1 else 0.0,
                                tag='lit:' + r['tag'], evals=r['evals'],
                                secs=r['secs']))
        for k in sorted({r['k'] for r in rows}):
            gg = [r for r in rows if r['k'] == k]
            print('k=%d n=%d improved=%d Σgain=%.4f' % (
                k, len(gg), sum(1 for r in gg if r['ms'] < r['ms0']),
                sum((r['ms0'] - r['ms']) / r['ms0'] for r in gg)))
        hit = defaultdict(int)
        for r in rows:
            if r['ms'] < r['ms0']:
                hit[r['tag']] += 1
        print('胜出候选族统计:', dict(sorted(hit.items(), key=lambda kv: -kv[1])))
    print('done', args.out)


if __name__ == '__main__':
    main()
