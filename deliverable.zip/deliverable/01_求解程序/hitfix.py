"""hitfix.py — 问题三汇总表里 cache_hit_rate 字段的回填与核对。

背景
----
问题三汇总表 `out/final3/summary_all.csv` 里有若干行 `cache_hit_rate` 为空：
这些行来自早期跑批通道没有把命中率一并落盘的记录。它们的 **makespan 本身是
官方值**（`xprobe.py` 抽查 8 条，用未打补丁的官方问题三评估器重算磁盘方案，
8/8 与表内 makespan 完全一致），只是缺了命中率这一个统计字段。

做法
----
对表中 `cache_hit_rate` 为空的行，读回**磁盘上的方案文件**，用官方
`multicore_cut_evaluate_problem_3.evaluate_problem_3` 重算：
  · 若 makespan 与表内一致 → 回填命中率（并把实测 makespan 写回，等价）；
  · 若不一致 → 不改数字，只报告 MISMATCH（提示方案与汇总表脱钩，需人工处理）。

这样保证"问题三附表的每一行都能由磁盘方案复现"，且命中率不再有空洞。

用法：
    python hitfix.py --summary out/final3/summary_all.csv \
                     --plans out/final3 --workers 4
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

FIELDS = ['case', 'k', 'T1', 'ms', 'speedup', 'added_copy_bytes',
          'cache_hit_rate', 'tag']


def worker(job):
    case, k, plans, t1, ms_tab = job
    try:
        import fev
        cfg = fev.config()
        P = fev._modules()  # noqa: SLF001
        import multicore_cut_evaluate_problem_3 as P3
        p = os.path.join(plans, '%s_k%d.json' % (case[:-5], k))
        plan = json.load(open(p, encoding='utf-8'))
        g = fev.graph(case)
        r = P3.evaluate_problem_3(
            g, plan, bandwidth=cfg['bandwidth'], capacity=dict(cfg['capacity']),
            cross_core_copy_delay=P['cross_core_copy_delay'],
            cache_capacity_bytes=P['cache_capacity_bytes'],
            cache_bandwidth_bytes_per_cycle=P['cache_bw'])
        ms = int(r['makespan'])
        return {'ok': True, 'case': case, 'k': k, 'ms': ms,
                'tab': ms_tab,
                'hit': r['cache_stats'].get('hit_rate', 0.0),
                'added': int(r['data_movement_bytes']['added_copy_bytes']),
                'T1': t1}
    except Exception:  # noqa: BLE001
        import traceback
        return {'ok': False, 'case': case, 'k': k,
                'err': traceback.format_exc()[-500:]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--summary', default='out/final3/summary_all.csv')
    ap.add_argument('--plans', default='out/final3')
    ap.add_argument('--workers', type=int, default=4)
    ap.add_argument('--out', default=None)
    args = ap.parse_args()

    sp = os.path.join(HERE, args.summary)
    rows = list(csv.DictReader(open(sp, encoding='utf-8-sig')))
    need = [r for r in rows if not (r.get('cache_hit_rate') or '').strip()]
    print('总 %d 行；命中率缺失 %d 行' % (len(rows), len(need)))
    if not need:
        print('无需回填。')
        return

    jobs = [(r['case'], int(r['k']), os.path.join(HERE, args.plans),
             int(r['T1']), int(r['ms'])) for r in need]
    import multiprocessing as mp
    ctx = mp.get_context('spawn')
    fix, mism = {}, []
    pool = ctx.Pool(args.workers)
    try:
        for i, res in enumerate(pool.imap_unordered(worker, jobs, chunksize=1), 1):
            if not res['ok']:
                print('FAIL %s k=%d %s' % (res['case'], res['k'], res['err']),
                      flush=True)
                continue
            if res['ms'] != res['tab']:
                mism.append((res['case'], res['k'], res['tab'], res['ms']))
            fix[(res['case'], res['k'])] = res
            print('  %-16s k=%d ms=%-10d hit=%.6f  [%d/%d]%s'
                  % (res['case'], res['k'], res['ms'], res['hit'], i,
                     len(jobs), '  <<< MISMATCH' if res['ms'] != res['tab'] else ''),
                  flush=True)
    finally:
        pool.terminate()
        pool.join()

    n = 0
    for r in rows:
        key = (r['case'], int(r['k']))
        if not (r.get('cache_hit_rate') or '').strip() and key in fix:
            f = fix[key]
            r['cache_hit_rate'] = '%.6f' % f['hit']
            if f['ms'] == f['tab']:
                r['ms'] = str(f['ms'])
                r['added_copy_bytes'] = str(f['added'])
                r['speedup'] = '%.6f' % (f['T1'] / f['ms'])
            n += 1
    out = os.path.join(HERE, args.out or args.summary)
    with open(out, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows([{x: r.get(x, '') for x in FIELDS} for r in rows])

    byk = defaultdict(list)
    for r in rows:
        byk[int(r['k'])].append(float(r['speedup']))
    print('\n回填 %d 行；makespan 不一致 %d 处' % (n, len(mism)))
    for m in mism[:20]:
        print('  MISMATCH', m)
    for k in sorted(byk):
        v = byk[k]
        print('  k=%d n=%d mean=%.4f' % (k, len(v), sum(v) / len(v)))
    print('-> %s' % out)


if __name__ == '__main__':
    main()
