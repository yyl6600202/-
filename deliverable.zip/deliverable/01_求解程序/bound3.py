"""bound3.py — 分层下界 vs 实测的量化对比（用于报告 §3.4 的诚实口径）。

三层可计算下界（k 核）：
  LB_work = max(ΣM/k, ΣV/k)                 流水线算力
  LB_cp   = 加权关键路径（按算子 cycles 求最长路）
  LB_ddr  = D0 / B，D0 = 原图中 pos=='DDR' 的张量字节数（必然要过 DDR 的搬运）
并检验"算子不可分割"是否是真瓶颈：max_o cycles(o) 与 top3/ΣM。
"""
from __future__ import annotations
import collections, csv, json, os, statistics as st, sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data')
F = os.path.join(HERE, 'out', 'final')
K = int(sys.argv[1]) if len(sys.argv) > 1 else 5
BW = 60.0

ms, t1 = {}, {}
for r in csv.DictReader(open(os.path.join(F, 'results_problem1.csv'),
                             encoding='utf-8-sig')):
    if int(r['k']) == K:
        ms[r['case']] = int(r['ms'])
        t1[r['case']] = int(r['T1'])

rows = []
for case in sorted(ms, key=lambda s: int(s[5:-5])):
    g = json.load(open(os.path.join(DATA, case), encoding='utf-8'))
    cyc = {}
    pm = pv = 0
    opm = []
    for o in g['ops']:
        cyc[o['id']] = int(o.get('cycles', 0))
        if o.get('op') in ('COPY_IN', 'COPY_OUT'):
            continue
        c = int(o.get('cycles', 0))
        if o.get('pipe') == 'PIPE_M':
            pm += c
            opm.append(c)
        else:
            pv += c
    pred = collections.defaultdict(list)
    for e in g.get('edges', ()):
        pred[e['target']].append(e['source'])
    succ = collections.defaultdict(list)
    for t, ss in pred.items():
        if t not in cyc:
            continue
        for s in ss:
            if s in cyc:
                succ[s].append(t)
    indeg = {n: 0 for n in cyc}
    for u in succ:
        for v in succ[u]:
            indeg[v] += 1
    q = collections.deque([n for n in cyc if indeg[n] == 0])
    dist = {n: cyc[n] for n in cyc}
    while q:
        u = q.popleft()
        for v in succ[u]:
            if dist[u] + cyc[v] > dist[v]:
                dist[v] = dist[u] + cyc[v]
            indeg[v] -= 1
            if indeg[v] == 0:
                q.append(v)
    cp = max(dist.values()) if dist else 0
    d0 = sum(t['size'] for t in g.get('tensors', ()) if t.get('pos') == 'DDR')
    opm.sort(reverse=True)
    mx = opm[0] if opm else 0
    rows.append(dict(case=case, ms=ms[case], T1=t1[case], pm=pm, pv=pv, cp=cp,
                     d0=d0, mx=mx, top3=sum(opm[:3]) / pm if pm else 0,
                     lbw=max(pm, pv) / K, lddr=d0 / BW))
    del g, pred, succ, dist

print('k=%d  n=%d' % (K, len(rows)))
print('  mean ΣM=%.0f  mean ΣV=%.0f  mean CP=%.0f  mean max_op=%.0f  '
      'max top3/ΣM=%.3f' % (
          st.mean(r['pm'] for r in rows), st.mean(r['pv'] for r in rows),
          st.mean(r['cp'] for r in rows), st.mean(r['mx'] for r in rows),
          max(r['top3'] for r in rows)))
print('  mean LB_work=%.0f (=Σpipe/k)   mean LB_ddr(D0/B)=%.0f   '
      'mean ms=%.0f' % (st.mean(r['lbw'] for r in rows),
                        st.mean(r['lddr'] for r in rows),
                        st.mean(r['ms'] for r in rows)))
print('  mean speedup=%.4f' % st.mean(r['T1'] / r['ms'] for r in rows))
print('  ms/LB_work : mean=%.3f median=%.3f' % (
    st.mean(r['ms'] / max(r['lbw'], 1) for r in rows),
    st.median(r['ms'] / max(r['lbw'], 1) for r in rows)))
print('  ms/max(LB_work,CP,LB_ddr): mean=%.3f' % st.mean(
    r['ms'] / max(r['lbw'], r['cp'], r['lddr'], 1) for r in rows))
print('  ms/(LB_work+LB_ddr)      : mean=%.3f' % st.mean(
    r['ms'] / max(r['lbw'] + r['lddr'], 1) for r in rows))
print('  LB_ddr 成为最紧下界的用例数: %d' % sum(
    1 for r in rows if r['lddr'] > max(r['lbw'], r['cp'])))
print('  max_op 成为最紧下界的用例数: %d' % sum(
    1 for r in rows if r['mx'] > max(r['lbw'], r['cp'], r['lddr'])))
print('  CP     成为最紧下界的用例数: %d' % sum(
    1 for r in rows if r['cp'] > max(r['lbw'], r['lddr'])))
print('  理论可达加速比上界 T1/LB_work 的均值: %.2f' % st.mean(
    r['T1'] / max(r['lbw'], 1) for r in rows))
print('  理论可达加速比上界 T1/LB3 的均值   : %.2f' % st.mean(
    r['T1'] / max(r['lbw'], r['cp'], r['lddr'], 1) for r in rows))
