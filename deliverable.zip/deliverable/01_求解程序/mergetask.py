"""mergetask.py — 同核相邻 Task 合并（位集增量合法性 + 批量线搜索爬山）。

背景与动机
----------
case_073 把图切成 49 个 Task ⇒ spill=0、分区搬运 142 MB；改成连续切段 ⇒
分区搬运 1 MB、spill 137 MB。两种极端下**额外 DDR 搬运总量近似守恒** ⇒ 真正的
杠杆是"同一份数据被反复搬动的次数"。Task 边界搬运与核内换出(spill) 是同一枚
硬币的两面。

合法性判据（关键，曾被一个反例推翻过一次）
----------------------------------------
把每个核上的 Task 序列看成被若干切点分割的链；把 a=(c,i)、b=(c,i+1) 合并成 m
等价于在任务级 DAG（子图依赖边 ∪ 同核相邻顺序边）里收缩边 a→b。

收缩后出现环 ⟺ 存在一条 **a ⇝ b 且含至少一个中间节点** 的通路（在去掉顺序边
a→b 之后）。反例：A→(1,10)→B 与 A→B（顺序边）共存时，A、B 各自与原图都不成环，
但 A∪B 与 (1,10) 互相可达 → 成环。所以"起点合法 ⇒ 合并必合法"是**错的**，
必须逐次判断。

但判断可以极快：
    illegal(a,b)  ⟺  b ∈ ⋃_{x ∈ dep_out(a) \\ {b}} ( R[x] ∪ {x} )
其中 R 是任务级 DAG 的可达闭包（位集）。理由：a 的第一步只能是依赖边；通路若
经过 a 则与 a→x 构成环（DAG 中不可能），故闭包用完整 DAG 计算即可。
单次判断 = O(|dep_out(a)|) 次大整数或运算，微秒级。

于是整个搜索的开销几乎只剩官方评估（实测 4–23 秒/次），因此采用
**批量线搜索**：一次试验先贪心连做 b 个（逐个已验证合法的）合并，再评估一次；
b 起始 16，成功加倍（上限 64），失败减半；b<2 时改为在 top-K 单切点上扫。

用法：
    python mergetask.py --plans out/final/plans --pair-file out/mgap.txt \\
        --out out/mgA --budget 200 --max-evals 20 --workers 6 \\
        --t1 out/final/results_problem1.csv
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import fl  # noqa: E402
import opt as optmod  # noqa: E402

DATA = os.path.join(HERE, 'data')

B0, BMAX, TOPK = 16, 512, 8


# ------------------------------------------------------------ 官方合法性（末次校验）
def legal(core_tasks):
    """官方 validate_task_order 判据：子图依赖 ∪ 同核相邻顺序 无环。"""
    gid, nodes = {}, set()
    for c, tasks in enumerate(core_tasks):
        for i, ops in enumerate(tasks):
            nodes.add((c, i))
            for o in ops:
                gid[o] = (c, i)
    succ = defaultdict(list)
    indeg = {n: 0 for n in nodes}
    for o, n in gid.items():
        for s in OP_SUCC[o]:
            m = gid.get(s)
            if m is None or m == n:
                continue
            succ[n].append(m)
            indeg[m] += 1
    for c, tasks in enumerate(core_tasks):
        for i in range(len(tasks) - 1):
            succ[(c, i)].append((c, i + 1))
            indeg[(c, i + 1)] += 1
    q = [n for n in nodes if indeg[n] == 0]
    cnt = 0
    while q:
        u = q.pop()
        cnt += 1
        for v in succ[u]:
            indeg[v] -= 1
            if indeg[v] == 0:
                q.append(v)
    return cnt == len(nodes)


# ---------------------------------------------------------------------- 方案表示
def to_plan(core_tasks, V, k):
    mapping, sched, nxt = {}, [[] for _ in range(k)], 0
    for c, tasks in enumerate(core_tasks):
        for ops in tasks:
            for o in ops:
                mapping[str(o)] = nxt
            sched[c].append(nxt)
            nxt += 1
    return {'node_to_subgraph': mapping, 'core_schedules': sched}


def state_of(V, plan, k):
    core_tasks = [[] for _ in range(k)]
    n2s = {int(a): int(b) for a, b in plan['node_to_subgraph'].items()}
    bucket = defaultdict(list)
    for o in V.ops:
        sg = n2s.get(o)
        if sg is not None:
            bucket[sg].append(o)
    for c, sgs in enumerate(plan['core_schedules']):
        for sg in sgs:
            if bucket.get(sg):
                core_tasks[c].append(sorted(bucket[sg]))
    return core_tasks


def merge_at(st, c, i):
    new = [list(x) for x in st]
    new[c][i] = new[c][i] + new[c][i + 1]
    del new[c][i + 1]
    return new


# --------------------------------------------------------------- 任务级索引 + 闭包
class TI:
    """任务级 DAG 的索引、可达闭包（位集），支持微秒级合并合法性判断。"""

    def __init__(self, st):
        self.st = st
        nodes = [(c, i) for c, ts in enumerate(st) for i in range(len(ts))]
        self.nodes = nodes
        idx = {n: j for j, n in enumerate(nodes)}
        gid = {}
        for c, ts in enumerate(st):
            for i, ops in enumerate(ts):
                for o in ops:
                    gid[o] = (c, i)
        n = len(nodes)
        out = [set() for _ in range(n)]
        for o, nd in gid.items():
            a = idx[nd]
            for s in OP_SUCC[o]:
                m = gid.get(s)
                if m is None or m == nd:
                    continue
                out[a].add(idx[m])
        self.dep_out = [frozenset(x) for x in out]
        chain = [-1] * n
        for c, ts in enumerate(st):
            for i in range(len(ts) - 1):
                chain[idx[(c, i)]] = idx[(c, i + 1)]
        self.chain = chain
        # Kahn 拓扑序
        indeg = [0] * n
        for u in range(n):
            for v in out[u]:
                indeg[v] += 1
            if chain[u] >= 0:
                indeg[chain[u]] += 1
        q = [u for u in range(n) if indeg[u] == 0]
        order = []
        while q:
            u = q.pop()
            order.append(u)
            vs = list(out[u])
            if chain[u] >= 0:
                vs.append(chain[u])
            for v in vs:
                indeg[v] -= 1
                if indeg[v] == 0:
                    q.append(v)
        if len(order) != n:
            raise RuntimeError('task DAG cyclic (%d/%d)' % (len(order), n))
        R = [0] * n
        for u in reversed(order):
            m = 0
            for v in out[u]:
                m |= R[v] | (1 << v)
            if chain[u] >= 0:
                v = chain[u]
                m |= R[v] | (1 << v)
            R[u] = m
        self.R = R
        self.n = n
        self.per_core = [[idx[(c, i)] for i in range(len(ts))]
                         for c, ts in enumerate(st)]

    def ok(self, c, i):
        """合并 (c,i) 与 (c,i+1) 是否合法。"""
        a = self.per_core[c][i]
        b = self.per_core[c][i + 1]
        m = 0
        for x in self.dep_out[a]:
            if x == b:
                continue
            m |= self.R[x] | (1 << x)
        return not ((m >> b) & 1)


# ------------------------------------------------------------------------ 切点收益
OP_SUCC, T_SIZE, T_PROD, T_CONS, OP_T = {}, {}, {}, {}, {}


def prep(V):
    global OP_SUCC, T_SIZE, T_PROD, T_CONS, OP_T
    OP_SUCC = {o: V.succs[o] for o in V.ops}
    gv = V.gv
    T_SIZE = gv.tensor_size
    T_PROD = {t: [p for p in gv.out_t.get(t, ()) if p in V.oset] for t in T_SIZE}
    T_CONS = {t: [c for c in gv.in_t.get(t, ()) if c in V.oset] for t in T_SIZE}
    inc = defaultdict(set)
    for t, ps in T_PROD.items():
        for p in ps:
            inc[p].add(t)
    for t, cs in T_CONS.items():
        for cc in cs:
            inc[cc].add(t)
    OP_T = dict(inc)


def _tset(task):
    s = set()
    for o in task:
        s.update(OP_T.get(o, ()))
    return s


def rank_boundaries(st):
    out = []
    for c, tasks in enumerate(st):
        ts = [_tset(t) for t in tasks]
        for i in range(len(tasks) - 1):
            common = ts[i] & ts[i + 1]
            out.append((sum(T_SIZE.get(t, 0) for t in common) if common else 0.0,
                        c, i))
    out.sort(key=lambda z: (-z[0], z[1], z[2]))
    return out


def apply_b(cur, ti, b, ti_ref):
    """在 cur 上贪心连做至多 b 个合法合并；返回 (新 cur, 应用到数)。"""
    n = 0
    while n < b:
        rk = rank_boundaries(cur)
        if not rk:
            break
        done = False
        for _sv, c, i in rk:
            if i + 1 >= len(cur[c]):
                continue
            if ti.ok(c, i):
                cur = merge_at(cur, c, i)
                ti = TI(cur)
                n += 1
                done = True
                break
        if not done:
            break
    ti_ref[0] = ti
    return cur, n


# -------------------------------------------------------------------------- 爬山
def improve(case, k, plans_dir, budget, max_evals, outdir, verbose=False):
    def ev(plan):
        return fl.eval_p1(case, plan)[0]

    g = json.load(open(os.path.join(DATA, case), encoding='utf-8'))
    fl.set_graph(case, g)
    V = optmod.View(g)
    prep(V)
    pp = os.path.join(plans_dir, '%s_k%d.json' % (case[:-5], k))
    plan0 = json.load(open(pp, encoding='utf-8'))
    ms0 = ev(plan0)
    st = state_of(V, plan0, k)
    if not legal(st):
        raise RuntimeError('input plan illegal: %s k=%d' % (case, k))
    ti = TI(st)

    cur_ms, best_ms, best_st = ms0, ms0, st
    ntask0 = sum(len(x) for x in st)
    # 初始批量随任务规模自适应：任务越碎，一次就该合掉越多
    b = max(B0, min(max(ntask0 // 8, 1), 256))
    t0, nev = time.time(), 0
    deadline = t0 + budget
    while nev < max_evals and time.time() < deadline:
        if b >= 2:
            ref = [ti]
            trial, na = apply_b(st, ti, b, ref)
            if na == 0:
                b //= 2
                continue
            ms = ev(to_plan(trial, V, k))
            nev += 1
            if ms < cur_ms:
                st, cur_ms, ti = trial, ms, ref[0]
                if ms < best_ms:
                    best_ms, best_st = ms, trial
                b = min(b * 2, BMAX)
                if verbose:
                    print('   %-16s k%d ev%-3d -> %-12d merged=%-4d ntasks=%d'
                          % (case, k, nev, ms, na,
                             sum(len(x) for x in st)), flush=True)
            else:
                b //= 2
        else:
            rk = rank_boundaries(st)
            improved = False
            for _sv, c, i in rk[:TOPK]:
                if nev >= max_evals or time.time() > deadline:
                    break
                if not ti.ok(c, i):
                    continue
                trial = merge_at(st, c, i)
                ms = ev(to_plan(trial, V, k))
                nev += 1
                if ms < cur_ms:
                    st, cur_ms, ti = trial, ms, TI(trial)
                    if ms < best_ms:
                        best_ms, best_st = ms, trial
                    improved = True
                    b = 2
                    break
            if not improved:
                break
    if not legal(best_st):
        raise RuntimeError('output plan illegal: %s k=%d' % (case, k))
    json.dump(to_plan(best_st, V, k),
              open(os.path.join(outdir, '%s_k%d.json' % (case[:-5], k)), 'w',
                   encoding='utf-8'))
    return ms0, best_ms, nev, round(time.time() - t0, 1)


def _w(job):
    case, k, plans, budget, max_evals, out = job
    try:
        ms0, ms, nev, secs = improve(case, k, plans, budget, max_evals, out)
        return dict(case=case, k=k, ms0=ms0, ms=ms,
                    gain=round((ms0 - ms) / ms0, 6) if ms0 else 0.0,
                    merges=nev, secs=secs)
    except Exception:  # noqa: BLE001
        import traceback
        print('FAIL %s k=%d %s' % (case, k, traceback.format_exc()[-400:]),
              flush=True)
        return None


def _fmt(r):
    return '%-16s k=%d  %d -> %d  (%+.4f)  evals=%d %ss' % (
        r['case'], r['k'], r['ms0'], r['ms'], r['gain'], r['merges'], r['secs'])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--cases', nargs='*', default=[])
    ap.add_argument('--case-file', default=None)
    ap.add_argument('--pair-file', default=None,
                    help='每行 "case_xxx.json k"')
    ap.add_argument('--ks', nargs='+', type=int, default=[2, 3, 4, 5])
    ap.add_argument('--plans', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--budget', type=float, default=200.0)
    ap.add_argument('--max-evals', type=int, default=20)
    ap.add_argument('--workers', type=int, default=1)
    ap.add_argument('--verbose', action='store_true')
    ap.add_argument('--t1', default=None)
    args = ap.parse_args()

    fl.load_fast()
    fl.config()

    T1 = {}
    if args.t1 and os.path.exists(args.t1):
        for r in csv.DictReader(open(args.t1, encoding='utf-8-sig')):
            T1[r['case']] = int(r['T1'])

    pairs = None
    if args.pair_file:
        pairs = []
        for ln in open(args.pair_file, encoding='utf-8'):
            ln = ln.strip()
            if not ln or ln.startswith('#'):
                continue
            a, b = ln.split()
            pairs.append((a, int(b)))
    cases = list(args.cases)
    if args.case_file:
        cases = [x.strip() for x in open(args.case_file, encoding='utf-8')
                 if x.strip()]
    os.makedirs(args.out, exist_ok=True)

    if pairs is None:
        if not cases:
            stems = sorted({f.split('_k')[0] for f in os.listdir(args.plans)
                            if f.startswith('case_')})
            cases = [s + '.json' for s in stems]
        jobs = [(c, k, args.plans, args.budget, args.max_evals, args.out)
                for c in cases for k in args.ks
                if os.path.exists(os.path.join(args.plans,
                                               '%s_k%d.json' % (c[:-5], k)))]
    else:
        jobs = [(c, k, args.plans, args.budget, args.max_evals, args.out)
                for c, k in pairs
                if os.path.exists(os.path.join(args.plans,
                                               '%s_k%d.json' % (c[:-5], k)))]
    print('jobs=%d  budget=%.0fs max_evals=%d workers=%d'
          % (len(jobs), args.budget, args.max_evals, args.workers), flush=True)

    rows = []
    if args.workers > 1:
        import multiprocessing as mp
        with mp.get_context('spawn').Pool(args.workers) as pool:
            for r in pool.imap_unordered(_w, jobs):
                if r is None:
                    continue
                rows.append(r)
                print(_fmt(r), flush=True)
    else:
        for j in jobs:
            r = _w(j)
            if r is None:
                continue
            rows.append(r)
            print(_fmt(r), flush=True)

    if rows:
        with open(os.path.join(args.out, 'merge_summary.csv'), 'w',
                  encoding='utf-8-sig', newline='') as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0]))
            w.writeheader()
            w.writerows(rows)
        SF = ['case', 'k', 'T1', 'ms', 'speedup', 'tag', 'evals', 'secs']
        with open(os.path.join(args.out, 'summary_all.csv'), 'w',
                  encoding='utf-8-sig', newline='') as f:
            w = csv.DictWriter(f, fieldnames=SF)
            w.writeheader()
            for r in sorted(rows, key=lambda z: (int(z['case'][5:-5]), z['k'])):
                t1 = T1.get(r['case'], 0)
                w.writerow(dict(case=r['case'], k=r['k'], T1=t1, ms=r['ms'],
                                speedup=round(t1 / r['ms'], 6) if t1 else 0.0,
                                tag='mg', evals=r['merges'], secs=r['secs']))
        for k in sorted({r['k'] for r in rows}):
            g = [r for r in rows if r['k'] == k]
            print('k=%d  n=%d  improved=%d  Σgain=%.4f  evals=%d' % (
                k, len(g), sum(1 for r in g if r['ms'] < r['ms0']),
                sum(r['gain'] for r in g), sum(r['merges'] for r in g)),
                flush=True)
    print('done', args.out)


if __name__ == '__main__':
    main()
