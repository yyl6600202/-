"""addfix.py — 汇总表 `added_copy_bytes` 字段的回填与核对（场景 B / 问题三通用）。

背景
----
`out/finalB/summary_all.csv` 里有 115 个「胜出行」（每个 (用例, 核数) 只保留实测
makespan 最小的一行）的 `added_copy_bytes` 为空：这些行来自不同跑批通道，有的
通道只落盘了 makespan，没有把 `data_movement_bytes.added_copy_bytes` 一并写出。
makespan 本身是官方值，缺的只是搬运量统计字段，而附表要求同时给出
「Makespan + 跨核搬运字节」，因此必须补齐——且不能用 0 或估计值顶替。

做法
----
对指定汇总表里 `added_copy_bytes` 为空的**胜出行**，读回磁盘上的方案文件，用
对应场景的官方评估器重算：
  · 若重算 makespan 与表内一致 → 回填 added_copy_bytes（并把 ms/added/speedup 写回）；
  · 若不一致 → 不改数字，只报告 MISMATCH（说明方案与汇总表脱钩，需人工处理）。

与 hitfix.py（问题三命中率回填）同构，区别是本脚本按 `--scene` 选择官方入口：
场景 B → `multicore_cut_evaluate_problem_2.evaluate_scene_b`；
问题三 → `multicore_cut_evaluate_problem_3.evaluate_problem_3`。

用法：
    python addfix.py --summary out/finalB/summary_all.csv --plans out/finalB \
                     --scene B --workers 12
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

FIELDS = ['case', 'k', 'T1', 'ms', 'speedup', 'added_copy_bytes',
          'cache_hit_rate', 'tag']


def worker(job):
    case, k, plan_path, t1, ms_tab, scene = job
    try:
        import fev
        cfg = fev.config()
        P = fev._modules()  # noqa: SLF001
        plan = json.load(open(plan_path, encoding='utf-8'))
        g = fev.graph(case)
        if scene == 'B':
            r = P['p2'].evaluate_scene_b(
                g, plan, bandwidth=cfg['bandwidth'],
                capacity=dict(cfg['capacity']),
                cross_core_copy_delay=P['cross_core_copy_delay'])
            hit = 0.0
        else:
            import multicore_cut_evaluate_problem_3 as P3
            r = P3.evaluate_problem_3(
                g, plan, bandwidth=cfg['bandwidth'],
                capacity=dict(cfg['capacity']),
                cross_core_copy_delay=P['cross_core_copy_delay'],
                cache_capacity_bytes=P['cache_capacity_bytes'],
                cache_bandwidth_bytes_per_cycle=P['cache_bw'])
            hit = r['cache_stats'].get('hit_rate', 0.0)
        return {'ok': True, 'case': case, 'k': k, 'tab': ms_tab,
                'ms': int(r['makespan']),
                'added': int(r['data_movement_bytes']['added_copy_bytes']),
                'hit': hit, 'T1': t1}
    except Exception:  # noqa: BLE001
        import traceback
        return {'ok': False, 'case': case, 'k': k,
                'err': traceback.format_exc()[-500:]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--summary', required=True)
    ap.add_argument('--plans', required=True)
    ap.add_argument('--scene', default='B', choices=['B', '3'])
    ap.add_argument('--workers', type=int, default=8)
    ap.add_argument('--out', default=None)
    args = ap.parse_args()

    sp = os.path.join(HERE, args.summary)
    rows = list(csv.DictReader(open(sp, encoding='utf-8-sig')))

    # 先定出每个 (用例, 核数) 的胜出行（与 mkcsv.py 的选行规则一致）
    best = {}
    for r in rows:
        if int(r['T1']) <= 0 or int(r['ms']) <= 0:
            continue
        key = (r['case'], int(r['k']))
        if key not in best or int(r['ms']) < int(best[key]['ms']):
            best[key] = r
    need = [(c, k) for (c, k), r in best.items()
            if not (r.get('added_copy_bytes') or '').strip()]
    print('总 %d 行；胜出 %d 行；搬运量缺失的胜出行 %d 行'
          % (len(rows), len(best), len(need)))
    if not need:
        print('无需回填。')
        return

    jobs, noplan = [], []
    for c, k in need:
        p = os.path.join(HERE, args.plans, '%s_k%d.json' % (c[:-5], k))
        if not os.path.exists(p):
            noplan.append((c, k))
            continue
        jobs.append((c, k, p, int(best[(c, k)]['T1']), int(best[(c, k)]['ms']),
                     args.scene))
    if noplan:
        print('缺方案文件（无法回填）：%d' % len(noplan))
        for x in noplan[:10]:
            print('  ', x)

    import multiprocessing as mp
    ctx = mp.get_context('spawn')
    fix, mism = {}, []
    pool = ctx.Pool(args.workers)
    try:
        for i, res in enumerate(pool.imap_unordered(worker, jobs, chunksize=1), 1):
            if not res['ok']:
                print('FAIL %s k=%d %s' % (res['case'], res['k'], res['err']),
                      flush=True)
                continue
            if res['ms'] != res['tab']:
                mism.append((res['case'], res['k'], res['tab'], res['ms']))
            else:
                fix[(res['case'], res['k'])] = res
            print('  %-16s k=%d ms=%-10d added=%-12d [%d/%d]%s'
                  % (res['case'], res['k'], res['ms'], res['added'], i,
                     len(jobs), '  <<< MISMATCH' if res['ms'] != res['tab'] else ''),
                  flush=True)
    finally:
        pool.terminate()
        pool.join()

    n = 0
    for r in rows:
        key = (r['case'], int(r['k']))
        if not (r.get('added_copy_bytes') or '').strip() and key in fix:
            f = fix[key]
            r['added_copy_bytes'] = str(f['added'])
            r['ms'] = str(f['ms'])
            r['speedup'] = '%.6f' % (f['T1'] / f['ms'])
            if f['hit'] and not (r.get('cache_hit_rate') or '').strip():
                r['cache_hit_rate'] = '%.6f' % f['hit']
            n += 1
    out = os.path.join(HERE, args.out or args.summary)
    with open(out, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows([{x: r.get(x, '') for x in FIELDS} for r in rows])

    byk = defaultdict(list)
    for r in rows:
        byk[int(r['k'])].append(float(r['speedup']))
    print('\n回填 %d 行；makespan 不一致 %d 处' % (n, len(mism)))
    for m in mism[:20]:
        print('  MISMATCH', m)
    for k in sorted(byk):
        v = byk[k]
        print('  k=%d n=%d mean=%.4f' % (k, len(v), sum(v) / len(v)))
    print('-> %s' % out)


if __name__ == '__main__':
    main()
