"""report.py — 由合并后的结果表生成问题一的图表与附录。

输入（由 merge.py 产出）：
    out/final/results_problem1.csv   列：case,k,T1,ms,speedup,tag,src
输出（默认同目录）：
    appendix_problem1.csv  逐用例明细（单核基准 / 2-5 核 makespan 与加速比）
    speedup_curve.png      1-5 核平均加速比曲线（含参考论文与理论上界对照）
    speedup_hist.png       5 核逐用例加速比分布
    report_problem1.html   单文件报告（图表以 base64 内嵌）
"""
from __future__ import annotations

import argparse
import base64
import csv
import io
import os
import sys
from collections import defaultdict

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib import font_manager  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

PAPER_CSV = r'C:\Users\xjw\Desktop\华为杯A题\appendix_A_problem1.csv'


def setup_font():
    prefer = ['Microsoft YaHei', 'SimHei', 'Noto Sans CJK SC', 'Source Han Sans SC',
              'WenQuanYi Micro Hei', 'DejaVu Sans']
    have = {f.name for f in font_manager.fontManager.ttflist}
    for name in prefer:
        if name in have:
            plt.rcParams['font.sans-serif'] = [name, 'DejaVu Sans']
            break
    plt.rcParams['axes.unicode_minus'] = False


def load_results(path):
    per = defaultdict(dict)
    t1s = {}
    for r in csv.DictReader(open(path, encoding='utf-8-sig')):
        k = int(r['k'])
        per[r['case']][k] = dict(ms=int(r['ms']), speedup=float(r['speedup']),
                                 tag=r.get('tag', ''))
        t1s[r['case']] = int(r['T1'])
    return per, t1s


def load_paper():
    if not os.path.exists(PAPER_CSV):
        return {}
    out = {}
    for r in csv.DictReader(open(PAPER_CSV, encoding='utf-8-sig')):
        out[r['用例']] = {
            'T1': int(r['单核基准_Makespan']),
            **{k: float(r['问题1_%d核_加速比' % k]) for k in (2, 3, 4, 5)}}
    return out


def mean_curve(per, ks=(1, 2, 3, 4, 5)):
    out = {}
    for k in ks:
        v = [d[k]['speedup'] for d in per.values() if k in d]
        out[k] = (sum(v) / len(v)) if v else None
    return out


def fig_to_b64(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format='png', dpi=150, bbox_inches='tight')
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode('ascii')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dir', default=os.path.join(HERE, 'out', 'final'))
    args = ap.parse_args()
    d = args.dir
    setup_font()

    per, t1s = load_results(os.path.join(d, 'results_problem1.csv'))
    paper = load_paper()
    common = sorted((c for c in per if c in paper), key=lambda s: int(s[5:-5]))
    n = len(per)
    print('用例数 %d；与论文可比 %d' % (n, len(common)))

    # ---------- 附录明细 ----------
    ks = [2, 3, 4, 5]
    ap_rows = []
    for case in sorted(per, key=lambda s: int(s[5:-5])):
        row = {'用例': case, '单核基准_Makespan': t1s[case]}
        for k in ks:
            v = per[case].get(k)
            row['问题1_%d核_Makespan' % k] = v['ms'] if v else ''
            row['问题1_%d核_加速比' % k] = ('%.4f' % v['speedup']) if v else ''
        ap_rows.append(row)
    fields = ['用例', '单核基准_Makespan'] + [
        x for k in ks for x in ('问题1_%d核_Makespan' % k, '问题1_%d核_加速比' % k)]
    ap_csv = os.path.join(d, 'appendix_problem1.csv')
    with open(ap_csv, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(ap_rows)

    # ---------- 曲线 ----------
    mine = mean_curve(per)
    xs = [1, 2, 3, 4, 5]
    fig, ax = plt.subplots(figsize=(7.6, 4.6))
    ax.plot(xs, [mine[k] for k in xs], 'o-', color='#c0392b', lw=2.2,
            ms=7, label='本模型（五核平均加速比 %.4f）' % mine[5])
    if common:
        pv = {}
        for k in ks:
            v = [paper[c][k] for c in common]
            pv[k] = sum(v) / len(v)
        ax.plot(xs, [1.0] + [pv[k] for k in ks], 's--', color='#2980b9', lw=1.8,
                ms=6, label='参考论文（五核 %.4f）' % pv[5])
    ax.plot(xs, xs, ':', color='#7f8c8d', lw=1.4, label='线性加速比上界 y=k')
    ax.set_xlabel('处理器核数 k')
    ax.set_ylabel('平均加速比（100 个用例算术平均）')
    ax.set_title('问题一：1–5 核平均加速比曲线')
    ax.set_xticks(xs)
    ax.grid(alpha=0.3)
    ax.legend(fontsize=9, loc='lower right')
    for k in xs:
        ax.annotate('%.3f' % mine[k], (k, mine[k]), textcoords='offset points',
                    xytext=(4, -12), fontsize=8.5, color='#c0392b')
    curve_b64 = fig_to_b64(fig)
    fig.savefig(os.path.join(d, 'speedup_curve.png'), dpi=150,
                bbox_inches='tight')
    plt.close(fig)

    # ---------- 分布 ----------
    fig, ax = plt.subplots(figsize=(7.6, 4.2))
    v5 = [per[c][5]['speedup'] for c in per if 5 in per[c]]
    ax.hist(v5, bins=[0, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6],
            color='#e67e22', edgecolor='white')
    ax.axvline(sum(v5) / len(v5), color='#c0392b', lw=2,
               label='均值 %.4f' % (sum(v5) / len(v5)))
    ax.set_xlabel('5 核加速比')
    ax.set_ylabel('用例数')
    ax.set_title('问题一：5 核加速比逐用例分布（n=%d）' % len(v5))
    ax.grid(alpha=0.3, axis='y')
    ax.legend(fontsize=9)
    hist_b64 = fig_to_b64(fig)
    fig.savefig(os.path.join(d, 'speedup_hist.png'), dpi=150, bbox_inches='tight')
    plt.close(fig)

    # ---------- HTML ----------
    def rowfmt(r):
        return ('<tr><td>%s</td><td>%s</td>%s</tr>' % (
            r['用例'], r['单核基准_Makespan'],
            ''.join('<td>%s</td><td>%s</td>' % (r['问题1_%d核_Makespan' % k],
                                                r['问题1_%d核_加速比' % k])
                    for k in ks)))

    tbl = '\n'.join(rowfmt(r) for r in ap_rows)
    head = ''.join('<th>%d 核<br>Makespan</th><th>%d 核<br>加速比</th>' % (k, k)
                   for k in ks)
    cmp_summary = ''
    if common:
        mm = set(common)
        mine_c = [per[c][5]['speedup'] for c in common]
        pap_c = [paper[c][5] for c in common]
        win = sum(1 for a, b in zip(mine_c, pap_c) if a > b + 1e-6)
        loss = sum(1 for a, b in zip(mine_c, pap_c) if a < b - 1e-6)
        cmp_summary = ('<p>与参考论文在 %d 个可比用例上：本模型五核平均 <b>%.4f</b>，'
                       '参考论文 <b>%.4f</b>；本模型更优 %d 例，更差 %d 例，持平 %d 例。</p>'
                       % (len(common), sum(mine_c) / len(mine_c),
                          sum(pap_c) / len(pap_c), win, loss,
                          len(common) - win - loss))
    html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<title>2026 研赛 A 题 · 问题一求解报告</title>
<style>
body{{font-family:"Microsoft YaHei",system-ui,sans-serif;max-width:1080px;margin:0 auto;
padding:28px 22px;color:#1f2328;line-height:1.75}}
h1{{font-size:24px;border-bottom:3px solid #c0392b;padding-bottom:10px}}
h2{{font-size:19px;margin-top:34px;color:#c0392b}}
table{{border-collapse:collapse;width:100%;font-size:12.5px;margin:12px 0}}
th,td{{border:1px solid #dcdcdc;padding:5px 7px;text-align:center}}
th{{background:#f5f6f8}} tbody tr:nth-child(even){{background:#fafbfc}}
img{{max-width:100%;border:1px solid #eee;border-radius:6px;margin:10px 0}}
.kpi{{display:flex;gap:14px;flex-wrap:wrap;margin:16px 0}}
.kpi div{{flex:1;min-width:150px;background:#fbf3f2;border-left:4px solid #c0392b;
padding:12px 14px;border-radius:5px}}
.kpi b{{display:block;font-size:22px;color:#c0392b}}
code{{background:#f2f3f5;padding:1px 5px;border-radius:3px;font-size:12.5px}}
</style></head><body>
<h1>2026 中国研究生数学建模竞赛 A 题 · 问题一求解报告</h1>
<div class="kpi">
<div><b>{mine[5]:.4f}</b>五核平均加速比</div>
<div><b>{mine[2]:.4f} / {mine[3]:.4f} / {mine[4]:.4f}</b>二 / 三 / 四核</div>
<div><b>{len(per)}</b>参与统计用例数</div>
</div>
<h2>一、结果曲线</h2>
<img src="data:image/png;base64,{curve_b64}" alt="加速比曲线">
{cmp_summary}
<p>加速比定义：<code>S_k = T_1 / T_k</code>，其中 T_k 为 k 核方案完工时间；100 个用例先各自求比值再取算术平均，与题目口径一致。</p>
<h2>二、逐用例加速比分布</h2>
<img src="data:image/png;base64,{hist_b64}" alt="分布直方图">
<h2>三、附录：逐用例明细</h2>
<table><thead><tr><th>用例</th><th>单核基准<br>Makespan</th>{head}</tr></thead>
<tbody>{tbl}</tbody></table>
</body></html>"""
    html_p = os.path.join(d, 'report_problem1.html')
    open(html_p, 'w', encoding='utf-8').write(html)
    print('曲线   -> %s' % os.path.join(d, 'speedup_curve.png'))
    print('分布   -> %s' % os.path.join(d, 'speedup_hist.png'))
    print('附录   -> %s' % ap_csv)
    print('报告   -> %s' % html_p)


if __name__ == '__main__':
    main()
