"""merge.py — 把多轮跑批的结果合并为"每个 (用例, 核数) 取最优方案"。

每轮跑批目录里都有 summary_all.csv（case,k,T1,ms,speedup,...）与对应方案文件
`<case>_k<k>.json`。本脚本按 makespan 取最小者，把胜出的方案复制到统一目录，
并输出合并后的汇总表，供画图与附录使用。

用法：
    python merge.py --dirs out/runF out/runG out/tw3 --out out/final
"""
from __future__ import annotations

import argparse
import csv
import os
import shutil
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def read_summary(d):
    p = os.path.join(d, 'summary_all.csv')
    if not os.path.exists(p):
        return []
    rows = []
    for r in csv.DictReader(open(p, encoding='utf-8-sig')):
        try:
            rows.append(dict(case=r['case'], k=int(r['k']), T1=int(r['T1']),
                             ms=int(r['ms']), speedup=float(r['speedup']),
                             tag=r.get('tag', ''), src=d))
        except (KeyError, ValueError):
            continue
    # 同一目录内同一 (case,k) 若多次出现，取最优
    best = {}
    for r in rows:
        key = (r['case'], r['k'])
        if key not in best or r['ms'] < best[key]['ms']:
            best[key] = r
    return list(best.values())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dirs', nargs='+', required=True)
    ap.add_argument('--out', required=True)
    args = ap.parse_args()

    best = {}
    for d in args.dirs:
        for r in read_summary(d):
            key = (r['case'], r['k'])
            if key not in best or r['ms'] < best[key]['ms']:
                best[key] = r
    print('合并后 (用例,核数) 条目数：%d' % len(best))

    os.makedirs(args.out, exist_ok=True)
    pdir = os.path.join(args.out, 'plans')
    os.makedirs(pdir, exist_ok=True)
    rows = []
    missing = []
    for (case, k), r in sorted(best.items(), key=lambda kv: (int(kv[0][0][5:-5]),
                                                             kv[0][1])):
        src = os.path.join(r['src'], '%s_k%d.json' % (case[:-5], k))
        if not os.path.exists(src):
            missing.append((case, k, src))
            continue
        dst = os.path.join(pdir, '%s_k%d.json' % (case[:-5], k))
        shutil.copyfile(src, dst)
        rows.append(dict(case=case, k=k, T1=r['T1'], ms=r['ms'],
                         speedup=round(r['T1'] / r['ms'], 6), tag=r['tag'],
                         src=r['src']))

    out_csv = os.path.join(args.out, 'results_problem1.csv')
    with open(out_csv, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['case', 'k', 'T1', 'ms', 'speedup',
                                          'tag', 'src'])
        w.writeheader()
        w.writerows(rows)

    per = defaultdict(dict)
    for r in rows:
        per[r['case']][r['k']] = r['speedup']
    for k in (1, 2, 3, 4, 5):
        v = [d.get(k, 1.0) for d in per.values()]
        print('k=%d  用例=%d  平均加速比=%.4f  最小=%.4f  最大=%.4f'
              % (k, len(v), sum(v) / len(v), min(v), max(v)))
    print('方案目录 -> %s' % pdir)
    print('结果表   -> %s' % out_csv)
    if missing:
        print('缺失方案 %d 个：%s' % (len(missing), missing[:5]))


if __name__ == '__main__':
    main()
