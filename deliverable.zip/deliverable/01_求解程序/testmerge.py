"""验证：同核连续子图合并成单个 Task 的收益。

对照组 A：(core, layer) 分组 —— 每个 (核,层) 一个子图（我目前的做法）
对照组 B：核心亲和拓扑序扫描 + 同核连续段合并 —— 参考论文 1.4 节做法
两者使用完全相同的 ocore（算子->核）映射，差异只在"怎么把算子打包成子图/Task"。
"""
from __future__ import annotations
import json
import os
import sys
import time
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
DATA = os.path.join(HERE, 'data')


def load_view(case):
    import opt as optmod
    g = json.load(open(os.path.join(DATA, case), encoding='utf-8'))
    return optmod.View(g), g


def group_by_core_layer(view, ocore, k):
    lv = defaultdict(int)
    for o in view.topo:
        ps = view.preds[o]
        if not ps:
            lv[o] = 0
        else:
            lv[o] = max(lv[p] + (1 if ocore[p] != ocore[o] else 0) for p in ps)
    buckets = defaultdict(list)
    for o in view.ops:
        buckets[(ocore[o], lv[o])].append(o)
    order = sorted(buckets)
    mapping = {}
    sched = [[] for _ in range(k)]
    for sgid, key in enumerate(order):
        for o in buckets[key]:
            mapping[str(o)] = sgid
        sched[key[0]].append(sgid)
    return {'node_to_subgraph': mapping, 'core_schedules': sched}


def sweep_plan(view, ocore, k):
    """核心亲和拓扑序扫描：同核连续的一段 = 一个子图（自动合并）。"""
    from collections import Counter
    preds, succs, ops = view.preds, view.succs, view.ops
    indeg = {o: len(preds[o]) for o in ops}
    ready = set(o for o in ops if indeg[o] == 0)
    mapping = {}
    sched = [[] for _ in range(k)]
    cur = None
    sgid = -1
    lvv = view.lv
    done = 0
    while ready:
        cnt = Counter(ocore[o] for o in ready)
        # 优先延续当前核；否则选就绪算子最多的核
        if cur is not None and cnt.get(cur, 0) > 0:
            bc = cur
        else:
            # 就绪最多的核；并列时取"层最小"的核以保持拓扑推进
            mx = max(cnt.values())
            cands = [c for c, v in cnt.items() if v == mx]
            bc = min(cands, key=lambda c: min(lvv[o] for o in ready if ocore[o] == c))
        pool = [o for o in ready if ocore[o] == bc]
        o = min(pool, key=lambda x: lvv[x])
        if bc != cur:
            sgid += 1
            sched[bc].append(sgid)
            cur = bc
        mapping[str(o)] = sgid
        ready.discard(o)
        done += 1
        for s in succs[o]:
            indeg[s] -= 1
            if indeg[s] == 0:
                ready.add(s)
    assert done == len(ops)
    return {'node_to_subgraph': mapping, 'core_schedules': sched}


def stats(view, plan):
    by = defaultdict(int)
    for o, s in plan['node_to_subgraph'].items():
        by[s] += 1
    return len(by), max((len(v) for v in plan['core_schedules']), default=0)


def main():
    import fl
    fl.load_fast()
    fl.config()
    import opt as optmod  # 复用分组/装箱

    cases = sys.argv[1:] or ['case_002.json']
    for case in cases:
        view, g = load_view(case)
        # 用同一套启发式构造 ocore：链单元 + LPT
        groups = optmod.groups_chains(view)
        gl = [view_mv(view, gg) for gg in groups]
        gc = optmod.lpt(gl, 5, 'max')
        ocore = {}
        for gi, ops in enumerate(groups):
            for o in ops:
                ocore[o] = gc[gi]
        pa = group_by_core_layer(view, ocore, 5)
        pb = sweep_plan(view, ocore, 5)
        t = time.time(); ma = fl.eval_p1(case, pa)[0]; ta = time.time() - t
        t = time.time(); mb = fl.eval_p1(case, pb)[0]; tb = time.time() - t
        t1 = fl.eval_p1(case, fl.single_plan(g))[0]
        na, sa = stats(view, pa)
        nb, sb = stats(view, pb)
        print('%-14s T1=%8d | (核,层) 任务数=%4d ms=%8d sp=%.3f (%.1fs) | 扫描合并 任务数=%4d ms=%8d sp=%.3f (%.1fs)'
              % (case, t1, na, ma, t1 / ma, ta, nb, mb, t1 / mb, tb))


def view_mv(view, gg):
    m = v = 0
    for o in gg:
        if view.pipe[o] == 'PIPE_M':
            m += view.cyc[o]
        else:
            v += view.cyc[o]
    return (m, v)


if __name__ == '__main__':
    main()
