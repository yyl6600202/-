"""splitfix.py — 对已求得的方案做"超大 Task 再切分"后处理（场景 A / B / 3 通用）。

动机
----
按 (核, 层) 打包子图时，`layer(o) = max_{p∈pred(o)}( layer(p) + [core(p)≠core(o)] )`，
于是一棵"全程同核"的大子树会全部落在同一层 ⇒ 变成**一个巨型 Task**。
巨型 Task 的活跃张量集很大，核内调度第 2 步会频繁换出/换入（spill），
DDR 流量激增 —— 这正是若干"high_spill_risk"用例加速比上不去的主要原因。
反之，把巨型 Task 切成若干块会引入新的跨子图边界 COPY（场景 A 还需 100 cyc/边界），
所以这里不做解析判断，而是**把若干切分阈值都真实评测一遍，取最优**。

合法性
------
把某个子图内的算子按**全局拓扑序**排序后切成连续若干片：跨片边一律向前，
同核顺序仍按原顺序拼接，因此商图无环、同核顺序不违反依赖，方案恒合法。

用法
----
    python splitfix.py --src out/final/plans --t1 out/final/results_problem1.csv \
                       --out out/fixA --scene A --caps 0 4000 1500 600 250 100 40 --workers 4
    其中 caps 中的 0 表示"不切分"（原方案），始终作为保底候选。
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import fev  # noqa: E402
import fl  # noqa: E402
import opt as optmod  # noqa: E402

SUMMARY_FIELDS = ['case', 'k', 'T1', 'ms', 'speedup', 'tag', 'evals', 'secs']


def splits_of(view, plan, max_ops):
    """按全局拓扑序把每个子图切成 <= max_ops 的连续片（max_ops<=0 表示不切）。"""
    n2s = plan['node_to_subgraph']
    sched = plan['core_schedules']
    sg_ops = defaultdict(list)
    for o in view.ops:
        sg = n2s.get(str(o))
        if sg is not None:
            sg_ops[sg].append(o)
    pos = {o: i for i, o in enumerate(view.topo)}
    mapping, new_sched, nxt = {}, [], 0
    for sgs in sched:
        row = []
        for sg in sgs:
            ops = sg_ops.get(sg)
            if not ops:
                continue
            ops.sort(key=lambda o: pos[o])
            if max_ops <= 0 or len(ops) <= max_ops:
                pieces = [ops]
            else:
                cnt = (len(ops) + max_ops - 1) // max_ops
                size = (len(ops) + cnt - 1) // cnt
                pieces = [ops[i:i + size] for i in range(0, len(ops), size)]
            for pc in pieces:
                for o in pc:
                    mapping[str(o)] = nxt
                row.append(nxt)
                nxt += 1
        new_sched.append(row)
    return {'node_to_subgraph': mapping, 'core_schedules': new_sched}


def _scen_eval(case, plan, scene):
    if scene == 'A':
        ms, add, _ = fev.evaluate(case, plan, scene='A')
        return int(ms), int(add)
    ms, add, _ = fev.evaluate(case, plan, scene=scene)
    return int(ms), int(add)


def worker(job):
    case, ks, src, outdir, scene, caps, t1 = job
    t0 = time.time()
    try:
        g = fev.graph(case)
        fev.set_graph(case, g)
        V = optmod.View(g)
        recs = []
        for k in ks:
            p = os.path.join(src, '%s_k%d.json' % (case[:-5], k))
            if not os.path.exists(p):
                continue
            base = json.load(open(p, encoding='utf-8'))
            best = None
            nev = 0
            for cap in caps:
                plan = base if cap <= 0 else splits_of(V, base, cap)
                ms, add = _scen_eval(case, plan, scene)
                nev += 1
                if best is None or ms < best[0]:
                    best = (ms, add, cap, plan)
            ms, add, cap, plan = best
            with open(os.path.join(outdir, '%s_k%d.json' % (case[:-5], k)),
                      'w', encoding='utf-8') as f:
                json.dump(plan, f)
            recs.append(dict(case=case, k=k, T1=t1, ms=ms,
                             speedup=round(t1 / ms, 6),
                             tag='splitcap=%d' % cap, evals=nev,
                             secs=round(time.time() - t0, 1)))
        return {'ok': True, 'case': case,
                'line': '%-16s %s (%.0fs)' % (
                    case, ' '.join('k%d=%.4f' % (r['k'], r['speedup'])
                                   for r in recs), time.time() - t0),
                'recs': recs}
    except Exception:  # noqa: BLE001
        import traceback
        return {'ok': False, 'case': case, 'err': traceback.format_exc()[-1200:]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--src', required=True)
    ap.add_argument('--t1', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--scene', default='A', choices=['A', 'B', '3'])
    ap.add_argument('--cases', nargs='*')
    ap.add_argument('--case-file', default=None)
    ap.add_argument('--ks', nargs='+', type=int, default=[2, 3, 4, 5])
    ap.add_argument('--caps', nargs='+', type=int,
                    default=[0, 4000, 1500, 600, 250, 100, 40])
    ap.add_argument('--workers', type=int, default=4)
    args = ap.parse_args()

    t1map = {}
    for r in csv.DictReader(open(args.t1, encoding='utf-8-sig')):
        t1map[r['case']] = int(r['T1'])

    cases = args.cases or []
    if args.case_file:
        cases = [ln.strip() for ln in open(args.case_file, encoding='utf-8')
                 if ln.strip()]
    if not cases:
        cases = sorted({f.split('_k')[0] + '.json' for f in os.listdir(args.src)
                        if f.startswith('case_') and f.endswith('.json')},
                       key=lambda s: int(s[5:-5]))
    os.makedirs(args.out, exist_ok=True)
    jobs = [(c, args.ks, args.src, args.out, args.scene, args.caps,
             t1map.get(c, 0)) for c in cases]

    sp = os.path.join(args.out, 'summary_all.csv')
    new = not os.path.exists(sp)
    fsum = open(sp, 'a', encoding='utf-8-sig', newline='')
    wsum = csv.DictWriter(fsum, fieldnames=SUMMARY_FIELDS)
    if new:
        wsum.writeheader()
        fsum.flush()

    import multiprocessing as mp
    ctx = mp.get_context('spawn')
    n_ok = 0
    t_start = time.time()
    pool = ctx.Pool(args.workers)
    try:
        for res in pool.imap_unordered(worker, jobs, chunksize=1):
            if not res['ok']:
                print('FAIL %s\n%s' % (res['case'], res['err']), flush=True)
                continue
            n_ok += 1
            for rec in res['recs']:
                wsum.writerow(rec)
            fsum.flush()
            print('%s  [%d/%d]' % (res['line'], n_ok, len(jobs)), flush=True)
    finally:
        pool.terminate()
        pool.join()
        fsum.close()

    rows = list(csv.DictReader(open(sp, encoding='utf-8-sig')))
    byk = defaultdict(list)
    for r in rows:
        byk[int(r['k'])].append(float(r['speedup']))
    print('')
    for k in sorted(byk):
        v = byk[k]
        print('scene %s k=%d n=%d mean=%.4f min=%.4f max=%.4f'
              % (args.scene, k, len(v), sum(v) / len(v), min(v), max(v)))
    print('summary -> %s ; 本轮 %.1fs' % (sp, time.time() - t_start))


if __name__ == '__main__':
    main()
