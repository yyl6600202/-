"""cdiag.py — 同一方案在场景 B / 场景三下的逐算子时间线对照。

目的：定位"加了只读缓存反而变慢"的机制。输出
  · 两场景 makespan 差；
  · 按 Pipe / 内存通路聚合的"结束时间增量"；
  · 命中/未命中的次数与字节量；
  · 增量最大的一批算子明细。
"""
from __future__ import annotations
import json
import os
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fev  # noqa: E402


def run(case, k, d):
    plan = json.load(open(os.path.join(HERE, d, '%s_k%d.json' % (case[:-5], k)),
                          encoding='utf-8'))
    P = fev._modules()  # noqa: SLF001
    cfg = fev.config()
    import multicore_cut_evaluate_problem_3 as P3
    g = fev.graph(case)
    rb = P['p2'].evaluate_scene_b(
        g, plan, bandwidth=cfg['bandwidth'], capacity=dict(cfg['capacity']),
        cross_core_copy_delay=P['cross_core_copy_delay'])
    rc = P3.evaluate_problem_3(
        g, plan, bandwidth=cfg['bandwidth'], capacity=dict(cfg['capacity']),
        cross_core_copy_delay=P['cross_core_copy_delay'],
        cache_capacity_bytes=P['cache_capacity_bytes'],
        cache_bandwidth_bytes_per_cycle=P['cache_bw'])
    return rb, rc


def main():
    case = sys.argv[1] if len(sys.argv) > 1 else 'case_067.json'
    k = int(sys.argv[2]) if len(sys.argv) > 2 else 2
    d = sys.argv[3] if len(sys.argv) > 3 else 'out/finalB'
    print('bandwidth=%s cache_bw=%s cap=%s'
          % (fev.config()['bandwidth'],
             fev._modules()['cache_bw'],  # noqa: SLF001
             fev._modules()['cache_capacity_bytes']))  # noqa: SLF001

    rb, rc = run(case, k, d)
    print('B makespan=%d   C makespan=%d   delta=%d'
          % (rb['makespan'], rc['makespan'], rc['makespan'] - rb['makespan']))
    cs = rc['cache_stats']
    print('hits=%d misses=%d hit_bytes=%d miss_bytes=%d hit_rate=%.4f'
          % (cs['copy_in_hits'], cs['copy_in_misses'], cs['hit_bytes'],
             cs['miss_bytes'], cs['hit_rate']))

    def idx(res):
        out = {}
        for tl in res['per_core_timeline']:
            for e in tl['ops']:
                out[(e['task_id'], e['op_id'])] = e
        return out

    A, B = idx(rb), idx(rc)
    agg = defaultdict(lambda: [0, 0])
    worst = []
    for key in A:
        ea, eb = A[key], B[key]
        d_ = eb['end'] - ea['end']
        tag = (ea['pipe'], ea['op'], eb.get('memory_path', '-'))
        agg[tag][0] += d_
        agg[tag][1] += 1
        if d_ > 0:
            worst.append((d_, key, ea['start'], ea['end'], eb['start'],
                          eb['end'], tag))
    print('\n-- 按 (Pipe, op, C内存通路) 聚合的 end 增量 --')
    for tag, (s, n) in sorted(agg.items(), key=lambda z: -z[1][0])[:14]:
        print('  %-34s sumΔend=%-12d n=%d' % (str(tag), s, n))

    worst.sort(key=lambda z: -z[0])
    print('\n-- end 增量最大的 12 个算子 --')
    for w in worst[:12]:
        print('  Δ=%-10d %-16s startB=%-10d endB=%-10d startC=%-10d endC=%-10d %s'
              % (w[0], str(w[1]), w[2], w[3], w[4], w[5], w[6]))

    print('\n-- 各核 task end (B / C) --')
    for ca, cb in zip(rb['per_core_timeline'], rc['per_core_timeline']):
        print('  core %d  B=%d  C=%d  Δ=%d'
              % (ca['core_id'], ca['tasks'][0]['end'], cb['tasks'][0]['end'],
                 cb['tasks'][0]['end'] - ca['tasks'][0]['end']))


if __name__ == '__main__':
    main()
