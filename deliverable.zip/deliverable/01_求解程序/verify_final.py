"""verify_final.py — 发布级独立复核。

对最终选定的方案目录，逐个 (用例, 核数) 做两件事：
  1. 用官方合法性检查 validate_multicore_plan 校验方案；
  2. 用**未经任何补丁**的官方评估器**直接**计算 Makespan、总额外搬运量
     （场景 3 另加 Cache 命中率）。
输出 verified_<scene>.csv 与复核报告，作为附录数据来源。

注意：本脚本刻意不 import fl.py（那里的外科补丁只用于搜索加速），
以保证复核走的是完全原始的一份官方代码。
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.join(HERE, 'code')
DATA = os.path.join(HERE, 'data')
sys.path.insert(0, CODE)

import multicore_cut_evaluate_problem_1 as P1  # noqa: E402
import multicore_cut_evaluate_problem_2 as P2  # noqa: E402
import multicore_cut_evaluate_problem_3 as P3  # noqa: E402
from evaluation_validation import (  # noqa: E402
    read_evaluation_config, read_required_settings)
from stub_multicore_cut_and_schedule import validate_multicore_plan  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--plans', required=True)
    ap.add_argument('--scene', default='A', choices=['A', 'B', '3'])
    ap.add_argument('--out', default=None)
    ap.add_argument('--cases', nargs='*')
    ap.add_argument('--ks', nargs='+', type=int, default=[2, 3, 4, 5])
    args = ap.parse_args()

    cfgp = os.path.join(DATA, 'config.txt')
    s = read_evaluation_config(cfgp)
    wa = read_required_settings(
        cfgp, 'multicore_scene_a',
        ('task_cross_core_wait_cycles', 'task_same_core_wait_cycles'))
    wb = P2.read_scene_b_config(cfgp)
    cc = P3.read_cache_config(cfgp)

    cases = args.cases or sorted(
        {f.split('_k')[0] for f in os.listdir(args.plans)
         if f.startswith('case_') and f.endswith('.json')},
        key=lambda x: int(x[5:]))
    cases = [c[:-5] if c.endswith('.json') else c for c in cases]
    rows, bad = [], []
    t_start = time.time()
    for c in cases:
        case = c + '.json'
        g = json.load(open(os.path.join(DATA, case), encoding='utf-8'))
        # T1：官方核内调度在整图上算单核基准
        t1 = P1.evaluate_scene_a(
            g, {'node_to_subgraph': {str(o['id']): 0 for o in g['ops']
                                     if o.get('op') not in ('COPY_IN', 'COPY_OUT')},
                'core_schedules': [[0]]},
            bandwidth=s['bandwidth'], capacity=s['capacity'],
            cross_core_wait=wa['task_cross_core_wait_cycles'],
            same_core_wait=wa['task_same_core_wait_cycles'])['makespan']
        for k in args.ks:
            p = os.path.join(args.plans, '%s_k%d.json' % (c, k))
            if not os.path.exists(p):
                continue
            plan = json.load(open(p, encoding='utf-8'))
            try:
                validate_multicore_plan(g, plan)
            except Exception as exc:  # noqa: BLE001
                bad.append((case, k, 'ILLEGAL', repr(exc)[:200]))
                continue
            try:
                if args.scene == 'A':
                    r = P1.evaluate_scene_a(
                        g, plan, bandwidth=s['bandwidth'],
                        capacity=s['capacity'],
                        cross_core_wait=wa['task_cross_core_wait_cycles'],
                        same_core_wait=wa['task_same_core_wait_cycles'])
                    hit = None
                elif args.scene == 'B':
                    r = P2.evaluate_scene_b(
                        g, plan, bandwidth=s['bandwidth'],
                        capacity=s['capacity'],
                        cross_core_copy_delay=wb['cross_core_copy_delay_cycles'])
                    hit = None
                else:
                    r = P3.evaluate_problem_3(
                        g, plan, bandwidth=s['bandwidth'],
                        capacity=s['capacity'],
                        cross_core_copy_delay=wb['cross_core_copy_delay_cycles'],
                        cache_capacity_bytes=cc['cache_capacity_bytes'],
                        cache_bandwidth_bytes_per_cycle=(
                            cc['cache_bandwidth_bytes_per_cycle']))
                    hit = r['cache_stats'].get('hit_rate')
            except Exception as exc:  # noqa: BLE001
                bad.append((case, k, 'EVAL_FAIL', repr(exc)[:200]))
                continue
            ms = r['makespan']
            rows.append(dict(scene=args.scene, case=case, k=k, T1=t1, ms=ms,
                             speedup=round(t1 / ms, 6),
                             added_copy_bytes=r['data_movement_bytes'][
                                 'added_copy_bytes'],
                             cache_hit_rate=('%.6f' % hit) if hit is not None else ''))
        print('%-16s ok  (%.0fs)' % (case, time.time() - t_start), flush=True)

    out = args.out or os.path.join(
        os.path.dirname(args.plans), 'verified_%s.csv' % args.scene)
    with open(out, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['scene', 'case', 'k', 'T1', 'ms',
                                          'speedup', 'added_copy_bytes',
                                          'cache_hit_rate'])
        w.writeheader()
        w.writerows(sorted(rows, key=lambda r: (int(r['case'][5:-5]), r['k'])))
    print('\n不合法/失败 %d 份' % len(bad))
    for b in bad[:20]:
        print('  ', b)
    from collections import defaultdict
    byk = defaultdict(list)
    for r in rows:
        byk[r['k']].append(r['speedup'])
    for k in sorted(byk):
        v = byk[k]
        print('scene %s k=%d n=%d mean=%.4f min=%.4f max=%.4f'
              % (args.scene, k, len(v), sum(v) / len(v), min(v), max(v)))
    print('-> %s' % out)


if __name__ == '__main__':
    main()
