"""fl.py — 快速评测基座（不改官方源文件，只在内存里做等价外科补丁）。

补丁仅替换“每轮扫全集做完成判据”的 O(N) 检查为 O(1) 计数器；
判据只依赖可累加量，且置位点在全文件中唯一（用 count==1 断言保证）。
"""
from __future__ import annotations

import json
import os
import sys
import types

HERE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.join(HERE, 'code')
DATA = os.path.join(HERE, 'data')
if CODE not in sys.path:
    sys.path.insert(0, CODE)


def load_patched(module_name, path, patches, register=False):
    src = open(path, encoding='utf-8').read()
    for old, new in patches:
        cnt = src.count(old)
        if cnt != 1:
            raise RuntimeError('anchor not unique (%d): %r' % (cnt, old[:160]))
        src = src.replace(old, new)
    mod = types.ModuleType(module_name)
    mod.__file__ = path
    if register:
        sys.modules[module_name] = mod
    exec(compile(src, path, 'exec'), mod.__dict__)
    return mod


# ---------------- schedule_step3 ----------------
STEP3_PATCHES = [
    (
        "    op_status = {op_id: 'pending' for op_id in op_by_id}\n"
        "    pred_remaining = {op_id: len(preds[op_id]) for op_id in op_by_id}",
        "    op_status = {op_id: 'pending' for op_id in op_by_id}\n"
        "    _done_count = [0]\n"
        "    _total_ops = len(op_by_id)\n"
        "    pred_remaining = {op_id: len(preds[op_id]) for op_id in op_by_id}",
    ),
    (
        "        if all(status == 'done' for status in op_status.values()):",
        "        if _done_count[0] == _total_ops:",
    ),
    (
        "                    op_status[op_id] = 'done'",
        "                    op_status[op_id] = 'done'\n"
        "                    _done_count[0] += 1",
    ),
]

# ---------------- multicore_cut_evaluate_problem_1 ----------------
P1_PATCHES = [
    (
        "    task_status = {task_id: 'waiting' for task_id in tasks}",
        "    task_status = {task_id: 'waiting' for task_id in tasks}\n"
        "    _task_done_ops = {task_id: 0 for task_id in tasks}\n"
        "    _task_total_ops = {task_id: len(tasks[task_id]['seq']) for task_id in tasks}\n"
        "    _active_task_ids = set()\n"
        "    _done_task_count = [0]\n"
        "    _task_succs = {task_id: [] for task_id in tasks}\n"
        "    for _t, _info in tasks.items():\n"
        "        for _p in _info['pred_tasks']:\n"
        "            _task_succs[_p].append(_t)\n"
        "    _preds_left = {task_id: len(tasks[task_id]['pred_tasks']) for task_id in tasks}\n"
        "    _xcore_ready = {task_id: 0 for task_id in tasks}",
    ),
    (
        "        task_status[task_id] = 'active'",
        "        task_status[task_id] = 'active'\n"
        "        _active_task_ids.add(task_id)",
    ),
    (
        "                op_status[item] = 'done'",
        "                op_status[item] = 'done'\n"
        "                _task_done_ops[task_id] += 1",
    ),
    (
        "    def task_release_time(task_id):\n"
        "        task = tasks[task_id]\n"
        "        core_id = task['core_id']\n"
        "        if any(task_status[pred] != 'done' for pred in task['pred_tasks']):\n"
        "            return None\n"
        "        release = 0\n"
        "        if core_previous_end[core_id] is not None:\n"
        "            release = core_previous_end[core_id] + same_core_wait\n"
        "        for pred in task['pred_tasks']:\n"
        "            if tasks[pred]['core_id'] != core_id:\n"
        "                release = max(release, task_end[pred] + cross_core_wait)\n"
        "        return release",
        "    def task_release_time(task_id):\n"
        "        task = tasks[task_id]\n"
        "        core_id = task['core_id']\n"
        "        if _preds_left[task_id] != 0:\n"
        "            return None\n"
        "        release = 0\n"
        "        if core_previous_end[core_id] is not None:\n"
        "            release = core_previous_end[core_id] + same_core_wait\n"
        "        if _xcore_ready[task_id] > release:\n"
        "            release = _xcore_ready[task_id]\n"
        "        return release",
    ),
    (
        "        for task_id, status in list(task_status.items()):\n"
        "            if status != 'active':\n"
        "                continue\n"
        "            task_items = [key(task_id, op_id) for op_id in tasks[task_id]['seq']]\n"
        "            if all(op_status[item] == 'done' for item in task_items):\n"
        "                core_id = tasks[task_id]['core_id']\n"
        "                task_status[task_id] = 'done'\n"
        "                task_end[task_id] = now\n"
        "                core_active_task[core_id] = None\n"
        "                core_previous_end[core_id] = now\n"
        "                core_index[core_id] += 1",
        "        for task_id in list(_active_task_ids):\n"
        "            if _task_done_ops[task_id] != _task_total_ops[task_id]:\n"
        "                continue\n"
        "            core_id = tasks[task_id]['core_id']\n"
        "            task_status[task_id] = 'done'\n"
        "            task_end[task_id] = now\n"
        "            _active_task_ids.discard(task_id)\n"
        "            _done_task_count[0] += 1\n"
        "            core_active_task[core_id] = None\n"
        "            core_previous_end[core_id] = now\n"
        "            core_index[core_id] += 1\n"
        "            _finish = task_end[task_id]\n"
        "            for _s in _task_succs[task_id]:\n"
        "                _preds_left[_s] -= 1\n"
        "                if tasks[_s]['core_id'] != core_id:\n"
        "                    _cand = _finish + cross_core_wait\n"
        "                    if _cand > _xcore_ready[_s]:\n"
        "                        _xcore_ready[_s] = _cand",
    ),
    (
        "        if all(status == 'done' for status in task_status.values()):",
        "        if _done_task_count[0] == len(tasks):",
    ),
]

# ---- 任务级缓存：_build_scene_a_tasks 的每个 task 只依赖它的算子集合 ----
# 局部搜索时绝大多数 task 未变化，直接复用 step1/step2/step3 的预处理结果。
_PREP_CACHE_PATCHES = [
    (
        "def _build_scene_a_tasks(graph_json, plan, bandwidth, capacity):",
        "_PREP_CACHE = {}\n"
        "_PREP_CAP = 24000\n"
        "_PREP_GRAPH = [None]\n"
        "\n"
        "\n"
        "def _build_scene_a_tasks(graph_json, plan, bandwidth, capacity):",
    ),
    (
        "    for task_id in plan_view['subgraph_ids']:\n"
        "        task_op_ids = set(plan_view['nodes_by_subgraph'][task_id])\n"
        "        ops = [dict(op_by_id[op_id]) for op_id in sorted(task_op_ids)]",
        "    if _PREP_GRAPH[0] is not graph_json:\n"
        "        _PREP_CACHE.clear()\n"
        "        _PREP_GRAPH[0] = graph_json\n"
        "    for task_id in plan_view['subgraph_ids']:\n"
        "        task_op_ids = set(plan_view['nodes_by_subgraph'][task_id])\n"
        "        _tgt_before = task_graph_copy_traffic\n"
        "        _spill_before = spill_copy_traffic\n"
        "        _gk = frozenset(task_op_ids)\n"
        "        _hit = _PREP_CACHE.get(_gk)\n"
        "        if _hit is not None:\n"
        "            prepared = dict(_hit[0])\n"
        "            task_graph_copy_traffic += _hit[1]\n"
        "            spill_copy_traffic += _hit[2]\n"
        "            prepared.update({\n"
        "                'task_id': task_id,\n"
        "                'core_id': core_by_task[task_id],\n"
        "                'pred_tasks': pred_tasks[task_id],\n"
        "            })\n"
        "            tasks[task_id] = prepared\n"
        "            continue\n"
        "        ops = [dict(op_by_id[op_id]) for op_id in sorted(task_op_ids)]",
    ),
    (
        "        prepared = prepare_step3_execution(\n"
        "            ext_graph, capacity=capacity, bandwidth=bandwidth)\n"
        "        prepared.update({",
        "        prepared = prepare_step3_execution(\n"
        "            ext_graph, capacity=capacity, bandwidth=bandwidth)\n"
        "        if len(_PREP_CACHE) >= _PREP_CAP:\n"
        "            _PREP_CACHE.clear()\n"
        "        _PREP_CACHE[_gk] = (\n"
        "            dict(prepared),\n"
        "            task_graph_copy_traffic - _tgt_before,\n"
        "            spill_copy_traffic - _spill_before)\n"
        "        prepared.update({",
    ),
]

P1_PATCHES = P1_PATCHES + _PREP_CACHE_PATCHES

_cache = {}


def load_fast():
    """装载打过补丁的 schedule_step3 与问题 1 评估器。"""
    if 'p1' in _cache:
        return _cache

    import schedule_step3 as _orig_step3  # noqa: F401  (仅为解析路径)

    step3 = load_patched(
        'schedule_step3', os.path.join(CODE, 'schedule_step3.py'),
        STEP3_PATCHES, register=True)
    p1 = load_patched(
        'p1_fast', os.path.join(CODE, 'multicore_cut_evaluate_problem_1.py'),
        P1_PATCHES, register=False)

    # schedule_step2 也需要被打补丁版 step3 影响（它不依赖 step3，这里仅为保险）
    _cache['step3'] = step3
    _cache['p1'] = p1
    _cache['_orig_step3'] = _orig_step3
    return _cache


CFG = None


def config():
    global CFG
    if CFG is None:
        from evaluation_validation import read_evaluation_config, read_required_settings
        cfgp = os.path.join(DATA, 'config.txt')
        s = read_evaluation_config(cfgp)
        w = read_required_settings(
            cfgp, 'multicore_scene_a',
            ('task_cross_core_wait_cycles', 'task_same_core_wait_cycles'))
        CFG = {
            'bandwidth': s['bandwidth'],
            'capacity': s['capacity'],
            'cross_core_wait': w['task_cross_core_wait_cycles'],
            'same_core_wait': w['task_same_core_wait_cycles'],
        }
    return CFG


_graph_cache = {}
_GRAPH_CAP = 2


def set_graph(name, obj):
    """由外部（求解器）注入已解析的图对象，避免同一案例在内存中保留两份。"""
    _graph_cache.clear()
    _graph_cache[name] = obj
    return obj


def graph(name):
    g = _graph_cache.get(name)
    if g is None:
        with open(os.path.join(DATA, name), encoding='utf-8') as f:
            g = json.load(f)
        if len(_graph_cache) >= _GRAPH_CAP:
            _graph_cache.clear()
        _graph_cache[name] = g
    return g


def eval_p1(case, plan, timing=False):
    """返回 (makespan, added_copy_bytes, seconds)。"""
    import time
    c = load_fast()
    cfg = config()
    g = graph(case if case.endswith('.json') else case + '.json')
    t0 = time.time()
    r = c['p1'].evaluate_scene_a(
        g, plan,
        bandwidth=cfg['bandwidth'], capacity=cfg['capacity'],
        cross_core_wait=cfg['cross_core_wait'],
        same_core_wait=cfg['same_core_wait'])
    dt = time.time() - t0
    return r['makespan'], r['data_movement_bytes']['added_copy_bytes'], (dt if timing else dt)


def single_plan(g):
    eligible = sorted(o['id'] for o in g['ops']
                      if o.get('op') not in ('COPY_IN', 'COPY_OUT'))
    return {'node_to_subgraph': {str(i): 0 for i in eligible},
            'core_schedules': [[0]]}


if __name__ == '__main__':
    names = sys.argv[1:] or ['case_001.json']
    for n in names:
        g = graph(n)
        ms, add, dt = eval_p1(n, single_plan(g), timing=True)
        print('%-16s makespan=%-12d added=%-12d %.2fs' % (n, ms, add, dt))
