"""opt.py — 场景 A 统一求解器 v2。

合法性机制
----------
给每个算子指定核号 core(o)，令
    layer(o) = max_{p in preds(o)} ( layer(p) + [core(p) != core(o)] )，源点为 0
（即"从源点到 o 的路径上跨核次数"的最大值）。则对任意边 u->v：
    layer(v) >= layer(u)，且 layer(u)==layer(v) 时必有 core(u)==core(v)。
于是把同一 (core, layer) 的算子打包成子图、同核子图按 layer 升序排列，
必满足官方校验（商图无环、同核顺序不违反依赖）。
=> 搜索空间 = 算子到核的任意映射，合法性自动成立。

分组（搜索的原子动作单位）
--------------------------
两种粒度，各建一次搜索，取更优：
  A) comp   ：按"波"（level//chunk）内的连通分量分组 —— 适合分量多、可整块并行的图；
  B) chain  ：极大链单元（单前驱并入唯一前驱），适合单连通、链状并行的图。

目标函数为与官方逐位一致的快速评估器 fl.eval_p1。
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import random
import sys
import time
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
DATA = os.path.join(HERE, 'data')


def load_json(name):
    with open(os.path.join(DATA, name), encoding='utf-8') as f:
        return json.load(f)


# ================================================================== 视图
class View:
    def __init__(self, graph, gv=None):
        if gv is None:
            import graphlib2 as G
            gv = G.GraphView(graph)
        self.g = graph
        self.gv = gv
        self.ops = list(gv.eligible)
        self.oset = gv.eligible_set
        self.preds = {o: sorted(p for p in gv.preds[o] if p in self.oset) for o in self.ops}
        self.succs = {o: sorted(s for s in gv.succs[o] if s in self.oset) for o in self.ops}
        self.pipe = {o: gv.pipe[o] for o in self.ops}
        self.cyc = {o: gv.cycles[o] for o in self.ops}
        self.lv, self.topo = gv.levels()

    def m_v(self, ops):
        m = v = 0
        for o in ops:
            if self.pipe[o] == 'PIPE_M':
                m += self.cyc[o]
            else:
                v += self.cyc[o]
        return m, v


# ================================================================== 分组
def groups_components(view, chunk=None):
    """波（level//chunk）内连通分量。chunk=None 表示整图一波。"""
    if chunk is None:
        waves = {0: list(view.ops)}
    else:
        waves = defaultdict(list)
        for o in view.ops:
            waves[view.lv[o] // chunk].append(o)
    groups = []
    for w in sorted(waves):
        pool = set(waves[w])
        seen = set()
        for s in sorted(pool):
            if s in seen:
                continue
            st = [s]
            seen.add(s)
            comp = []
            while st:
                u = st.pop()
                comp.append(u)
                for v in view.succs[u] + view.preds[u]:
                    if v in pool and v not in seen:
                        seen.add(v)
                        st.append(v)
            groups.append(comp)
    return groups


def groups_chains(view):
    parent = {o: o for o in view.ops}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for o in view.topo:
        ps = view.preds[o]
        if len(ps) == 1:
            ra, rb = find(ps[0]), find(o)
            if ra != rb:
                parent[rb] = ra
    idx = {}
    groups = []
    for o in view.ops:
        r = find(o)
        if r not in idx:
            idx[r] = len(groups)
            groups.append([])
        groups[idx[r]].append(o)
    return groups


# ================================================================== 计划构造
def layer_from(view, ocore):
    lv = {}
    for o in view.topo:
        ps = view.preds[o]
        if not ps:
            lv[o] = 0
        else:
            c = ocore[o]
            best = 0
            for p in ps:
                val = lv[p] + (1 if ocore[p] != c else 0)
                if val > best:
                    best = val
            lv[o] = best
    return lv


def build_plan(view, ocore, k):
    lv = layer_from(view, ocore)
    groups = defaultdict(list)
    for o in view.ops:
        groups[(ocore[o], lv[o])].append(o)
    mapping = {}
    sched = [[] for _ in range(k)]
    order = sorted(groups)
    sgid_of = {}
    for sgid, key in enumerate(order):
        sgid_of[key] = sgid
        for o in groups[key]:
            mapping[str(o)] = sgid
    for key in order:
        sched[key[0]].append(sgid_of[key])
    return {'node_to_subgraph': mapping, 'core_schedules': sched}


def plan_from_groups(view, groups, gcore, k):
    ocore = {}
    for gi, ops in enumerate(groups):
        c = gcore[gi]
        for o in ops:
            ocore[o] = c
    return build_plan(view, ocore, k)


# ================================================================== 负载
def group_loads(view, groups):
    return [view.m_v(g) for g in groups]


def lpt(gloads, k, mode='max'):
    n = len(gloads)
    cm = [0] * k
    cv = [0] * k
    out = [0] * n
    if mode == 'max':
        keyf = lambda i: -max(gloads[i])
    elif mode == 'sum':
        keyf = lambda i: -(gloads[i][0] + gloads[i][1])
    else:
        keyf = lambda i: -(4 * gloads[i][0] + gloads[i][1])
    for i in sorted(range(n), key=keyf):
        m, v = gloads[i]
        c = min(range(k), key=lambda c: (max(cm[c] + m, cv[c] + v), cm[c] + cv[c]))
        out[i] = c
        cm[c] += m
        cv[c] += v
    return out


def seed_locality(view, groups, gloads, k, lam):
    """按组拓扑序逐个放置：代价 = 负载 + lam * 已确定的跨核边数。
    对"单连通巨型结构"能自动切成若干带局部性的片。"""
    n = len(groups)
    gidx = {}
    glv = [0] * n
    for gi, ops in enumerate(groups):
        for o in ops:
            gidx[o] = gi
        glv[gi] = max(view.lv[o] for o in ops)
    order = sorted(range(n), key=lambda gi: glv[gi])
    cm = [0] * k
    cv = [0] * k
    out = [0] * n
    placed = set()
    for gi in order:
        m, v = gloads[gi]
        ops = groups[gi]
        # 已放置的跨组邻居
        nb = []
        for o in ops:
            for p in view.preds[o]:
                gp = gidx[p]
                if gp != gi and gp in placed:
                    nb.append(gp)
            for s in view.succs[o]:
                gs = gidx[s]
                if gs != gi and gs in placed:
                    nb.append(gs)
        best = None
        for c in range(k):
            score = max(cm[c] + m, cv[c] + v) + lam * sum(1 for gp in nb if out[gp] != c)
            if best is None or score < best[0]:
                best = (score, c)
        c = best[1]
        out[gi] = c
        placed.add(gi)
        cm[c] += m
        cv[c] += v
    return out


# ================================================================== 搜索
def search(view, groups, gloads, k, ev, budget_s, rng, note='', heavy=False):
    t0 = time.time()
    n = len(groups)
    evals = [0]
    best_ms = None
    best_gc = None
    best_tag = ''

    def run(gc):
        ms = ev(plan_from_groups(view, groups, gc, k))
        evals[0] += 1
        return ms

    cands = [('lpt_max', lpt(gloads, k, 'max'))]
    if heavy:
        cands.append(('loc20000', seed_locality(view, groups, gloads, k, 20000)))
    else:
        for mode in ('sum', 'm4'):
            cands.append(('lpt_%s' % mode, lpt(gloads, k, mode)))
        for lam in (5000, 20000, 80000):
            cands.append(('loc%d' % lam, seed_locality(view, groups, gloads, k, lam)))
        cands.append(('rr', [i % k for i in range(n)]))
    for tag, gc in cands:
        ms = run(gc)
        if best_ms is None or ms < best_ms:
            best_ms, best_gc, best_tag = ms, list(gc), tag
    if heavy:
        return best_ms, best_gc, best_tag + note, evals[0], time.time() - t0

    cur = list(best_gc)
    cur_ms = best_ms
    order = list(range(n))
    stalled = 0
    while time.time() - t0 < budget_s:
        rng.shuffle(order)
        improved = False
        for u in order:
            if time.time() - t0 >= budget_s:
                break
            base = cur[u]
            lb = cur_ms
            lc = base
            for c in range(k):
                if c == base:
                    continue
                cur[u] = c
                ms = run(cur)
                if ms < lb:
                    lb, lc = ms, c
            cur[u] = lc
            if lb < cur_ms:
                cur_ms = lb
                improved = True
                if cur_ms < best_ms:
                    best_ms, best_gc, best_tag = cur_ms, list(cur), 'desc'
            else:
                cur[u] = base
        if not improved:
            stalled += 1
            if stalled >= 1:
                break
    return best_ms, best_gc, best_tag + note, evals[0], time.time() - t0


# ================================================================== 单案例
def run_case(case, ks, budget_s, seed=12345, verbose=False):
    import fl
    g = load_json(case)
    view = View(g)
    fl.load_fast()
    fl.config()
    t1 = fl.eval_p1(case, fl.single_plan(g))[0]

    def ev(plan):
        return fl.eval_p1(case, plan)[0]

    t = time.time()
    ev(build_plan(view, {o: 0 for o in view.ops}, 1))
    dt = max(1e-3, time.time() - t)

    variants = []
    heavy = dt > 2.0
    chunks = (None, 16, 64) if heavy else (None, 4, 8, 16, 32, 64)
    for chunk in chunks:
        gs = groups_components(view, chunk)
        if gs:
            variants.append(('comp%s' % (chunk if chunk else 'all'), gs))
    variants.append(('chain', groups_chains(view)))

    out = []
    for k in ks:
        if k == 1:
            out.append(dict(case=case, k=1, T1=t1, ms=t1, sp=1.0, tag='single',
                            evals=0, secs=0.0, plan=fl.single_plan(g),
                            groups=None))
            continue
        rng = random.Random(seed + k)
        budget = budget_s
        if heavy:
            budget = 1.0
        best = None
        for name, gs in variants:
            gl = group_loads(view, gs)
            ms, gc, tag, evs, secs = search(view, gs, gl, k, ev, budget, rng,
                                           heavy=heavy)
            if best is None or ms < best[0]:
                best = (ms, gc, tag + '/' + name, evs, secs, gs)
        ms, gc, tag, evs, secs, gs = best
        out.append(dict(case=case, k=k, T1=t1, ms=ms, sp=t1 / ms, tag=tag,
                        evals=evs, secs=round(secs, 1),
                        plan=plan_from_groups(view, gs, gc, k), groups=gs))
    return out


# ================================================================== 批处理
def worker(job):
    case, ks, budget_s, seed = job
    t0 = time.time()
    try:
        rows = run_case(case, ks, budget_s, seed)
        for r in rows:
            r.pop('groups', None)
            r['secs_'] = round(time.time() - t0, 1)
        return {'ok': True, 'rows': rows}
    except Exception:  # noqa: BLE001
        import traceback
        return {'ok': False, 'case': case, 'err': traceback.format_exc()[-1200:]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--cases', nargs='*')
    ap.add_argument('--ks', nargs='+', type=int, default=[2, 3, 4, 5])
    ap.add_argument('--out', required=True)
    ap.add_argument('--budget', type=float, default=8.0)
    ap.add_argument('--workers', type=int, default=12)
    ap.add_argument('--seed', type=int, default=12345)
    ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--only', type=int, default=0)
    args = ap.parse_args()

    cases = args.cases
    if not cases:
        cases = sorted((f for f in os.listdir(DATA)
                        if f.startswith('case_') and f.endswith('.json')
                        and f[5:-5].isdigit()), key=lambda s: int(s[5:-5]))
    if args.limit:
        cases = cases[:args.limit]
    if args.only:
        cases = cases[:args.only]
    os.makedirs(args.out, exist_ok=True)
    jobs = [(c, args.ks, args.budget, args.seed) for c in cases]

    import multiprocessing as mp
    ctx = mp.get_context('spawn')
    rows_all = []
    t_start = time.time()
    with ctx.Pool(args.workers) as pool:
        for res in pool.imap_unordered(worker, jobs, chunksize=1):
            if not res['ok']:
                print('FAIL %s\n%s' % (res['case'], res['err']), flush=True)
                continue
            for r in res['rows']:
                p = os.path.join(args.out, '%s_k%d.json' % (r['case'][:-5], r['k']))
                with open(p, 'w', encoding='utf-8') as f:
                    json.dump(r['plan'], f)
                rows_all.append(dict(case=r['case'], k=r['k'], T1=r['T1'],
                                     ms=r['ms'], speedup=r['sp'], tag=r['tag'],
                                     evals=r['evals'], secs=r['secs_']))
            print('%-16s %s (%.0fs)' % (res['rows'][0]['case'],
                  ' '.join('k%d=%.3f' % (r['k'], r['sp']) for r in res['rows']),
                  time.time() - t_start), flush=True)

    rows_all.sort(key=lambda r: (r['case'], r['k']))
    p = os.path.join(args.out, 'summary_all.csv')
    with open(p, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['case', 'k', 'T1', 'ms', 'speedup',
                                          'tag', 'evals', 'secs'])
        w.writeheader()
        w.writerows(rows_all)
    byk = defaultdict(list)
    for r in rows_all:
        byk[r['k']].append(r['speedup'])
    print('')
    for k in sorted(byk):
        v = byk[k]
        print('k=%d  n=%d  mean=%.4f  min=%.4f  max=%.4f' % (
            k, len(v), sum(v) / len(v), min(v), max(v)))
    print('summary -> %s ; total %.1fs' % (p, time.time() - t_start))


if __name__ == '__main__':
    main()
