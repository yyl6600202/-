"""splice_verify.py — 方案变更后，只对"变了"的用例重跑官方复核并拼进 verified_A.csv。

判据：把官方复核表 verified_A.csv 与搜索侧结果表 results_problem1.csv（fl 等价加速版）
逐 (case,k) 比对，凡 makespan 不一致的用例视为"方案已变"，只对这些用例重跑
`verify_mp.py`（未打补丁的官方评估器），再用新值替换旧行。

用法：
    python splice_verify.py --plans out/final/plans --workers 4
"""
from __future__ import annotations
import argparse, csv, os, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable
F = os.path.join(HERE, 'out', 'final')


def load(p):
    d = {}
    if not os.path.exists(p):
        return d
    for r in csv.DictReader(open(p, encoding='utf-8-sig')):
        d[(r['case'], int(r['k']))] = r
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--plans', default='out/final/plans')
    ap.add_argument('--scene', default='A')
    ap.add_argument('--verified', default=os.path.join(F, 'verified_A.csv'))
    ap.add_argument('--fl', default=os.path.join(F, 'results_problem1.csv'))
    ap.add_argument('--workers', type=int, default=4)
    args = ap.parse_args()

    ver = load(args.verified)
    flr = load(args.fl)
    changed = sorted({c for (c, k), r in flr.items()
                      if (c, k) not in ver or int(ver[(c, k)]['ms']) != int(r['ms'])},
                     key=lambda s: int(s[5:-5]))
    print('官方表 %d 条；搜索表 %d 条；需重跑用例 %d 个' % (len(ver), len(flr), len(changed)))
    if not changed:
        print('无需重跑。')
        return
    print(' ', ' '.join(changed))
    tmp = os.path.join(HERE, 'out', 'splice_tmp.csv')
    r = subprocess.run([PY, '-u', os.path.join(HERE, 'verify_mp.py'),
                        '--plans', args.plans, '--scene', args.scene,
                        '--out', tmp, '--cases'] + changed +
                       ['--workers', str(args.workers)], cwd=HERE)
    if r.returncode != 0:
        print('verify_mp 失败 rc=%d' % r.returncode)
        return
    new = load(tmp)
    n = 0
    for key, row in new.items():
        ver[key] = row
        n += 1
    fields = ['scene', 'case', 'k', 'T1', 'ms', 'speedup', 'added_copy_bytes',
              'cache_hit_rate']
    with open(args.verified, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for key in sorted(ver, key=lambda z: (int(z[0][5:-5]), z[1])):
            w.writerow({x: ver[key].get(x, '') for x in fields})
    from collections import defaultdict
    byk = defaultdict(list)
    for key, row in ver.items():
        byk[key[1]].append(float(row['speedup']))
    print('替换 %d 行 -> %s' % (n, args.verified))
    for k in sorted(byk):
        v = byk[k]
        print('  scene %s k=%d n=%d mean=%.4f' % (args.scene, k, len(v),
                                                  sum(v) / len(v)))


if __name__ == '__main__':
    main()
