"""mgverify.py — 位集增量判据 TI.ok() 与官方 legal(merge) 的逐切点一致性检验。"""
from __future__ import annotations
import json, os, sys, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fl, opt as optmod                      # noqa: E402
import mergetask as mt                        # noqa: E402

DATA = os.path.join(HERE, 'data')
PLANS = os.path.join(HERE, 'out/final/plans')
fl.load_fast(); fl.config()

CASES = [('case_003.json', 5), ('case_062.json', 5), ('case_073.json', 5),
         ('case_092.json', 5), ('case_039.json', 5), ('case_016.json', 5),
         ('case_016.json', 3), ('case_085.json', 4), ('case_024.json', 5)]

tot = mis = 0
for case, k in CASES:
    g = json.load(open(os.path.join(DATA, case), encoding='utf-8'))
    fl.set_graph(case, g)
    V = optmod.View(g); mt.prep(V)
    plan = json.load(open(os.path.join(PLANS, '%s_k%d.json' % (case[:-5], k)),
                          encoding='utf-8'))
    st = mt.state_of(V, plan, k)
    t0 = time.perf_counter(); ti = mt.TI(st); t_ti = time.perf_counter() - t0
    bad = 0; nb = 0; il = 0
    t0 = time.perf_counter()
    for c in range(k):
        for i in range(len(st[c]) - 1):
            nb += 1
            fast = ti.ok(c, i)
            slow = mt.legal(mt.merge_at(st, c, i))
            if fast != slow:
                bad += 1
                if bad <= 3:
                    print('   MISMATCH c=%d i=%d fast=%s slow=%s' % (c, i, fast, slow))
            if not slow:
                il += 1
    t_fast = time.perf_counter() - t0
    # 顺序贪心连做：验证结果仍合法
    ref = [ti]
    trial, na = mt.apply_b(st, ti, 24, ref)
    ok = mt.legal(trial)
    print('%-16s k%d ntask=%-4d cand=%-4d illegal=%-3d mismatch=%d  TI=%.0fms  '
          '24merges=%d legal=%s' % (case, k, sum(len(x) for x in st), nb, il, bad,
                                    t_ti * 1e3, na, ok), flush=True)
    tot += nb; mis += bad
print('TOTAL cand=%d mismatch=%d' % (tot, mis))
