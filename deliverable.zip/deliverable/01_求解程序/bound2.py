"""bound2.py — 把"算子不可分割"纳入下界，判断 ms/LB 的乐观程度。

原 gap.py 的 LB = max(ΣM/k, ΣV/k, CP)。但每个算子是**原子不可分**的，因此
    LB_real = max( ΣM/k, max_o M(o), ΣV/k, max_o V(o), CP )
若某用例被一个巨型算子主导，则 ms/LB_real ≈ 1，说明"看起来的 5 倍余量"其实是假的。

另输出：最大的 3 个算子占 ΣM 的比例、最大单算子周期占 T1 的比例、以及
"最大算子决定的速度比上限" cap = T1 / max_op。

用法：python bound2.py [--k 5] [--top 30]
"""
from __future__ import annotations

import argparse
import collections
import csv
import json
import os
import statistics as st

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data')
F = os.path.join(HERE, 'out', 'final')


def analyze(case, k):
    g = json.load(open(os.path.join(DATA, case), encoding='utf-8'))
    cyc, pipe = {}, {}
    for o in g['ops']:
        cyc[o['id']] = int(o.get('cycles', 0))
        pipe[o['id']] = o.get('op')
    pm = pv = 0
    opm, opv = [], []
    for o in g['ops']:
        if o.get('op') in ('COPY_IN', 'COPY_OUT'):
            continue
        c = int(o.get('cycles', 0))
        if o['pipe'] == 'PIPE_M':
            pm += c
            opm.append(c)
        else:
            pv += c
            opv.append(c)
    pred = collections.defaultdict(list)
    for e in g.get('edges', ()):
        pred[e['target']].append(e['source'])
    succ = collections.defaultdict(list)
    for t, ss in pred.items():
        if t not in cyc:
            continue
        for s in ss:
            if s in cyc:
                succ[s].append(t)
    indeg = {n: 0 for n in cyc}
    for u in succ:
        for v in succ[u]:
            indeg[v] += 1
    q = collections.deque([n for n in cyc if indeg[n] == 0])
    dist = {n: cyc[n] for n in cyc}
    while q:
        u = q.popleft()
        for v in succ[u]:
            if dist[u] + cyc[v] > dist[v]:
                dist[v] = dist[u] + cyc[v]
            indeg[v] -= 1
            if indeg[v] == 0:
                q.append(v)
    cp = max(dist.values()) if dist else 0
    tot_ddr = sum(t['size'] for t in g.get('tensors', ())
                  if t.get('pos') == 'DDR')
    del g, pred, succ, dist
    opm.sort(reverse=True)
    opv.sort(reverse=True)
    mx = max(opm[0] if opm else 0, opv[0] if opv else 0)
    lb = max(pm / k, pv / k, cp)
    lb2 = max(pm / k, pv / k, cp, mx)
    return dict(case=case, pm=pm, pv=pv, cp=cp, maxop=mx, lb=lb, lb2=lb2,
                top3=sum(opm[:3]) / pm if pm else 0,
                ddr=tot_ddr / 60.0,
                big=opm[:5] + opv[:5])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--k', type=int, default=5)
    ap.add_argument('--top', type=int, default=35)
    ap.add_argument('--csv', default=os.path.join(F, 'results_problem1.csv'))
    args = ap.parse_args()

    ms, t1 = {}, {}
    for r in csv.DictReader(open(args.csv, encoding='utf-8-sig')):
        if int(r['k']) == args.k:
            ms[r['case']] = int(r['ms'])
            t1[r['case']] = int(r['T1'])

    rows = []
    for case in sorted(ms, key=lambda s: int(s[5:-5])):
        d = analyze(case, args.k)
        d.update(ms=ms[case], T1=t1[case], sp=t1[case] / ms[case])
        d['r1'] = ms[case] / max(d['lb'], 1)
        d['r2'] = ms[case] / max(d['lb2'], 1)
        d['cap'] = t1[case] / max(d['maxop'], 1)
        rows.append(d)

    rows.sort(key=lambda r: -r['r1'])
    print('k=%d   LB  = max(ΣM/k,ΣV/k,CP)          LB2 = LB ∪ {max_op}' % args.k)
    print('%-14s %-10s %-7s %-10s %-11s %-7s %-7s %-7s %-7s %-7s' % (
        'case', 'ms', 'speedup', 'LB', 'max_op', 'ms/LB', 'ms/LB2',
        'top3/ΣM', 'cap', 'ddr_cyc'))
    for r in rows[:args.top]:
        print('%-14s %-10d %-7.3f %-10.0f %-11d %-7.3f %-7.3f %-7.3f %-7.2f %-7.0f'
              % (r['case'], r['ms'], r['sp'], r['lb'], r['maxop'], r['r1'],
                 r['r2'], r['top3'], r['cap'], r['ddr']))
    print('...')
    print('n=%d  mean sp=%.4f  mean ms/LB=%.3f  mean ms/LB2=%.3f' % (
        len(rows), st.mean(r['sp'] for r in rows),
        st.mean(r['r1'] for r in rows), st.mean(r['r2'] for r in rows)))
    for thr in (1.2, 1.4, 1.6, 2.0):
        b2 = [r for r in rows if r['r2'] > thr]
        g2 = sum(r['T1'] / (r['lb2'] * thr) - r['sp'] for r in b2) / len(rows)
        print('  按 LB2: ratio>%.1f: %2d 例 → 均值最多 +%.4f' % (thr, len(b2), g2))
    n1 = sum(1 for r in rows if r['sp'] > r['cap'] + 1e-9)
    print('  speedup 超过"最大算子上限 cap" 的用例数（应为 0）:', n1)
    print('  cap<2 的用例数（被巨型算子钉死）:',
          sum(1 for r in rows if r['cap'] < 2))


if __name__ == '__main__':
    main()
