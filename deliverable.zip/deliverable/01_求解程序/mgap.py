"""mgap.py — 由 mgscan.csv 生成合并目标清单 out/mgap.txt（每行 "case_xxx.json k"）。
排序依据：可合并切点数 ncand 降序（切点越多 ⇒ 任务越碎 ⇒ 合并余地越大）。"""
from __future__ import annotations
import csv, os
HERE = os.path.dirname(os.path.abspath(__file__))
O = os.path.join(HERE, 'out')
MINC = int(os.environ.get('MINC', '8'))
rows = [r for r in csv.DictReader(open(os.path.join(O, 'mgscan.csv'),
                                       encoding='utf-8-sig'))
        if int(r['ncand']) >= MINC]
rows.sort(key=lambda r: (-int(r['ncand']), r['k']))
out = os.path.join(O, 'mgap.txt')
with open(out, 'w', encoding='utf-8') as f:
    for r in rows:
        f.write('%s %s\n' % (r['case'], r['k']))
print('MINC=%d  pairs=%d  -> %s' % (MINC, len(rows), out))
from collections import Counter
print('按 k 分布:', dict(Counter(r['k'] for r in rows)))
print('ncand 总和:', sum(int(r['ncand']) for r in rows))
print('前 20:')
for r in rows[:20]:
    print('  %-16s k=%s ncand=%s' % (r['case'], r['k'], r['ncand']))
