"""graphlib2.py — 通用图工具：op DAG、层、链覆盖、原子打包、计划构造与校验。"""
from __future__ import annotations

import heapq
from collections import defaultdict, deque


class GraphView:
    def __init__(self, graph):
        ops = graph['ops']
        self.ops = ops
        self.op_by_id = {o['id']: o for o in ops}
        self.op_ids = set(self.op_by_id)
        self.eligible = [o['id'] for o in ops if o.get('op') not in ('COPY_IN', 'COPY_OUT')]
        self.eligible_set = set(self.eligible)
        tset = {t['id'] for t in graph['tensors']}
        self.tensor_ids = tset
        out_t = defaultdict(list)
        in_t = defaultdict(list)
        for e in graph['edges']:
            s, d = e['source'], e['target']
            if s in self.op_ids and d not in self.op_ids:
                out_t[s].append(d)
            elif s not in self.op_ids and d in self.op_ids:
                in_t[d].append(s)
        self.out_t, self.in_t = out_t, in_t
        prod = defaultdict(set)
        for oid, ts in out_t.items():
            for t in ts:
                prod[t].add(oid)
        preds = {o['id']: set() for o in ops}
        for oid, ts in in_t.items():
            for t in ts:
                preds[oid] |= {p for p in prod.get(t, ()) if p != oid}
        # 单管周期
        self.pipe = {o['id']: o['pipe'] for o in ops}
        self.cycles = {o['id']: int(o.get('cycles', 0)) for o in ops}
        self.preds = preds
        succs = defaultdict(set)
        for o, ps in preds.items():
            for p in ps:
                succs[p].add(o)
        self.succs = succs
        self.tensor_size = {t['id']: t['size'] for t in graph['tensors']}

    # ---------- 拓扑与层 ----------
    def topo(self, nodes=None):
        nodes = self.eligible_set if nodes is None else set(nodes)
        indeg = {}
        for n in nodes:
            indeg[n] = sum(1 for p in self.preds[n] if p in nodes)
        ready = [n for n in nodes if indeg[n] == 0]
        heapq.heapify(ready)
        out = []
        while ready:
            u = heapq.heappop(ready)
            out.append(u)
            for v in sorted(self.succs[u]):
                if v in nodes:
                    indeg[v] -= 1
                    if indeg[v] == 0:
                        heapq.heappush(ready, v)
        return out

    def levels(self, nodes=None):
        nodes = self.eligible_set if nodes is None else set(nodes)
        order = self.topo(nodes)
        lv = {}
        for n in order:
            ps = [p for p in self.preds[n] if p in nodes]
            lv[n] = 0 if not ps else 1 + max(lv[p] for p in ps)
        return lv, order

    def blevel(self, nodes=None):
        """bottom-level：到汇点的最长路径（含自身 cycles），用于关键路径优先。"""
        nodes = self.eligible_set if nodes is None else set(nodes)
        order = self.topo(nodes)
        bl = {}
        for n in reversed(order):
            best = 0
            for s in self.succs[n]:
                if s in nodes:
                    best = max(best, bl[s])
            bl[n] = self.cycles[n] + best
        return bl

    def chain_cover(self, nodes=None, cap=None):
        """贪心最长链覆盖：反复取出剩余子图的最长路径。"""
        nodes = set(self.eligible_set if nodes is None else nodes)
        rem = set(nodes)
        chains = []
        while rem:
            order = self.topo(rem)
            dist = {}
            parent = {}
            for n in order:
                dist[n] = self.cycles[n]
                parent[n] = None
            for n in order:
                for s in self.succs[n]:
                    if s in rem and dist[n] + self.cycles[s] > dist[s]:
                        dist[s] = dist[n] + self.cycles[s]
                        parent[s] = n
            end = max(order, key=lambda n: (dist[n], -n))
            path = []
            cur = end
            while cur is not None:
                path.append(cur)
                cur = parent[cur]
            path.reverse()
            chains.append(path)
            rem -= set(path)
            if cap and len(chains) >= cap:
                break
        return chains


def plan_from_core_map(graph, core_of, num_cores, order_hint=None):
    """core_of: {op_id: core}；每个核一个子图，sgid == core。"""
    mapping = {str(op): int(c) for op, c in core_of.items()}
    schedules = [[] for _ in range(num_cores)]
    used = sorted(set(mapping.values()))
    for c in used:
        schedules[c] = [c]
    return {'node_to_subgraph': mapping, 'core_schedules': schedules}


def plan_from_chunks(graph, chunks, num_cores):
    """chunks: list of (core, [ops]) -> 每个 chunk 一个子图；同核内按给定次序排。"""
    mapping = {}
    schedules = [[] for _ in range(num_cores)]
    for sgid, (core, ops) in enumerate(chunks):
        for o in ops:
            mapping[str(o)] = sgid
        schedules[core].append(sgid)
    return {'node_to_subgraph': mapping, 'core_schedules': schedules}


def validate(graph, plan):
    from stub_multicore_cut_and_schedule import validate_multicore_plan
    try:
        validate_multicore_plan(graph, plan)
        return True, ''
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)[:200]


def quotient_edges(gv, mapping, nodes=None):
    """跨子图依赖对 (src_sg, dst_sg)。"""
    nodes = gv.eligible_set if nodes is None else set(nodes)
    pairs = set()
    for u in nodes:
        su = mapping[u]
        for v in gv.succs[u]:
            if v in nodes and mapping[v] != su:
                pairs.add((su, mapping[v]))
    return pairs


def acyclic(pairs, nodes):
    """pairs 中只保留两端都在 nodes 里的边，判断是否有环。"""
    nodes = set(nodes)
    adj = defaultdict(set)
    indeg = {n: 0 for n in nodes}
    for a, b in pairs:
        if a in nodes and b in nodes and b not in adj[a]:
            adj[a].add(b)
            indeg[b] += 1
    ready = [n for n in nodes if indeg[n] == 0]
    seen = 0
    while ready:
        u = ready.pop()
        seen += 1
        for v in adj[u]:
            indeg[v] -= 1
            if indeg[v] == 0:
                ready.append(v)
    return seen == len(nodes)
