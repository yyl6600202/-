"""fev.py — 三个场景的统一评测入口（全部直接调用官方评估器，不做任何数值改写）。

场景：
    A  问题一（每个子图一个 Task；同核 100、跨核 1000）
    B  问题二（每核合并为一个 Task；跨核 COPY 500）
    3  问题三（同 B，另加只读 FIFO L2 Cache 1MB @250B/cyc）

T1（单核基准）在三个场景下完全相同：单核方案没有跨核搬运，也没有 Cache 参与。
"""
from __future__ import annotations

import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.join(HERE, 'code')
DATA = os.path.join(HERE, 'data')
if CODE not in sys.path:
    sys.path.insert(0, CODE)

import fl  # noqa: E402  （场景 A 的快速评测，已逐位验证）

_P = {}
_CFG = {}
_GRAPH = {}
_GRAPH_CAP = 2


def _modules():
    if 'p2' in _P:
        return _P
    import multicore_cut_evaluate_problem_2 as p2
    import multicore_cut_evaluate_problem_3 as p3
    _P['p2'] = p2
    _P['p3'] = p3
    cfgp = os.path.join(DATA, 'config.txt')
    cb = p2.read_scene_b_config(cfgp)
    cc = p3.read_cache_config(cfgp)
    _P['cross_core_copy_delay'] = cb['cross_core_copy_delay_cycles']
    _P['cache_capacity_bytes'] = cc['cache_capacity_bytes']
    _P['cache_bw'] = cc['cache_bandwidth_bytes_per_cycle']
    return _P


def config():
    if not _CFG:
        _CFG.update(fl.config())
    return _CFG


def graph(name):
    g = _GRAPH.get(name)
    if g is None:
        with open(os.path.join(DATA, name), encoding='utf-8') as f:
            g = json.load(f)
        if len(_GRAPH) >= _GRAPH_CAP:
            _GRAPH.clear()
        _GRAPH[name] = g
    return g


def set_graph(name, obj):
    _GRAPH.clear()
    _GRAPH[name] = obj
    try:
        fl.set_graph(name, obj)
    except Exception:  # noqa: BLE001  场景 A 未装载时忽略
        pass
    return obj


def evaluate(case, plan, scene='A', timing=False):
    """返回 (makespan, added_copy_bytes, seconds)。"""
    P = _modules()
    cfg = config()
    g = graph(case if case.endswith('.json') else case + '.json')
    cap = dict(cfg['capacity'])
    t0 = time.time()
    try:
        if scene in ('A', 'a', '1'):
            ms, add, _ = fl.eval_p1(case, plan, timing=True)
            return ms, add, (time.time() - t0 if timing else time.time() - t0)
        if scene in ('B', 'b', '2'):
            r = P['p2'].evaluate_scene_b(
                g, plan, bandwidth=cfg['bandwidth'], capacity=cap,
                cross_core_copy_delay=P['cross_core_copy_delay'])
        else:
            r = P['p3'].evaluate_problem_3(
                g, plan, bandwidth=cfg['bandwidth'], capacity=cap,
                cross_core_copy_delay=P['cross_core_copy_delay'],
                cache_capacity_bytes=P['cache_capacity_bytes'],
                cache_bandwidth_bytes_per_cycle=P['cache_bw'])
    finally:
        dt = time.time() - t0
    return r['makespan'], r['data_movement_bytes']['added_copy_bytes'], dt


if __name__ == '__main__':
    names = sys.argv[1:] or ['case_001.json']
    for n in names:
        g = graph(n)
        plan = fl.single_plan(g)
        for sc in ('A', 'B', '3'):
            ms, add, dt = evaluate(n, plan, scene=sc, timing=True)
            print('%-16s scene=%s makespan=%-10d added=%-10d %.2fs'
                  % (n, sc, ms, add, dt))
