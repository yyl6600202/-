"""xprobe.py — 场景三"空命中率行"官方重算探针。

对 out/final3 中被指定为"空 cache_hit_rate"的 (case,k)，用**未打补丁**的官方
问题三评估器重算磁盘上的方案，打印与汇总表 ms 的差异。
"""
from __future__ import annotations
import argparse
import csv
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fev  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--sel', default='out/xprobe_sel.txt')
    ap.add_argument('--plans', default='out/final3')
    args = ap.parse_args()

    want = []
    for ln in open(os.path.join(HERE, args.sel), encoding='utf-8'):
        ln = ln.strip()
        if ln:
            c, k = ln.split()
            want.append((c, int(k)))

    tab = {}
    for r in csv.DictReader(open(os.path.join(HERE, 'out', 'final3',
                                              'summary_all.csv'),
                                 encoding='utf-8-sig')):
        tab[(r['case'], int(r['k']))] = r

    cfg = fev.config()
    P = fev._modules()  # noqa: SLF001
    import multicore_cut_evaluate_problem_3 as P3

    for case, k in want:
        p = os.path.join(HERE, args.plans, '%s_k%d.json' % (case[:-5], k))
        plan = json.load(open(p, encoding='utf-8'))
        r = P3.evaluate_problem_3(
            fev.graph(case), plan, bandwidth=cfg['bandwidth'],
            capacity=cfg['capacity'],
            cross_core_copy_delay=P['cross_core_copy_delay'],
            cache_capacity_bytes=P['cache_capacity_bytes'],
            cache_bandwidth_bytes_per_cycle=P['cache_bw'])
        ms = int(r['makespan'])
        old = tab.get((case, k))
        oms = int(old['ms']) if old else -1
        print('%-16s k=%d  表=%d  实测=%d  %s  hit=%.6f  add=%d'
              % (case, k, oms, ms, 'SAME' if ms == oms else '**DIFF**',
                 r['cache_stats'].get('hit_rate', 0.0),
                 int(r['data_movement_bytes']['added_copy_bytes'])), flush=True)


if __name__ == '__main__':
    main()
