"""exp_lit.py — 文献/参考实现启发的候选族实测（场景 A）。

新增两个**当前求解器没有**的候选族：
  (1) intcut  : 拓扑区间 + 张量级跨缝代价 DP（参考 solver2.boundary_span_costs /
                gen_topo_cut_min）。跨缝代价在「连续 k 段划分」下**可分离**，
                故可用 DP 在「边界搬运 + 负载偏差」之间最优折中。
  (2) ladder  : 阶梯窗口（参考 gen_ladder）：核窗口序列按拓扑层非降 ——
                恒合法，且在层内可获得并行度。

用法：
    python exp_lit.py case_073 case_062 ...        # 默认 k=5
    python exp_lit.py k=3 case_073
"""
from __future__ import annotations

import json
import os
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import fl  # noqa: E402
import opt as optmod  # noqa: E402
import testmerge as TM  # noqa: E402

DATA = os.path.join(HERE, 'data')
PLANS = os.path.join(HERE, 'out', 'final', 'plans')


# ------------------------------------------------------------------ 跨缝代价
def boundary_span_costs(V, order):
    """拓扑序上每条切缝 j 的张量级跨缝流量。O(N + T)。"""
    gv = V.gv
    ts, out_t, in_t = gv.tensor_size, gv.out_t, gv.in_t
    n = len(order)
    pos = {o: i for i, o in enumerate(order)}
    diff = [0.0] * (n + 2)
    for t, sz in ts.items():
        ps = [pos[p] for p in out_t.get(t, ()) if p in pos]
        cs = [pos[c] for c in in_t.get(t, ()) if c in pos]
        if not cs:
            continue
        if ps:
            lo, hi = min(ps) + 1, max(cs)
        else:
            lo, hi = min(cs) + 1, max(cs)
        if lo > hi:
            continue
        diff[lo] += sz
        if hi + 1 <= n - 1:
            diff[hi + 1] -= sz
    w = [0.0] * n
    acc = 0.0
    for j in range(1, n):
        acc += diff[j]
        w[j] = acc
    return w


def assign_segments(order, cuts):
    cuts = sorted(cuts)
    core_of, seg, ci = {}, 0, 0
    for i, v in enumerate(order):
        while ci < len(cuts) and i == cuts[ci]:
            seg += 1
            ci += 1
        core_of[v] = seg
    return core_of


def intcut_ocore(V, k, balance=1.0, weight='bytes'):
    order = V.topo
    n = len(order)
    if n <= 1 or k <= 1:
        return {v: 0 for v in order}
    if weight == 'bytes':
        w = boundary_span_costs(V, order)
    else:
        w = [0.0] * n
        pos = {o: i for i, o in enumerate(order)}
        for u in order:
            iu = pos[u]
            for v2 in V.succs[u]:
                iv = pos[v2]
                if iv <= iu + 1:
                    continue
                for j in range(iu + 1, iv):
                    w[j] += 1.0
    kk = min(k, n)
    cyc = [V.cyc[v] for v in order]
    pre = [0.0] * (n + 1)
    for i, c in enumerate(cyc):
        pre[i + 1] = pre[i] + c
    tot = pre[n] or 1.0
    target = tot / kk
    lam = balance * tot / max(1, kk)
    denom = max(1.0, target)
    scale = 1.0
    if weight == 'bytes':
        scale = tot / max(1.0, sum(w[1:n]) or 1.0) * 0.5
    cand = list(range(1, n))
    S = len(cand)
    if S > 4000:
        cand = sorted(sorted(cand, key=lambda j: (w[j], j))[:max(320, 16 * kk)])
        S = len(cand)
    if S < kk - 1:
        return assign_segments(order, cand)
    INF = float('inf')
    dp = [[INF] * S for _ in range(kk)]
    bk = [[-1] * S for _ in range(kk)]
    for i in range(S):
        load = pre[cand[i]]
        dp[1][i] = scale * w[cand[i]] + lam * abs(load - target) / denom
    for g in range(2, kk):
        for i in range(g - 1, S):
            best, bh = INF, -1
            for h in range(g - 2, i):
                if dp[g - 1][h] == INF:
                    continue
                load = pre[cand[i]] - pre[cand[h]]
                v = dp[g - 1][h] + scale * w[cand[i]] + lam * abs(load - target) / denom
                if v < best:
                    best, bh = v, h
            dp[g][i] = best
            bk[g][i] = bh
    best, bi = INF, -1
    for i in range(kk - 2, S):
        if dp[kk - 1][i] == INF:
            continue
        load = pre[n] - pre[cand[i]]
        v = dp[kk - 1][i] + lam * abs(load - target) / denom
        if v < best:
            best, bi = v, i
    if bi < 0:
        return assign_segments(order, cand[:kk - 1])
    cuts, g, i = [], kk - 1, bi
    while g >= 1 and i >= 0:
        cuts.append(cand[i])
        i = bk[g][i]
        g -= 1
    return assign_segments(order, cuts)


def ladder_ocore(V, k, mode='work', split=0.5, mwin=2):
    lv = V.lv
    D = max(lv.values()) + 1 if lv else 1
    wl = [0.0] * D
    for v in V.ops:
        wl[lv[v]] += V.cyc[v]
    tot = sum(wl) or 1.0
    km = k - 1
    out = []
    if mode == 'head':
        for l in range(D):
            out.append((0, km) if l == 0 else (km, km))
    elif mode == 'tail':
        for l in range(D):
            out.append((0, km) if l == D - 1 else (0, 0))
    elif mode == 'uniform':
        for l in range(D):
            out.append((min(km, (l * km) // max(D - 1, 1)),
                        min(km, ((l + 1) * km) // max(D - 1, 1))))
    elif mode == 'two':
        c = min(D - 1, max(0, int(round(split * D)) - 1))
        m = min(max(1, mwin), k)
        for l in range(D):
            out.append((0, m - 1) if l <= c else (m - 1, km))
    else:
        acc = 0.0
        for l in range(D):
            a = min(km, int(round(km * acc / tot)))
            acc += wl[l]
            b = min(km, int(round(km * acc / tot)))
            out.append((a, max(a, b)))
    aa, bb, fixed = 0, 0, []
    for a, b in out:
        a = max(aa, min(max(0, a), km))
        b = max(a, bb, min(max(0, b), km))
        aa, bb = a, b
        fixed.append((a, b))
    load = [0.0] * k
    core_of = {}
    for v in sorted(V.ops, key=lambda x: (lv[x], x)):
        a, b = fixed[lv[v]]
        best, bs = a, None
        for c in range(a, b + 1):
            if bs is None or load[c] < bs:
                best, bs = c, load[c]
        core_of[v] = best
        load[best] += V.cyc[v]
    return core_of


def ladder_ocore_bal(V, k, mode='work', split=0.5, mwin=2, pipe=False):
    """同 ladder，但窗口内按 M/V 双流水线负载选择（更贴近真实核内下界）。"""
    lv = V.lv
    D = max(lv.values()) + 1 if lv else 1
    wl = [0.0] * D
    for v in V.ops:
        wl[lv[v]] += V.cyc[v]
    tot = sum(wl) or 1.0
    km = k - 1
    from collections import defaultdict as _dd
    out = []
    if mode == 'uniform':
        for l in range(D):
            out.append((min(km, (l * km) // max(D - 1, 1)),
                        min(km, ((l + 1) * km) // max(D - 1, 1))))
    elif mode == 'two':
        c = min(D - 1, max(0, int(round(split * D)) - 1))
        m = min(max(1, mwin), k)
        for l in range(D):
            out.append((0, m - 1) if l <= c else (m - 1, km))
    elif mode == 'head':
        for l in range(D):
            out.append((0, km) if l == 0 else (km, km))
    elif mode == 'tail':
        for l in range(D):
            out.append((0, km) if l == D - 1 else (0, 0))
    else:
        acc = 0.0
        for l in range(D):
            a = min(km, int(round(km * acc / tot)))
            acc += wl[l]
            b = min(km, int(round(km * acc / tot)))
            out.append((a, max(a, b)))
    aa, bb, fixed = 0, 0, []
    for a, b in out:
        a = max(aa, min(max(0, a), km))
        b = max(a, bb, min(max(0, b), km))
        aa, bb = a, b
        fixed.append((a, b))
    lm = [0.0] * k
    lv_ = [0.0] * k
    core_of = {}
    for v in sorted(V.ops, key=lambda x: (lv[x], x)):
        a, b = fixed[lv[v]]
        best, bs = a, None
        for c in range(a, b + 1):
            s = max(lm[c] + (V.cyc[v] if V.pipe[v] == 'PIPE_M' else 0),
                    lv_[c] + (V.cyc[v] if V.pipe[v] != 'PIPE_M' else 0))
            if bs is None or s < bs:
                best, bs = c, s
        core_of[v] = best
        if V.pipe[v] == 'PIPE_M':
            lm[best] += V.cyc[v]
        else:
            lv_[best] += V.cyc[v]
    return core_of


# ------------------------------------------------------------------ 主流程
def ev_plan(case, plan):
    cfg = fl.config()
    p1 = fl.load_fast()['p1']
    g = fl.graph(case)
    r = p1.evaluate_scene_a(g, plan, bandwidth=cfg['bandwidth'],
                            capacity=cfg['capacity'],
                            cross_core_wait=cfg['cross_core_wait'],
                            same_core_wait=cfg['same_core_wait'])
    return r


def main():
    args = sys.argv[1:]
    ks = [5]
    cases = []
    for a in args:
        if a.startswith('k='):
            ks = [int(x) for x in a[2:].split(',')]
        else:
            cases.append(a if a.endswith('.json') else a + '.json')
    fl.load_fast()
    fl.config()
    for case in cases:
        g = json.load(open(os.path.join(DATA, case), encoding='utf-8'))
        fl.set_graph(case, g)
        V = optmod.View(g)
        for k in ks:
            # 当前方案基线
            pp = os.path.join(PLANS, '%s_k%d.json' % (case[:-5], k))
            base_ms = None
            if os.path.exists(pp):
                rr = ev_plan(case, json.load(open(pp, encoding='utf-8')))
                base_ms = rr['makespan']
            cands = []
            for bal in (0.0, 0.5, 2.0, 8.0, 32.0, 128.0):
                for wt in ('bytes', 'count'):
                    cands.append(('intcut_%s_b%g' % (wt, bal),
                                  intcut_ocore(V, k, balance=bal, weight=wt)))
            for mode in ('work', 'uniform', 'two', 'head', 'tail'):
                cands.append(('ladder_' + mode, ladder_ocore(V, k, mode=mode)))
            for mode in ('work', 'uniform', 'two'):
                cands.append(('ladderB_' + mode, ladder_ocore_bal(V, k, mode=mode)))
            print('==== %s k=%d   base_ms=%s' % (case, k, base_ms))
            best = None
            for name, ocore in cands:
                oc = {o: (c if c < k else k - 1) for o, c in ocore.items()}
                plan = TM.group_by_core_layer(V, oc, k)
                ntask = len(set(plan['node_to_subgraph'].values()))
                try:
                    r = ev_plan(case, plan)
                except Exception as e:  # noqa: BLE001
                    print('   %-18s ILLEGAL %s' % (name, str(e)[:60]))
                    continue
                ms = r['makespan']
                sp = r['data_movement_bytes'].get('spill_added_copy_bytes', 0)
                pc = r['data_movement_bytes'].get('partition_added_copy_bytes', 0)
                mark = ''
                if base_ms and ms < base_ms:
                    mark = '  <== BETTER %+.4f' % ((base_ms - ms) / base_ms * 100)
                    if best is None or ms < best[1]:
                        best = (name, ms, plan)
                print('   %-18s ms=%-10d ntask=%-4d part=%-9d spill=%-9d%s'
                      % (name, ms, ntask, pc, sp, mark))
            if best:
                out = os.path.join(HERE, 'out', 'litplans')
                os.makedirs(out, exist_ok=True)
                json.dump(best[2], open(os.path.join(
                    out, '%s_k%d.json' % (case[:-5], k)), 'w', encoding='utf-8'))
                print('   BEST %s saved (ms=%d, base=%d)' % (best[0], best[1], base_ms))
            print()


if __name__ == '__main__':
    main()
