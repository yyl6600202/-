"""package_all.py — 组装最终交付目录（覆盖问题一 / 二 / 三）。

产出（工作区同级 `deliverable/`，并额外打一个 zip 便于发送）：
    deliverable/
      README.md                 交付说明与复现步骤
      01_求解程序/               算法与工具脚本（可复现）
      02_评测器/                 赛题官方评估器 + data/config.txt（原样只读副本）
      03_结果数据/               发布级复核 CSV、逐用例附表、方案 JSON
      04_图表/                   加速比曲线与分布图
      05_报告/                   单文件 HTML 报告（图表内嵌 base64）
      deliverable.zip
"""
from __future__ import annotations

import os
import shutil
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DIST = os.path.join(ROOT, 'deliverable')

SOLVER = ['solve_final.py', 'sceneBC.py', 'mergetask.py', 'litfix.py', 'exp_lit.py',
          'fev.py', 'fl.py', 'opt.py', 'px.py',
          'testmerge.py', 'graphlib2.py', 'merge.py', 'mergeA.py', 'mergeBC.py',
          'harvest.py', 'mkA.py', 'mkcsv.py', 'splice_verify.py', 'finalize.py',
          'verify_mp.py', 'verify_final.py', 'verify_patch.py', 'judge_patch.py',
          'appendix.py', 'gen_paper.py', 'gap.py', 'bound2.py', 'bound3.py',
          'diag3.py', 'splitfix.py', 'mgscan.py', 'mgap.py', 'mgverify.py',
          'mkcaselist.py', 'status.py', 'report.py', 'bounds.py', 'collect.py',
          'xreuse.py', 'xprobe.py', 'abcprobe.py', 'cdiag.py', 'cdiag2.py',
          'addfix.py', 'hitfix.py', 'figs2.py', 'dx.py', 'package_all.py']

README = """# 2026 中国研究生数学建模竞赛 A 题（华为）· 多核切图与调度

> 本目录为可复现交付物：求解程序、官方评测器副本、发布级结果数据、图表与单文件报告。

## 一、目录结构

| 目录 | 内容 |
| --- | --- |
| `01_求解程序/` | 主求解器 `solve_final.py`、场景 B/三复用通道 `sceneBC.py`、统一评测入口 `fev.py`、加速层 `fl.py`、聚簇与装箱 `opt.py`/`px.py`、合并 `merge.py`、发布级复核 `verify_mp.py`、附表 `appendix.py`、论文生成 `gen_paper.py` |
| `02_评测器/` | 赛题官方评估器原样副本（`code/`）与固定配置（`data/config.txt`），**未作任何修改** |
| `03_结果数据/` | `verified_A/B/3.csv`（官方评估器直接算出的逐用例结果）、`appendix_problem1/2/3.csv`（论文附表）、`plans_*/`（逐用例逐核数方案 JSON） |
| `04_图表/` | 1–5 核平均加速比曲线、5 核逐用例分布、问题三对比曲线等 |
| `05_报告/` | `paper.html`（单文件，图表已 base64 内嵌） |

## 二、核心结论（详见 `05_报告/paper.html`）

加速比定义 `S_k = T_1 / T_k`，100 个用例先各自求比值、再取算术平均；单核基准
`T_1` 由官方核内调度算法在整图上计算，`S_1 = 1`。

| 核数 k | 问题一（场景 A） | 问题二（场景 B） | 问题三（只读 L2 Cache） |
| --- | --- | --- | --- |
%(TABLE)s

## 三、算法要点

1. **单调分层放置定理**：给定任意 算子→核 映射 `c:O→{0..k-1}`，令
   `layer(o) = max_{p∈pred(o)} ( layer(p) + [c(p)≠c(o)] )`，按 `(核, 层)` 打包成子图、
   同核按层升序执行，则商图必无环、同核顺序必不违反依赖。**合法性由构造保证**，
   于是"带约束的切图 + 分核 + 排序"退化为无约束的"算子分核"，任意邻域移动都保持可行。
2. **多粒度聚簇**：链式（单前驱并查集）/ 组内拓扑切片（`cap = 2…512`）/ 弱连通分量 /
   重边匹配多级（HEM）。其中"按组内拓扑序切片"解决了巨型单元（实测出现 944 算子的
   不可分单元）把加速比钉死在 1.0× 的问题。
3. **代理筛选 + 真实精评**：用任务级事件仿真 `px.proxy` 对（粒度 × 种子）候选排序，
   只对前 N 个调用官方评估器精评；再对胜出粒度做代理爬山与（轻图）精评爬山。
4. **单调化**：k 核可空置一核无损模拟 k−1 核方案，故强制 `M_k ≤ M_{k−1}`；
   出现回落时回退少核方案并补空核。
5. **任务级合并算子**（`mergetask.py`）：诊断发现"Task 边界搬运"与"核内 spill"
   是同一份数据流动的两个出口（实测 case_073 两种极端下额外 DDR 搬运总量近似守恒 ≈140 MB），
   且核内多个 Task 串行执行会让 M/V 流水线无法跨 Task 重叠。因此新增"同核相邻 Task 合并"
   算子。合法性判据上有一个必须记录的陷阱：**"起点合法 ⇒ 合并必合法"是错的**——
   若同核相邻任务 A、B 之间有依赖边 A→T、T→B，则 A、B 各自与原图都不成环，但收缩 A∪B 后
   m 与 T 互相可达而成环。正确判据是"存在 a 的依赖后继 x≠b 使 x 可达 b"，
   用任务级 DAG 的可达闭包（位集）实现后单次判断降到 O(|dep_out(a)|) 次大整数或运算，
   在 case_016（1521 个切点、1216 个非法）等 9 组用例上与官方 `validate_task_order`
   判据逐切点比对 **0 处不一致**。配合"批量线搜索"（一次试验连做 b 个已验证合法的合并再评估一次）
   使每次官方评估推进的合并步数提高一个量级。
   收益边界：以碎切方案为种子时 case_073（5 核）Makespan 由 3 410 135 降到 2 767 415（−18.9%）；
   但在已收敛的最终方案上重跑，93 个高切点组合中仅 1 个改进（+0.12%）。
6. **问题二/三的复用**：场景 B 的可行解集合包含场景 A 的解，故以问题一最优方案为种子，
   再用对应场景的官方评估器实测择优（`sceneBC.py`）。问题三仅 `COPY_IN` 查询 FIFO Cache，
   核内 spill 不参与缓存，这一点在建模时已确认。
7. **文献候选族对照（负结果）**：把参考实现的两族场景 A 生成器——拓扑连续切段
   （张量级跨缝代价 DP）与阶梯窗口——完整移植实测（`exp_lit.py` / `litfix.py`）。
   其一，把这两族并入候选池后在 **5 核下 ms/LB 最大的 26 个最困难用例**上穷举对照
   （每例 27 个候选、预算 180 秒），结果 **26 例 0 胜出**，故不作为主表示；
   其二，唯一胜出的例子出现在另一批次（case_039 5 核 382 707 → 327 297，+14.5%），
   因此仍保留为候补候选族，由官方评估器逐例裁决。
8. **下界的诚实口径**（`bound2.py` / `bound3.py`）：三层可计算下界
   `max(Σpipe/k, D0/B, 加权关键路径)` 中，带宽与关键路径几乎从不成为最紧下界；
   并且**"算子不可分割"不是瓶颈**——平均最大单算子仅 1507 周期，前 3 大算子合计
   不超过 ΣM 的 18%。故流水线下界 6.21 与实际 3.72 的差距<b>不能</b>用"粒度不够细"解释，
   而应归因于跨核每跳固定 1000 周期的同步、切分新增的 DDR 往返，以及核内 Pipe 无法完全重叠。

## 四、复现步骤

```bash
# 0) 目录约定：本 README 所在目录为工作区根，data/ 与 code/ 见 02_评测器/
# 1) 问题一：多粒度聚簇 + 装箱 + 代理/精评爬山（每用例每核数一个方案）
python 01_求解程序/solve_final.py --ks 2 3 4 5 --out out/runA --budget 20 --workers 2
# 2) 合并多轮结果，按 makespan 取最优
python 01_求解程序/merge.py --dirs out/runA --out out/final
# 3) 问题二 / 问题三：复用问题一方案 + 对应场景精评
python 01_求解程序/sceneBC.py --scene B --src out/final/plans --t1 out/final/results_problem1.csv --out out/finalB --workers 4
python 01_求解程序/sceneBC.py --scene 3 --src out/final/plans --t1 out/final/results_problem1.csv --out out/final3 --workers 4
# 4) 发布级复核（直接用**未经补丁**的官方评估器）
python 01_求解程序/verify_mp.py --plans out/final/plans  --scene A --out out/final/verified_A.csv --workers 4
python 01_求解程序/verify_mp.py --plans out/finalB        --scene B --out out/final/verified_B.csv --workers 4
python 01_求解程序/verify_mp.py --plans out/final3        --scene 3 --out out/final/verified_3.csv --workers 4
# 5) 附表、图表与报告
python 01_求解程序/appendix.py  --dir out/final
python 01_求解程序/gen_paper.py --dir out/final --out out/final/paper.html
```

> 说明：搜索阶段使用的 `fl.py` 是官方场景 A 评估程序的等价加速实现（仅把 O(N) 的
> 完成检查改写为 O(1) 计数器、并缓存 Task 级预处理）。**论文中所有数值均来自
> `verify_mp.py` 调用的未经修改的官方评估器**（并先用官方 `validate_multicore_plan`
> 校验方案合法性）。
>
> 等价性证据（`verify_patch.py` + `judge_patch.py`）：对 100 个用例做"补丁版 vs 未打补丁"
> 的 makespan 比对，初次有 5 例（case_002/062/063/082/085）与一份第三方历史汇总表不一致；
> 随后用**未打补丁**的官方实现直接复核这 5 例，两版结果完全相同（例如 case_002 均为
> 261 945），差异来自第三方表的历史口径。故可确认补丁与官方逐位一致。
"""


def cp(src, dst, isdir=False):
    if not os.path.exists(src):
        print('  skip(缺失) %s' % src)
        return False
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if isdir:
        # 用 dirs_exist_ok 覆盖式同步，避免 rmtree（部分环境对批量删除有安全拦截）
        shutil.copytree(src, dst, dirs_exist_ok=True)
    else:
        shutil.copyfile(src, dst)
    print('  ok   %s' % os.path.relpath(dst, DIST))
    return True


def mean_of(csv_path, ks=(1, 2, 3, 4, 5)):
    import csv as _csv
    if not os.path.exists(csv_path):
        return {}
    acc = {}
    for r in _csv.DictReader(open(csv_path, encoding='utf-8-sig')):
        acc.setdefault(int(r['k']), []).append(float(r['speedup']))
    out = {1: 1.0}
    for k, v in acc.items():
        out[k] = sum(v) / len(v)
    return out


def main():
    print('组装交付目录 -> %s' % DIST)
    os.makedirs(DIST, exist_ok=True)
    for f in SOLVER:
        cp(os.path.join(HERE, f), os.path.join(DIST, '01_求解程序', f))
    cp(os.path.join(HERE, 'code'), os.path.join(DIST, '02_评测器', 'code'), True)
    cp(os.path.join(HERE, 'data', 'config.txt'),
       os.path.join(DIST, '02_评测器', 'data', 'config.txt'))

    F = os.path.join(HERE, 'out', 'final')
    for f in ('results_problem1.csv', 'verified_A.csv', 'verified_B.csv',
              'verified_3.csv', 'appendix_problem1.csv', 'appendix_problem2.csv',
              'appendix_problem3.csv'):
        cp(os.path.join(F, f), os.path.join(DIST, '03_结果数据', f))
    for name, src in (('plans_A', os.path.join(F, 'plans')),
                      ('plans_B', os.path.join(HERE, 'out', 'finalB')),
                      ('plans_C', os.path.join(HERE, 'out', 'final3'))):
        cp(src, os.path.join(DIST, '03_结果数据', name), True)

    figs = sorted(f for f in os.listdir(F) if f.endswith('.png'))
    for f in figs:
        cp(os.path.join(F, f), os.path.join(DIST, '04_图表', f))
    cp(os.path.join(F, 'paper.html'),
       os.path.join(DIST, '05_报告', '问题一至三求解报告.html'))

    cur = {'A': mean_of(os.path.join(F, 'verified_A.csv')),
           'B': mean_of(os.path.join(F, 'verified_B.csv')),
           'C': mean_of(os.path.join(F, 'verified_3.csv'))}
    rows = []
    for k in (1, 2, 3, 4, 5):
        cells = []
        for s in ('A', 'B', 'C'):
            v = cur[s].get(k)
            cells.append('%.4f' % v if v else '—')
        rows.append('| %d | %s |' % (k, ' | '.join(cells)))
    with open(os.path.join(DIST, 'README.md'), 'w', encoding='utf-8') as fh:
        # 注意：README 正文里含 `%`（如 “−18.9%”），不能用 % 格式化
        fh.write(README.replace('%(TABLE)s', '\n'.join(rows)))
    print('  ok   README.md')

    zpath = os.path.join(ROOT, 'deliverable.zip')
    with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED) as z:
        for base, _dirs, files in os.walk(DIST):
            for fn in files:
                p = os.path.join(base, fn)
                z.write(p, os.path.relpath(p, os.path.dirname(DIST)))
    print('  ok   %s (%.1f MB)' % (zpath, os.path.getsize(zpath) / 1e6))


if __name__ == '__main__':
    main()
