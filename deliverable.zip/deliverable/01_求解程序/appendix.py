"""appendix.py — 由发布级复核表生成三个问题的"逐用例附录"CSV。

输入（verify_mp.py 产出，均来自**未经补丁**的官方评估器）：
    <dir>/verified_A.csv   问题一（场景 A）
    <dir>/verified_B.csv   问题二（场景 B，无 L2）
    <dir>/verified_3.csv   问题三（场景 B + 只读 L2 Cache）
输出：
    <dir>/appendix_problem1.csv
    <dir>/appendix_problem2.csv
    <dir>/appendix_problem3.csv

附表列与题目口径一致：
    问题一/二：Makespan + 总额外数据搬运量 + 加速比（2~5 核）
    问题三：无 L2 与只读 Cache 两种配置各自的 Makespan、总额外数据搬运量、
            加速比，另加只读 Cache 配置下的 Cache 命中率。
"""
from __future__ import annotations

import argparse
import csv
import os
from collections import defaultdict

KS = [2, 3, 4, 5]


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def load(path):
    if not os.path.exists(path):
        return {}
    out = defaultdict(dict)
    for r in csv.DictReader(open(path, encoding='utf-8-sig')):
        hit = r.get('cache_hit_rate')
        out[r['case']][int(r['k'])] = dict(
            T1=_int(r['T1']) or 0, ms=_int(r['ms']) or 0,
            speedup=float(r['speedup']), added=_int(r['added_copy_bytes']),
            hit=(float(hit) if hit else None))
    return out


def order(data):
    return sorted(data, key=lambda s: int(s[5:-5]))


def basic(data, prob):
    fields = ['用例', '单核基准_Makespan']
    for k in KS:
        fields += ['问题%d_%d核_Makespan' % (prob, k),
                   '问题%d_%d核_加速比' % (prob, k),
                   '问题%d_%d核_总额外搬运量_B' % (prob, k)]
    rows = []
    for c in order(data):
        r = {'用例': c, '单核基准_Makespan': data[c][2]['T1']
             if 2 in data[c] else ''}
        for k in KS:
            d = data[c].get(k)
            r['问题%d_%d核_Makespan' % (prob, k)] = d['ms'] if d else ''
            r['问题%d_%d核_加速比' % (prob, k)] = ('%.4f' % d['speedup']) if d else ''
            r['问题%d_%d核_总额外搬运量_B' % (prob, k)] = d['added'] if d else ''
        rows.append(r)
    return fields, rows


def problem3(B, C):
    fields = ['用例', '单核基准_Makespan']
    for k in KS:
        fields += ['无L2_%d核_Makespan' % k, '无L2_%d核_加速比' % k,
                   '无L2_%d核_总额外搬运量_B' % k,
                   '只读Cache_%d核_Makespan' % k, '只读Cache_%d核_加速比' % k,
                   '只读Cache_%d核_总额外搬运量_B' % k,
                   '只读Cache_%d核_Cache命中率' % k, '只读Cache_%d核_相对无L2加速比' % k]
    rows = []
    for c in order(C or B):
        r = {'用例': c}
        src = C.get(c) or B.get(c) or {}
        first = src[min(src)] if src else None
        r['单核基准_Makespan'] = first['T1'] if first else ''
        for k in KS:
            db, dc = B.get(c, {}).get(k), C.get(c, {}).get(k)
            r['无L2_%d核_Makespan' % k] = db['ms'] if db else ''
            r['无L2_%d核_加速比' % k] = ('%.4f' % db['speedup']) if db else ''
            r['无L2_%d核_总额外搬运量_B' % k] = db['added'] if db else ''
            r['只读Cache_%d核_Makespan' % k] = dc['ms'] if dc else ''
            r['只读Cache_%d核_加速比' % k] = ('%.4f' % dc['speedup']) if dc else ''
            r['只读Cache_%d核_总额外搬运量_B' % k] = dc['added'] if dc else ''
            r['只读Cache_%d核_Cache命中率' % k] = (
                ('%.6f' % dc['hit']) if (dc and dc['hit'] is not None) else '')
            r['只读Cache_%d核_相对无L2加速比' % k] = (
                ('%.4f' % (db['ms'] / dc['ms'])) if (db and dc) else '')
        rows.append(r)
    return fields, rows


def write(path, fields, rows):
    with open(path, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print('-> %s  (%d 行 × %d 列)' % (path, len(rows), len(fields)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dir', required=True)
    ap.add_argument('--bp', default=None, help='问题二的 verified_*.csv 目录（默认同 --dir）')
    ap.add_argument('--cp', default=None, help='问题三的 verified_*.csv 目录（默认同 --dir）')
    args = ap.parse_args()
    d = args.dir
    A = load(os.path.join(d, 'verified_A.csv'))
    B = load(os.path.join(os.path.join(args.bp or d), 'verified_B.csv'))
    C = load(os.path.join(os.path.join(args.cp or d), 'verified_3.csv'))

    if A:
        write(os.path.join(d, 'appendix_problem1.csv'), *basic(A, 1))
    if B:
        write(os.path.join(d, 'appendix_problem2.csv'), *basic(B, 2))
    if B or C:
        write(os.path.join(d, 'appendix_problem3.csv'), *problem3(B, C))

    from collections import Counter
    for tag, data in (('问题一', A), ('问题二', B), ('问题三(只读Cache)', C)):
        if not data:
            continue
        cnt = Counter(len(v) for v in data.values())
        print('%s：%d 用例，k 分布 %s' % (tag, len(data), dict(sorted(cnt.items()))))


if __name__ == '__main__':
    main()
