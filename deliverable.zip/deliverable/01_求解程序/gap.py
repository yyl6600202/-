"""gap.py — 找出"离算力下界最远"的用例（提升均值的唯一有效方向）。

对每个用例、每个核数 k：
    LB_work = max(Σ PIPE_M cycles, Σ PIPE_V cycles) / k
    ratio   = ms / LB_work
ratio → 1 表示已接近完美并行；ratio 大表示仍有空间（通常是 DDR 带宽或核内 spill 主导）。

用法：python gap.py [--k 5] [--top 30]
"""
from __future__ import annotations

import argparse
import csv
import gc
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data')
F = os.path.join(HERE, 'out', 'final')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--k', type=int, default=5)
    ap.add_argument('--top', type=int, default=40)
    ap.add_argument('--csv', default=os.path.join(F, 'results_problem1.csv'))
    args = ap.parse_args()

    ms = {}
    t1 = {}
    for r in csv.DictReader(open(args.csv, encoding='utf-8-sig')):
        if int(r['k']) == args.k:
            ms[r['case']] = int(r['ms'])
            t1[r['case']] = int(r['T1'])

    rows = []
    for case in sorted(ms, key=lambda s: int(s[5:-5])):
        with open(os.path.join(DATA, case), encoding='utf-8') as f:
            g = json.load(f)
        pm = pv = 0
        tens = 0
        cyc = {}
        pred = {}
        for o in g['ops']:
            cyc[o['id']] = int(o.get('cycles', 0))
            if o.get('op') in ('COPY_IN', 'COPY_OUT'):
                continue
            if o['pipe'] == 'PIPE_M':
                pm += o['cycles']
            else:
                pv += o['cycles']
        for e in g.get('edges', ()):
            pred.setdefault(e['target'], []).append(e['source'])
        for t in g.get('tensors', ()):
            if t.get('pos') == 'DDR':
                tens += t['size']
        # 关键路径（含 COPY 节点，按算子周期加权）—— Kahn 拓扑序 DP
        import collections
        succ = collections.defaultdict(list)
        for tgt, srcs in pred.items():
            for s in srcs:
                if s in cyc and tgt in cyc:
                    succ[s].append(tgt)
        indeg = {n: len([s for s in pred.get(n, ()) if s in cyc]) for n in cyc}
        q = collections.deque([n for n in cyc if indeg[n] == 0])
        dist = {n: cyc[n] for n in cyc}
        while q:
            u = q.popleft()
            for v in succ[u]:
                if dist[u] + cyc[v] > dist[v]:
                    dist[v] = dist[u] + cyc[v]
                indeg[v] -= 1
                if indeg[v] == 0:
                    q.append(v)
        cp = max(dist.values()) if dist else 0
        del g, pred, succ, dist
        lb = max(max(pm, pv) / args.k, cp)
        lbw = max(pm, pv) / args.k
        ddr = tens / 60.0
        msr = ms[case]
        rows.append(dict(case=case, ms=msr, T1=t1[case], sp=t1[case] / msr,
                         LB=lb, LBw=lbw, cp=cp, ratio=msr / max(lb, 1),
                         ratio_w=msr / max(lbw, 1),
                         ratio_ddr=msr / max(lb + ddr, 1),
                         ddr_cyc=int(ddr)))
        gc.collect()

    rows.sort(key=lambda r: -r['ratio'])
    print('k=%d  LB = max(ΣM/k, ΣV/k, 关键路径)' % args.k)
    print('%-14s %-11s %-8s %-11s %-11s %-8s %-8s %-8s' % (
        'case', 'ms', 'speedup', 'LB(cp)', 'CP', 'ms/LB', 'ms/LBw', 'ms/LBddr'))
    for r in rows[:args.top]:
        print('%-14s %-11d %-8.4f %-11.0f %-11.0f %-8.3f %-8.3f %-8.3f' % (
            r['case'], r['ms'], r['sp'], r['LB'], r['cp'], r['ratio'],
            r['ratio_w'], r['ratio_ddr']))
    print('...')
    import statistics as st
    print('n=%d  mean sp=%.4f  mean ms/LB=%.3f  median=%.3f  mean ms/LBw=%.3f' % (
        len(rows), st.mean(r['sp'] for r in rows),
        st.mean(r['ratio'] for r in rows), st.median(r['ratio'] for r in rows),
        st.mean(r['ratio_w'] for r in rows)))
    for thr in (1.2, 1.4, 1.6, 2.0):
        big = [r for r in rows if r['ratio'] > thr]
        gain = sum(r['T1'] / (r['LB'] * thr) - r['sp'] for r in big) / len(rows)
        print('  ratio>%.1f: %2d 例，若压到该阈值 → 均值 +%.4f' % (
            thr, len(big), gain))


if __name__ == '__main__':
    main()
