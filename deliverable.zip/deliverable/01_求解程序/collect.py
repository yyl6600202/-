"""collect.py — 收集某个计划目录下的全部方案，逐份做官方合法性校验 + 官方口径评测，
产出 summary_all.csv 与校验报告。

用法：
    python collect.py --dir out/runF [--out out/runF/summary_all.csv]
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, 'code'))
DATA = os.path.join(HERE, 'data')

import fl  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dir', required=True)
    ap.add_argument('--out', default=None)
    ap.add_argument('--no-validate', action='store_true')
    ap.add_argument('--ks', nargs='+', type=int, default=[2, 3, 4, 5])
    args = ap.parse_args()

    fl.load_fast()
    fl.config()
    from stub_multicore_cut_and_schedule import validate_multicore_plan

    d = args.dir
    cases = sorted({f.split('_k')[0] for f in os.listdir(d)
                    if f.startswith('case_') and f.endswith('.json')},
                   key=lambda s: int(s[5:]))
    rows = []
    bad = []
    for c in cases:
        case = c + '.json'
        g = json.load(open(os.path.join(DATA, case), encoding='utf-8'))
        fl.set_graph(case, g)
        t1 = fl.eval_p1(case, fl.single_plan(g))[0]
        for k in args.ks:
            p = os.path.join(d, '%s_k%d.json' % (c, k))
            if not os.path.exists(p):
                continue
            plan = json.load(open(p, encoding='utf-8'))
            if not args.no_validate:
                try:
                    validate_multicore_plan(g, plan)
                except Exception as exc:  # noqa: BLE001
                    bad.append((c, k, repr(exc)[:200]))
                    continue
            ms = fl.eval_p1(case, plan)[0]
            rows.append(dict(case=case, k=k, T1=t1, ms=ms,
                             speedup=round(t1 / ms, 6), tag='', evals='', secs=''))
        print(c, flush=True)

    out = args.out or os.path.join(d, 'summary_all.csv')
    rows.sort(key=lambda r: (int(r['case'][5:-5]), r['k']))
    with open(out, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['case', 'k', 'T1', 'ms', 'speedup',
                                          'tag', 'evals', 'secs'])
        w.writeheader()
        w.writerows(rows)

    byk = defaultdict(list)
    per = defaultdict(dict)
    for r in rows:
        byk[r['k']].append(r['speedup'])
        per[r['case']][r['k']] = r['speedup']
    print('\n=== 校验：不合法方案 %d 份 ===' % len(bad))
    for b in bad[:30]:
        print('  ', b)
    n_all = len({r['case'] for r in rows})
    print('\n=== 用例数 %d，行数 %d ===' % (n_all, len(rows)))
    for k in sorted(byk):
        v = byk[k]
        print('k=%d  n=%d  mean=%.4f  min=%.4f  max=%.4f' % (
            k, len(v), sum(v) / len(v), min(v), max(v)))
    # 单调性检查 S_2<=S_3<=S_4<=S_5
    mono_bad = []
    for c, dd in per.items():
        ks = sorted(dd)
        for a, b in zip(ks, ks[1:]):
            if dd[b] < dd[a] - 1e-9:
                mono_bad.append((c, a, b, dd[a], dd[b]))
    print('单调性违例：%d 例' % len(mono_bad))
    for m in mono_bad[:15]:
        print('  ', m)
    print('\nsummary -> %s' % out)


if __name__ == '__main__':
    main()
