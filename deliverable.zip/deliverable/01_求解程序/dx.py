"""dx.py — 诊断某案例的分组粒度、最佳方案的 Task 结构、以及每核 M/V 负载。"""
import json
import os
import sys
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
DATA = os.path.join(HERE, 'data')

import fl  # noqa: E402
import opt as optmod  # noqa: E402
import px  # noqa: E402
import solve_final as SF  # noqa: E402


def main():
    case = sys.argv[1]
    planfile = sys.argv[2] if len(sys.argv) > 2 else None
    fl.load_fast()
    fl.config()
    g = json.load(open(os.path.join(DATA, case), encoding='utf-8'))
    fl.set_graph(case, g)
    V = SF.attach_esz(optmod.View(g))
    t1 = fl.eval_p1(case, fl.single_plan(g))[0]
    tm = sum(V.cyc[o] for o in V.ops if V.pipe[o] == 'PIPE_M')
    tv = sum(V.cyc[o] for o in V.ops if V.pipe[o] != 'PIPE_M')
    print('%s ops=%d M=%d V=%d T1=%d  LB5=%d' % (case, len(V.ops), tm, tv, t1,
                                                 max(tm // 5, tv // 5)))
    chains = optmod.groups_chains(V)
    print('chains: %d 组, 大小 top10 %s' % (len(chains),
                                        sorted((len(c) for c in chains), reverse=True)[:10]))
    for cap in (8, 16, 32, 64, 128):
        us = SF.units_split_from(V, chains, cap)
        print('  split%-4d units=%-5d maxsize=%-5d' % (cap, len(us),
                                                      max(len(u) for u in us)))
    comps = optmod.groups_components(V, 1)
    print('  comp1   units=%-5d' % len(comps))
    # 分量结构
    compall = optmod.groups_components(V, None)
    print('弱连通分量 %d 个, top10 %s' % (len(compall),
                                     sorted((len(c) for c in compall), reverse=True)[:10]))

    if planfile and os.path.exists(planfile):
        plan = json.load(open(planfile, encoding='utf-8'))
        r = fl.load_fast()['p1'].evaluate_scene_a(
            g, plan, bandwidth=60, capacity={'L1': 524288, 'UB': 131072},
            cross_core_wait=1000, same_core_wait=100)
        print('\nplan makespan=%d  sp=%.4f' % (r['makespan'], t1 / r['makespan']))
        print('core_schedules lens', [len(x) for x in plan['core_schedules']])
        cnt = Counter(plan['node_to_subgraph'].values())
        print('subgraph sizes top15', sorted(cnt.values(), reverse=True)[:15])
        # 每核任务数与负载
        op2sg = {int(k): v for k, v in plan['node_to_subgraph'].items()}
        sgcore = {}
        for ci, sgs in enumerate(plan['core_schedules']):
            for sg in sgs:
                sgcore[sg] = ci
        load = defaultdict(lambda: [0, 0, 0])
        for o in V.ops:
            sg = op2sg.get(o)
            ci = sgcore.get(sg, -1)
            if V.pipe[o] == 'PIPE_M':
                load[ci][0] += V.cyc[o]
            else:
                load[ci][1] += V.cyc[o]
        for ci in sorted(load):
            m, v, _ = load[ci]
            print('  core%d  M=%-9d V=%-9d max=%d  tasks=%d'
                  % (ci, m, v, max(m, v),
                     sum(1 for sg in plan['core_schedules'][ci])))
        print('per_core_timeline:', json.dumps(r['per_core_timeline'])[:600])


if __name__ == '__main__':
    main()
